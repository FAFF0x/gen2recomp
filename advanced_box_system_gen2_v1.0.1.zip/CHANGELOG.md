# Changelog

## 1.0.1 - Modern UI integration

- `AdvancedBoxBrowserGen2` now exposes stable Pokémon-browser semantics for UI overhaul mods.
- Every browser row publishes the live Pokémon as `source`, plus `species`, `pokemonIcon`, and `semanticRole = "pokemon"`.
- Added `getPokemonList()` and `getSelectedPokemon()` read-only presentation seams.
- Added `semanticKind = "gen2_box"` / `absPokemonBrowser` markers so Modern UI can use its rich box presenter instead of treating Advanced Box as a generic ListMenu.
- Storage, swap, release, MAIL safety, box navigation and native Gen 2 actions are unchanged.


## 1.0.0 - Gen 2 port

- New standalone id: `advanced_box_system_gen2`.
- Targets `games: ["gen2"]` (Gold / Silver / Crystal).
- Replaced Gen 1 `src.pokemon.Boxes` assumptions with native `src.core.gen2.Boxes`.
- Updated storage geometry from 12 boxes to 14 boxes, 20 Pokémon each.
- Replaced Gen 1 `Stats.calc/ensure` with Gen 2 `Mon.stats/refreshStats`.
- Uses Gen 2 Summary screen (`Gen2SummaryMenu`).
- Integrates through the shared `ui.pc.items` hook instead of overriding the Gen 1 `BoxMenu` screen id.
- Preserves Gen 2 PC lifecycle, SEE YA!, MAILBOX and house-only extras.
- Added direct Gen 2-safe SWAP with MAIL and usable-party guards.
- Deposit/withdraw/release use Gen 2 storage model functions.
- Removed Yellow Pikachu-happiness and PRINT BOX paths that do not belong to Gen 2.
