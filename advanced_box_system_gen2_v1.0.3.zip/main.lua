-- Advanced Box System Gen 2 for Pokemon Recomp
-- v1.0.3
--
-- Native Gold / Silver / Crystal port of Advanced Box System v1.1.0.
-- Uses the released Gen 2 storage model instead of Gen 1 table assumptions:
--   * 14 boxes x 20 Pokemon
--   * MAIL-aware deposit/swap rules
--   * last-usable-Pokemon safety
--   * Gen 2 box-entry PP/status semantics
--   * Gen 2 six-stat calculations (Sp. Atk / Sp. Def split)
--
-- The native Gen2PcMenu remains the owner of Bill's PC.  This mod replaces
-- its storage operation rows through ui.pc.items, so PC lifecycle, house-PC
-- extras, translations, and other mods remain composable.

local SCREEN_ID = "AdvancedBoxBrowserGen2"
local VERSION = "1.0.3"

local function clamp(value, minimum, maximum)
  value = math.floor(tonumber(value) or minimum)
  if value < minimum then return minimum end
  if value > maximum then return maximum end
  return value
end

local function fit(text, maximum)
  text = tostring(text or "")
  if #text <= maximum then return text end
  if maximum <= 1 then return text:sub(1, maximum) end
  return text:sub(1, maximum - 1) .. "."
end

return function(mod)
  local Boxes = require("src.core.gen2.Boxes")
  local Mon = require("src.battle.gen2.Mon")
  local Mail = require("src.core.gen2.Mail")
  local Sound = require("src.core.Sound")
  local Strings = require("src.core.Strings")

  local Menu = mod.ui.Menu
  local ListMenu = mod.ui.ListMenu
  local TextBox = mod.ui.TextBox

  local function monDef(game, mon)
    return mon and game.data and game.data.pokemon
      and game.data.pokemon[mon.species] or nil
  end

  local function monName(game, mon)
    if not mon then return "--" end
    local name = Mon.displayName and Mon.displayName(mon) or nil
    if name and name ~= "?" then return name end
    local def = monDef(game, mon)
    return mon.nickname or mon.name or (def and def.name)
      or tostring(mon.species or "?")
  end

  local function playCry(game, mon)
    if not (game and game.data and mon and mon.species) or mon.isEgg then return end
    local cries = game.data.audio and game.data.audio.cries
    if cries and cries[mon.species] then
      Sound.playCry(game.data, mon.species)
    end
  end

  local function playUiSfx(game)
    local data = game and game.data
    local sfx = data and data.audio and data.audio.sfx
    if sfx and sfx[Sound.resolve(data, "Sfx_ReadText2")] then
      Sound.play(data, "Sfx_ReadText2")
    end
  end

  local function boxAt(game, number)
    number = clamp(number or (game.save and game.save.currentBox) or 1,
      1, Boxes.NUM_BOXES)
    return Boxes.box(game.save, number)
  end

  local function setCurrentBox(game, number)
    number = ((math.floor(number or 1) - 1) % Boxes.NUM_BOXES) + 1
    Boxes.setCurrent(game.save, number)
    return number
  end

  local function nextBox(game, delta)
    return setCurrentBox(game, ((game.save and game.save.currentBox) or 1) + delta)
  end

  -- A capture with a full party normally checks ONLY wCurBox/currentBox.
  -- Advanced Box instead treats the boxes as one storage pool: keep the
  -- preferred box while it has room, otherwise walk forward (wrapping after
  -- BOX14) until a free slot is found.  Nil means every box is full.
  local function firstFreeBox(save, preferred)
    preferred = clamp(preferred or (save and save.currentBox) or 1,
      1, Boxes.NUM_BOXES)
    if not Boxes.isFull(save, preferred) then return preferred end
    for offset = 1, Boxes.NUM_BOXES - 1 do
      local candidate = ((preferred - 1 + offset) % Boxes.NUM_BOXES) + 1
      if not Boxes.isFull(save, candidate) then return candidate end
    end
    return nil
  end

  local function selectFreeBox(save, preferred)
    if not save then return nil end
    local target = firstFreeBox(save, preferred)
    if target then Boxes.setCurrent(save, target) end
    return target
  end

  -- BattleState's Poke Ball gate and SendMonIntoBox path both ask currentBox().
  -- Wrapping this one seam keeps the three reads coherent: a full current box
  -- automatically rolls to the next box with space before the Ball is refused,
  -- the catch is inserted into that same box, and if the insert fills it the
  -- final read advances currentBox again for the next capture.  When all 14
  -- boxes are full, the original box is returned so the engine's BOX FULL
  -- refusal remains intact and no Pokemon can be lost.
  local function installCaptureAutoBox()
    local okBattle, BattleState = pcall(require, "src.ui.gen2.BattleState")
    if okBattle and type(BattleState) == "table"
      and type(BattleState.currentBox) == "function" then
      BattleState.__advancedBoxBaseCurrentBox =
        BattleState.__advancedBoxBaseCurrentBox or BattleState.currentBox
      local baseCurrentBox = BattleState.__advancedBoxBaseCurrentBox
      BattleState.currentBox = function(self)
        local current = baseCurrentBox(self)
        local save = self and self.save
        if not save or not Boxes.isFull(save, current) then return current end
        local target = selectFreeBox(save, current)
        if target then
          if self.battle then
            self.battle.advancedBoxAutoBoxFrom = current
            self.battle.advancedBoxAutoBoxTo = target
          end
          return target
        end
        return current
      end
      BattleState.__advancedBoxAutoCaptureVersion = VERSION
    end

    -- The Bug-Catching Contest has a separate post-contest storage path that
    -- does not use BattleState:currentBox().  Preselect a free box there too,
    -- so a contest catch follows the same automatic rollover rule.
    local okContest, BugContest = pcall(require, "src.core.gen2.BugContest")
    if okContest and type(BugContest) == "table"
      and type(BugContest.collectCaughtMon) == "function" then
      BugContest.__advancedBoxBaseCollectCaughtMon =
        BugContest.__advancedBoxBaseCollectCaughtMon
        or BugContest.collectCaughtMon
      local baseCollect = BugContest.__advancedBoxBaseCollectCaughtMon
      BugContest.collectCaughtMon = function(save, partySize, boxes)
        local state = save and BugContest.state(save)
        local mon = state and state.caught
        local party = (save and save.party) or {}
        local capacity = partySize or Boxes.PARTY_SIZE
        if mon and #party >= capacity then
          selectFreeBox(save, save.currentBox or 1)
        end
        return baseCollect(save, partySize, boxes)
      end
      BugContest.__advancedBoxAutoCaptureVersion = VERSION
    end
  end

  installCaptureAutoBox()

  -- Read-only stat block for list rows. Box mons can legitimately lack a
  -- cached party-style stat block; Gen 2's Mon.stats is the correct six-stat
  -- calculator and does not rewrite the save just for looking at a row.
  local function temporaryStats(game, mon)
    if type(mon) ~= "table" then return {} end
    local s = mon.stats
    if type(s) == "table" and type(s.hp) == "number"
      and type(s.attack) == "number" and type(s.defense) == "number"
      and type(s.speed) == "number" and type(s.specialAttack) == "number"
      and type(s.specialDefense) == "number" then
      return s
    end
    local def = monDef(game, mon)
    if not (def and def.baseStats) then return {} end
    local ok, result = pcall(Mon.stats, def.baseStats, mon.dvs or {},
      mon.level or 1, mon.statExp or {})
    return ok and type(result) == "table" and result or {}
  end

  local function maxHpFor(game, mon)
    local stats = temporaryStats(game, mon)
    return tonumber(mon and mon.maxHp) or tonumber(stats.hp)
      or tonumber(mon and mon.hp) or 0
  end

  local function rowRight(game, mon)
    local hp = maxHpFor(game, mon)
    local level = tonumber(mon and mon.level) or 0
    if hp > 0 then
      local current = math.max(0, math.min(tonumber(mon.hp) or hp, hp))
      return ("Lv %d  %d/%d"):format(level, current, hp)
    end
    return ("Lv %d"):format(level)
  end

  local Browser = {}

  local function modeSourceKind(mode)
    if mode == "deposit" or mode == "swap_party" then return "party" end
    return "box"
  end

  function Browser.list(state)
    if modeSourceKind(state.absMode) == "party" then
      return (state.game.save and state.game.save.party) or {}
    end
    return boxAt(state.game, state.game.save.currentBox)
  end

  function Browser.title(state)
    local boxNo = state.game.save.currentBox or 1
    local boxName = Boxes.name(state.game.save, boxNo)
    if state.absMode == "withdraw" then
      return Strings("%s (WITHDRAW)", boxName)
    elseif state.absMode == "deposit" then
      return Strings("PARTY -> %s", boxName)
    elseif state.absMode == "release" then
      return Strings("%s (RELEASE)", boxName)
    elseif state.absMode == "swap_box" or state.absMode == "swap_box_target" then
      return Strings("%s (SWAP)", boxName)
    elseif state.absMode == "swap_party" then
      local pending = state.absPendingBoxNo or boxNo
      return Strings("PARTY -> %s", Boxes.name(state.game.save, pending))
    end
    return boxName
  end

  function Browser.footer(state)
    if state.absMessage then return state.absMessage end
    if state.absMode == "swap_party" then
      return Strings("Choose party POKéMON. B: back")
    elseif state.absMode == "swap_box" or state.absMode == "swap_box_target" then
      return Strings("L/R: BOX   A: SWAP   B: back")
    elseif state.absMode == "release" then
      return Strings("L/R: BOX   A: RELEASE   B: back")
    elseif state.absMode == "deposit" then
      return Strings("L/R: destination BOX   A: options")
    end
    return Strings("L/R: BOX   A: options")
  end

  function Browser.refresh(state, preserveIndex)
    local list = Browser.list(state)
    local oldIndex = state.index or 1
    state.items = {}
    for i, mon in ipairs(list) do
      state.items[#state.items + 1] = {
        label = fit(monName(state.game, mon), 13),
        right = rowRight(state.game, mon),
        value = i,
        mon = mon,

        -- Public presentation metadata for UI overhaul mods.  Keep the
        -- actual storage object as `source` so icon/sprite resolvers can use
        -- species, form, DVs and other live Gen 2 fields without parsing the
        -- row label.
        source = mon,
        species = mon.species,
        pokemonIcon = true,
        semanticRole = "pokemon",
      }
    end
    state.title = Browser.title(state)
    state.footer = Browser.footer(state)
    state.absSourceKind = modeSourceKind(state.absMode)
    state.absBoxNo = state.game.save.currentBox or 1
    if #state.items == 0 then
      state.index, state.scroll = 1, 0
    else
      state.index = clamp(preserveIndex and oldIndex or 1, 1, #state.items)
      local rows = state.rows or 7
      state.scroll = clamp(state.scroll or 0, 0, math.max(0, #state.items - rows))
      if state.index <= state.scroll then state.scroll = state.index - 1 end
      if state.index > state.scroll + rows then state.scroll = state.index - rows end
    end
  end

  function Browser.setMessage(state, message)
    state.absMessage = Strings(message)
    state.footer = Browser.footer(state)
  end

  function Browser.clearMessage(state)
    state.absMessage = nil
    state.footer = Browser.footer(state)
  end

  function Browser.showMessage(state, text)
    state.game.stack:push(TextBox.new(state.game, text))
  end

  function Browser.showStats(state, mon)
    if not mon then return end
    -- SummaryMenu.refreshStats uses the native Gen 2 stat calculator and is
    -- the same route the stock BoxMenu uses for boxed mons.
    mod.ui.push(state.game, "Gen2SummaryMenu", {
      mon = mon,
      save = state.game.save,
      onClose = function()
        if state.game.stack and state.game.stack:top() then
          state.game.stack:pop()
        end
      end,
    })
  end

  function Browser.switchBox(state, delta)
    if state.absMode == "swap_party" then return false end
    nextBox(state.game, delta)
    Browser.clearMessage(state)
    Browser.refresh(state, true)
    playUiSfx(state.game)
    return true
  end

  function Browser.withdrawAt(state, index)
    local boxNo = state.game.save.currentBox or 1
    local box = boxAt(state.game, boxNo)
    local mon = box[index]
    if not mon then return false end

    -- Refresh before withdraw so Boxes.withdraw's heal targets the current
    -- calculated max HP, not a stale imported/cached value.
    Mon.refreshStats(mon, state.game.data)
    local ok, result = Boxes.withdraw(state.game.save, boxNo, index)
    if not ok then
      Browser.setMessage(state, result)
      return false
    end

    playCry(state.game, result)
    Browser.refresh(state, true)
    Browser.showMessage(state, Strings("%s was taken\nout of %s.",
      monName(state.game, result), Boxes.name(state.game.save, boxNo)))
    return true
  end

  function Browser.depositAt(state, index)
    local party = state.game.save.party or {}
    local mon = party[index]
    if not mon then return false end
    local boxNo = state.game.save.currentBox or 1
    local name = monName(state.game, mon)
    local ok, result = Boxes.deposit(state.game.save, index, boxNo)
    if not ok then
      Browser.setMessage(state, result)
      return false
    end

    playCry(state.game, result)
    Browser.refresh(state, true)
    Browser.showMessage(state, Strings("%s was stored\nin %s.",
      name, Boxes.name(state.game.save, boxNo)))
    return true
  end

  function Browser.releaseAt(state, index)
    local boxNo = state.game.save.currentBox or 1
    local box = boxAt(state.game, boxNo)
    local mon = box[index]
    if not mon then return false end
    if mon.isEgg then
      Browser.setMessage(state, "NO RELEASING EGGS!")
      return false
    end

    local name = monName(state.game, mon)
    state.game.stack:push(TextBox.new(state.game,
      Strings("Release %s from\n%s forever?", name, Boxes.name(state.game.save, boxNo)),
      nil, {
        defaultNo = true,
        choice = function(yes)
          if not yes then return end
          local liveBox = boxAt(state.game, boxNo)
          if liveBox[index] ~= mon then
            Browser.setMessage(state, "POKéMON MOVED - TRY AGAIN")
            return
          end
          local ok, released = Boxes.release(state.game.save, boxNo, index)
          if not ok then
            Browser.setMessage(state, released)
            return
          end
          playCry(state.game, released)
          Browser.refresh(state, true)
          Browser.showMessage(state, Strings("Bye, %s!", name))
        end,
      }))
    return true
  end

  function Browser.beginSwapFromBox(state, index, returnMode)
    local boxNo = state.game.save.currentBox or 1
    local mon = boxAt(state.game, boxNo)[index]
    if not mon then return false end
    state.absPendingBoxNo = boxNo
    state.absPendingBoxIndex = index
    state.absPendingPartyIndex = nil
    state.absReturnMode = returnMode or "swap_box"
    state.absMode = "swap_party"
    state.index, state.scroll = 1, 0
    Browser.setMessage(state, "CHOOSE PARTY POKéMON")
    Browser.refresh(state, false)
    return true
  end

  function Browser.beginSwapFromParty(state, index)
    local mon = state.game.save.party and state.game.save.party[index]
    if not mon then return false end
    state.absPendingPartyIndex = index
    state.absPendingBoxNo = nil
    state.absPendingBoxIndex = nil
    state.absReturnMode = "deposit"
    state.absMode = "swap_box_target"
    state.index, state.scroll = 1, 0
    Browser.setMessage(state, "CHOOSE BOX POKéMON")
    Browser.refresh(state, false)
    return true
  end

  local function swapAllowed(state, boxMon, partyMon)
    -- A boxed mon has nowhere to store sPartyMail.  Native deposit refuses the
    -- same condition; direct swap must not bypass it.
    if Mail.monHoldsMail(partyMon) then
      return false, "REMOVE MAIL FIRST"
    end

    -- Party size does not change, but replacing the only usable battler with
    -- an EGG would still leave no usable Pokemon. A normal boxed Pokemon is
    -- healed on entry to party, matching Boxes.withdraw.
    if (partyMon.hp or 0) > 0 and Boxes.healthyCount(state.game.save.party) <= 1
      and boxMon.isEgg then
      return false, "LAST USABLE POKéMON"
    end
    return true
  end

  local function prepareBoxMonForParty(game, mon)
    Mon.refreshStats(mon, game.data)
    mon.status = nil
    mon.statusTurns = nil
    if mon.isEgg then
      mon.hp = 0
    else
      mon.hp = mon.maxHp or (mon.stats and mon.stats.hp) or mon.hp
    end
  end

  function Browser.finishSwap(state, boxNo, boxIndex, partyIndex)
    local party = state.game.save.party or {}
    local box = boxAt(state.game, boxNo)
    local boxMon = box[boxIndex]
    local partyMon = party[partyIndex]
    if not boxMon or not partyMon then
      Browser.setMessage(state, "SWAP TARGET CHANGED")
      return false
    end

    local allowed, reason = swapAllowed(state, boxMon, partyMon)
    if not allowed then
      Browser.setMessage(state, reason)
      return false
    end

    local boxName = monName(state.game, boxMon)
    local partyName = monName(state.game, partyMon)

    -- Recreate the two native transfer tails while keeping party slot and box
    -- slot fixed. No Mail.removeSlot call is needed: party size/order do not
    -- shift, and the outgoing slot was just verified to contain no mail.
    prepareBoxMonForParty(state.game, boxMon)
    Boxes.enterBox(partyMon)
    box[boxIndex] = partyMon
    party[partyIndex] = boxMon

    playCry(state.game, boxMon)

    local back = state.absReturnMode or "swap_box"
    state.absMode = back
    state.absPendingBoxNo = nil
    state.absPendingBoxIndex = nil
    state.absPendingPartyIndex = nil
    state.absReturnMode = nil

    if back == "swap_box" or back == "withdraw" or back == "release" then
      setCurrentBox(state.game, boxNo)
      state.index = math.min(boxIndex, math.max(1, #box))
    else
      state.index = math.min(partyIndex, math.max(1, #party))
    end
    state.scroll = 0
    Browser.clearMessage(state)
    Browser.refresh(state, true)
    Browser.showMessage(state, Strings("%s joined the party.\n%s moved to %s.",
      boxName, partyName, Boxes.name(state.game.save, boxNo)))
    return true
  end

  function Browser.activate(state, index)
    Browser.clearMessage(state)
    local list = Browser.list(state)
    if #list == 0 then
      Browser.setMessage(state,
        modeSourceKind(state.absMode) == "party" and "PARTY IS EMPTY" or "BOX IS EMPTY")
      return false
    end
    index = clamp(index or state.index or 1, 1, #list)
    state.index = index
    local mon = list[index]
    if not mon then return false end

    if state.absMode == "withdraw" then
      state.game.stack:push(Menu.new(state.game, {
        { label = "WITHDRAW", onSelect = function() Browser.withdrawAt(state, index) end },
        { label = "SWAP", onSelect = function() Browser.beginSwapFromBox(state, index, "withdraw") end },
        { label = "STATS", keepOpen = true, onSelect = function() Browser.showStats(state, mon) end },
        { label = "CANCEL" },
      }, { tx = 9, ty = 8, tw = 11, th = 10, noSound = true }))
      return true
    elseif state.absMode == "deposit" then
      state.game.stack:push(Menu.new(state.game, {
        { label = "DEPOSIT", onSelect = function() Browser.depositAt(state, index) end },
        { label = "SWAP", onSelect = function() Browser.beginSwapFromParty(state, index) end },
        { label = "STATS", keepOpen = true, onSelect = function() Browser.showStats(state, mon) end },
        { label = "CANCEL" },
      }, { tx = 9, ty = 8, tw = 11, th = 10, noSound = true }))
      return true
    elseif state.absMode == "release" then
      return Browser.releaseAt(state, index)
    elseif state.absMode == "swap_box" then
      return Browser.beginSwapFromBox(state, index, "swap_box")
    elseif state.absMode == "swap_party" then
      if not (state.absPendingBoxNo and state.absPendingBoxIndex) then
        state.absMode = "swap_box"
        Browser.setMessage(state, "SELECT BOX POKéMON AGAIN")
        Browser.refresh(state, false)
        return false
      end
      return Browser.finishSwap(state, state.absPendingBoxNo,
        state.absPendingBoxIndex, index)
    elseif state.absMode == "swap_box_target" then
      if not state.absPendingPartyIndex then
        state.absMode = "deposit"
        Browser.setMessage(state, "SELECT PARTY POKéMON AGAIN")
        Browser.refresh(state, false)
        return false
      end
      return Browser.finishSwap(state, state.game.save.currentBox or 1,
        index, state.absPendingPartyIndex)
    end
    return false
  end

  function Browser.back(state)
    if state.absMode == "swap_party" then
      local boxNo = state.absPendingBoxNo or state.game.save.currentBox or 1
      local boxIndex = state.absPendingBoxIndex or 1
      setCurrentBox(state.game, boxNo)
      state.absMode = state.absReturnMode or "swap_box"
      state.absPendingBoxNo = nil
      state.absPendingBoxIndex = nil
      state.absPendingPartyIndex = nil
      state.absReturnMode = nil
      state.index, state.scroll = boxIndex, 0
      Browser.clearMessage(state)
      Browser.refresh(state, true)
      return true
    elseif state.absMode == "swap_box_target" then
      local partyIndex = state.absPendingPartyIndex or 1
      state.absMode = "deposit"
      state.absPendingBoxNo = nil
      state.absPendingBoxIndex = nil
      state.absPendingPartyIndex = nil
      state.absReturnMode = nil
      state.index, state.scroll = partyIndex, 0
      Browser.clearMessage(state)
      Browser.refresh(state, true)
      return true
    end
    state.game.stack:pop()
    return true
  end

  function Browser.new(game, mode)
    game.save.party = game.save.party or {}
    game.save.boxes = game.save.boxes or {}
    setCurrentBox(game, game.save.currentBox or 1)

    local state
    state = ListMenu.new(game, "", {}, {
      noSound = true,
      wrap = true,
      rows = 7,
      onChoose = function(item)
        Browser.activate(state, item and item.value or state.index)
      end,
    })

    state.absAdvancedBox = true
    state.absAdvancedBoxGen2 = true
    state.absPokemonBrowser = true
    state.semanticKind = "gen2_box"
    state.absMode = mode or "withdraw"

    -- Stable, read-only seams for Modern UI and other presentation mods.
    -- They deliberately expose the same live tables Browser itself uses;
    -- actions and mutation remain owned by Advanced Box System.
    state.getPokemonList = function(self)
      return Browser.list(self)
    end
    state.getSelectedPokemon = function(self)
      local item = self.items and self.items[self.index or 1]
      return item and (item.mon or item.source) or nil
    end
    state.absMessage = nil
    state.absPendingBoxNo = nil
    state.absPendingBoxIndex = nil
    state.absPendingPartyIndex = nil
    state.absReturnMode = nil

    local baseUpdate = state.update
    state.update = function(self, dt)
      local input = self.game and self.game.input
      if not input then return baseUpdate(self, dt) end
      if input:wasPressed("left") then
        Browser.switchBox(self, -1)
        return
      elseif input:wasPressed("right") then
        Browser.switchBox(self, 1)
        return
      elseif input:wasPressed("b") then
        Browser.back(self)
        return
      elseif input:wasPressed("a") and #self.items == 0 then
        Browser.activate(self, 1)
        return
      end
      baseUpdate(self, dt)
    end

    Browser.refresh(state, false)
    return state
  end

  local function openBrowser(game, mode)
    mod.ui.push(game, SCREEN_ID, mode)
  end

  local changeBox

  -- Remote storage hub opened from the Gen 2 Start menu.  The StartMenu
  -- itself stays underneath on the state stack, just like POKéMON/PACK, so B
  -- returns here and then to the overworld naturally.  It delegates every
  -- operation to the same Browser/Boxes paths used by Bill's PC; only the
  -- physical-PC requirement is removed.
  local function openRemoteBoxHub(game)
    if not (game and game.stack and game.save) then return false end

    -- The Bug-Catching Contest temporarily masks the party and owns a held
    -- contest mon outside normal storage.  Opening PC storage in the middle
    -- of that mode can invalidate its restore path, so keep the remote entry
    -- inert there instead of risking save corruption.
    local contest = game.save.bugContest
    if contest and contest.active then
      game.stack:push(TextBox.new(game,
        Strings("BOX access is unavailable\nduring the Contest.")))
      return false
    end

    local hub
    local items = {
      { label = Strings("WITHDRAW <PK><MN>"), mode = "withdraw" },
      { label = Strings("DEPOSIT <PK><MN>"), mode = "deposit" },
      { label = Strings("SWAP <PK><MN>"), mode = "swap_box" },
      { label = Strings("RELEASE <PK><MN>"), mode = "release" },
      { label = Strings("CHANGE BOX"), action = "change_box" },
      { label = Strings("CANCEL"), action = "cancel" },
    }

    hub = ListMenu.new(game, Strings("POKéMON BOX"), items, {
      noSound = true,
      wrap = true,
      rows = 6,
      onChoose = function(item, list)
        if not item then return end
        if item.mode then
          openBrowser(game, item.mode)
        elseif item.action == "change_box" then
          changeBox(game)
        elseif item.action == "cancel" then
          if list and list.close then list:close()
          elseif game.stack and game.stack.top and game.stack:top() == hub then
            game.stack:pop()
          end
        end
      end,
    })
    hub.absAdvancedBoxRemoteHubGen2 = true
    hub.semanticKind = "gen2_box_hub"
    game.stack:push(hub)
    return true
  end

  changeBox = function(game)
    local items = {}
    for i = 1, Boxes.NUM_BOXES do
      local mark = i == (game.save.currentBox or 1) and "*" or " "
      items[#items + 1] = {
        label = Strings("%s%s", mark, Boxes.name(game.save, i)),
        right = ("%d/%d"):format(Boxes.count(game.save, i), Boxes.MONS_PER_BOX),
        value = i,
      }
    end
    game.stack:push(ListMenu.new(game, "CHANGE BOX", items, {
      noSound = true,
      onChoose = function(item, list)
        setCurrentBox(game, item.value)
        if game.writeSave then game:writeSave() end
        list:close()
      end,
    }))
  end

  mod.exports.open = function(game, mode)
    openBrowser(game, mode or "swap_box")
  end
  mod.exports.openRemote = function(game)
    return openRemoteBoxHub(game)
  end
  mod.exports.version = VERSION
  mod.exports.generation = 2
  mod.exports.boxCount = Boxes.NUM_BOXES
  mod.exports.boxCapacity = Boxes.MONS_PER_BOX

  mod.content.screens:register(SCREEN_ID, {
    new = function(game, mode)
      return Browser.new(game, mode)
    end,
  })

  -- Remote Bill's PC access from the Gen 2 Start menu.  Use the released
  -- shared hook so other Start-menu mods remain composable, anchor on SAVE
  -- rather than a row number, and suppress a duplicate BOX row if another
  -- copy/variant of Advanced Box is active.
  mod.hooks:wrap("ui.start_menu.items", function(next, game, items)
    local out = next(game, items)
    if type(out) ~= "table" then return out end

    for _, entry in ipairs(out) do
      if entry and (entry.absAdvancedBoxRemote == true
          or entry.label == "BOX" or entry.label == Strings("BOX")) then
        return out
      end
    end

    mod.ui.insertBefore(out, "SAVE", {
      label = "BOX",
      desc = { Strings("PC storage"), Strings("Anywhere") },
      absAdvancedBoxRemote = true,
      onSelect = function(g) openRemoteBoxHub(g or game) end,
    })
    return out
  end)

  -- Preserve Gen2PcMenu itself and compose through its released hook.  Its
  -- own SEE YA! is appended after the hook; house-only extras such as MAILBOX
  -- and DECORATION are kept below our advanced storage rows.
  mod.hooks:wrap("ui.pc.items", function(next, game, items)
    local out = next(game, items)
    if type(out) ~= "table" then return out end

    local advanced = {
      { label = Strings("WITHDRAW <PK><MN>"),
        onSelect = function(_, g) openBrowser(g or game, "withdraw") end },
      { label = Strings("DEPOSIT <PK><MN>"),
        onSelect = function(_, g) openBrowser(g or game, "deposit") end },
      { label = Strings("RELEASE <PK><MN>"),
        onSelect = function(_, g) openBrowser(g or game, "release") end },
      { label = Strings("SWAP <PK><MN>"),
        onSelect = function(_, g) openBrowser(g or game, "swap_box") end },
      { label = Strings("CHANGE BOX"),
        onSelect = function(_, g) changeBox(g or game) end },
    }

    local replaced = {
      withdraw = true, deposit = true, changebox = true, move = true,
    }
    for _, entry in ipairs(out) do
      if not replaced[entry.id] then
        advanced[#advanced + 1] = entry
      end
    end
    return advanced
  end)
end
