# Changelog

## 1.1.0

- Added HM01–HM07 to the dedicated free machine shop.
- Renamed the catalogue/menu entry to **TM/HM SHOP**.
- HMs are limited to one owned copy because they are reusable.
- Added **SELECT: INFO** from the machine list.
- Added a full move information screen with type, Gen 2 physical/special class, power, accuracy, PP, effect, effect chance, and ROM description.
- Added navigation through machines while the info screen is open.
- Normal mart stock filtering now removes both TM and HM machine entries to avoid duplicates.
- Zero-price patch now covers all 57 Gen 2 machines.
- Added regression tests for 50 TM + 7 HM discovery, HM purchases, SELECT info, and stock filtering.

## 1.0.0

- Initial Gen 2 port with free TM01–TM50 catalogue.
