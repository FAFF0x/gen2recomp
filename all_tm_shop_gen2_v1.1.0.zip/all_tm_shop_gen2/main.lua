-- Universal Free TM/HM Shop Gen 2 v1.1.0
-- Gold / Silver / Crystal port of all_tm_shop.
--
-- Gen 2 differences that matter here:
--   * TMs/HMs are items in pocket "TM_HM" and expose `tmNumber` + `teaches`.
--   * The native TM/HM pocket has 57 machine slots (50 TMs + 7 HMs).
--   * Shops are the Gen2MartMenu state, opened by the blocking pokemart opcode.
--
-- This mod does NOT enlarge bagSize. It registers a Gen2MartMenu chooser,
-- delegates the normal shop to the untouched native MartMenu, and opens a
-- dedicated Gen 2-native catalogue for TM01..TM50 + HM01..HM07. SELECT on a
-- highlighted machine opens the full move-information panel.

local Bag = require("src.inventory.Bag")
local Chrome = require("src.ui.gen2.Chrome")
local Sound = require("src.core.Sound")
local VanillaMartMenu = require("src.ui.gen2.MartMenu")

local NUM_TMS = 50
local NUM_HMS = 7
local NUM_MACHINES = NUM_TMS + NUM_HMS
local VISIBLE_ROWS = 8

local function machineInfo(def)
  if type(def) ~= "table" or def.pocket ~= "TM_HM" or def.teaches == nil then
    return nil
  end
  local label = tostring(def.tmLabel or def.name or ""):upper()
  local tm = tonumber(label:match("^TM(%d+)$") or label:match("^TM(%d+)"))
  if tm and tm >= 1 and tm <= NUM_TMS then
    return "TM", math.floor(tm), math.floor(tm)
  end
  local hm = tonumber(label:match("^HM(%d+)$") or label:match("^HM(%d+)"))
  if hm and hm >= 1 and hm <= NUM_HMS then
    return "HM", math.floor(hm), NUM_TMS + math.floor(hm)
  end
  local n = tonumber(def.tmNumber)
  if not n then return nil end
  n = math.floor(n)
  if n >= 1 and n <= NUM_TMS then return "TM", n, n end
  if n > NUM_TMS and n <= NUM_MACHINES then
    return "HM", n - NUM_TMS, n
  end
  return nil
end

local function isMachine(def)
  return machineInfo(def) ~= nil
end

local function isTM(def)
  local kind = machineInfo(def)
  return kind == "TM"
end

local function isHM(def)
  local kind = machineInfo(def)
  return kind == "HM"
end

local function discoverMachines(data)
  local out = {}
  for id, def in pairs((data and data.items) or {}) do
    local kind, number, order = machineInfo(def)
    if kind then
      out[#out + 1] = {
        id = id,
        kind = kind,
        number = number,
        order = order,
        move = def.teaches,
        itemName = def.tmLabel or def.name or ("%s%02d"):format(kind, number),
      }
    end
  end
  table.sort(out, function(a, b)
    if a.order ~= b.order then return a.order < b.order end
    return tostring(a.id) < tostring(b.id)
  end)
  return out
end

local function discoverTMs(data)
  local out = {}
  for _, machine in ipairs(discoverMachines(data)) do
    if machine.kind == "TM" then out[#out + 1] = machine end
  end
  return out
end

local function discoverHMs(data)
  local out = {}
  for _, machine in ipairs(discoverMachines(data)) do
    if machine.kind == "HM" then out[#out + 1] = machine end
  end
  return out
end


local function moveName(data, machine)
  local def = data and data.moves and data.moves[machine.move]
  return (def and def.name) or tostring(machine.move or "")
end

local function tmLabel(data, machine)
  local head = machine.itemName or ("%s%02d"):format(machine.kind or "TM", machine.number)
  return head .. " " .. moveName(data, machine)
end

local function normalStock(data, stock)
  local out = {}
  for _, id in ipairs(stock or {}) do
    if not isMachine(data and data.items and data.items[id]) then
      out[#out + 1] = id
    end
  end
  return out
end

-- Clone only the mart list that is about to open. All other extracted mart
-- data stays shared and untouched. This preserves the original mod's rule:
-- TMs/HMs live in the dedicated free catalogue, not in NORMAL SHOP at price 0.
local function filteredMarts(data, marts, martId)
  if type(marts) ~= "table" then return marts end
  local out = {}
  for k, v in pairs(marts) do out[k] = v end

  local source = marts.lists or marts
  if type(source) ~= "table" then return out end
  local lists = {}
  for k, v in pairs(source) do lists[k] = v end

  local index = (tonumber(martId) or 0) + 1
  if type(source[index]) == "table" then
    lists[index] = normalStock(data, source[index])
  end

  if marts.lists then
    out.lists = lists
    return out
  end
  return lists
end

local function popTop(game, expected)
  local stack = game and game.stack
  if not stack then return end
  if type(stack.top) == "function" then
    local ok, top = pcall(stack.top, stack)
    if ok and top ~= expected then return end
  end
  if type(stack.pop) == "function" then stack:pop() end
end

local function playTransaction(game)
  if not (game and game.data) then return end
  pcall(Sound.play, game.data, "Sfx_Transaction")
end

-- ========================================================================
-- Dedicated Gen 2 TM/HM catalogue.
-- ========================================================================

local FreeTMShop = {}
FreeTMShop.__index = FreeTMShop
FreeTMShop.isOpaque = true

function FreeTMShop.new(game, opts)
  opts = opts or {}
  local self = setmetatable({}, FreeTMShop)
  self.game = game
  self.save = opts.save or (game and game.save)
  self.onClose = opts.onClose
  self.rows = discoverMachines(game and game.data)
  self.index = 1
  self.scroll = 0
  self.phase = "list"
  self.qty = 1
  self.qtyMax = 1
  self.choice = 1
  self.message = nil
  self.screenId = "AllTmShopGen2Catalogue"
  return self
end

function FreeTMShop:wantsFillScale() return true end
function FreeTMShop:drawsWidescreen() return true end

function FreeTMShop:selected()
  return self.rows[self.index]
end

function FreeTMShop:owned(machine)
  local inv = self.save and self.save.inventory or {}
  return tonumber(inv and machine and inv[machine.id]) or 0
end

function FreeTMShop:ensureVisible()
  if self.index <= self.scroll then
    self.scroll = self.index - 1
  elseif self.index > self.scroll + VISIBLE_ROWS then
    self.scroll = self.index - VISIBLE_ROWS
  end
  self.scroll = math.max(0, math.min(self.scroll,
    math.max(0, #self.rows - VISIBLE_ROWS)))
end

function FreeTMShop:step(delta)
  local n = #self.rows
  if n == 0 then return end
  self.index = ((self.index - 1 + delta) % n) + 1
  self:ensureVisible()
end

function FreeTMShop:page(delta)
  if #self.rows == 0 then return end
  self.index = math.max(1, math.min(#self.rows,
    self.index + delta * VISIBLE_ROWS))
  self:ensureVisible()
end

function FreeTMShop:beginPurchase()
  local machine = self:selected()
  if not machine then
    self.message = "No TM/HM machines are available."
    return
  end
  local owned = self:owned(machine)
  if machine.kind == "HM" then
    if owned >= 1 then
      self.message = "You already have\nthis HM."
      return
    end
    self.qty = 1
    self.qtyMax = 1
  else
    if owned >= 99 then
      self.message = "You already have\n99 of this TM."
      return
    end
    self.qty = 1
    self.qtyMax = 99 - owned
  end
  self.phase = "quantity"
end

function FreeTMShop:quantityStep(delta)
  local n = self.qty + delta
  if math.abs(delta) == 1 then
    if n > self.qtyMax then n = 1 end
    if n < 1 then n = self.qtyMax end
  else
    n = math.max(1, math.min(self.qtyMax, n))
  end
  self.qty = n
end

function FreeTMShop:beginConfirm()
  self.choice = 1
  self.phase = "confirm"
end

function FreeTMShop:finishPurchase()
  local machine = self:selected()
  if not machine then
    self.phase = "list"
    return
  end
  if not Bag.add(self.save, machine.id, self.qty, self.game and self.game.data) then
    self.message = "You can't carry\nany more machines."
    self.phase = "list"
    return
  end
  playTransaction(self.game)
  self.message = ("Here you are!\n%s x%d."):format(machine.itemName, self.qty)
  self.phase = "list"
end

function FreeTMShop:close()
  if self.onClose then self.onClose() end
end

function FreeTMShop:update(_dt)
  local input = self.game and self.game.input
  if not input then return end

  if self.message then
    if input:wasPressed("a") or input:wasPressed("b") then
      self.message = nil
    end
    return
  end

  if self.phase == "list" then
    if input:wasPressed("up") then
      self:step(-1)
    elseif input:wasPressed("down") then
      self:step(1)
    elseif input:wasPressed("left") then
      self:page(-1)
    elseif input:wasPressed("right") then
      self:page(1)
    elseif input:wasPressed("a") then
      self:beginPurchase()
    elseif input:wasPressed("select") then
      if self:selected() then self.phase = "details" end
    elseif input:wasPressed("b") then
      self:close()
    end
    return
  end

  if self.phase == "details" then
    if input:wasPressed("select") or input:wasPressed("a")
        or input:wasPressed("b") then
      self.phase = "list"
    elseif input:wasPressed("up") then
      self:step(-1)
    elseif input:wasPressed("down") then
      self:step(1)
    elseif input:wasPressed("left") then
      self:page(-1)
    elseif input:wasPressed("right") then
      self:page(1)
    end
    return
  end

  if self.phase == "quantity" then
    if input:wasPressed("up") then
      self:quantityStep(1)
    elseif input:wasPressed("down") then
      self:quantityStep(-1)
    elseif input:wasPressed("right") then
      self:quantityStep(10)
    elseif input:wasPressed("left") then
      self:quantityStep(-10)
    elseif input:wasPressed("a") then
      self:beginConfirm()
    elseif input:wasPressed("b") then
      self.phase = "list"
    end
    return
  end

  if self.phase == "confirm" then
    if input:wasPressed("up") or input:wasPressed("down") then
      self.choice = self.choice == 1 and 2 or 1
    elseif input:wasPressed("b") then
      self.phase = "list"
    elseif input:wasPressed("a") then
      if self.choice == 1 then
        self:finishPurchase()
      else
        self.phase = "list"
      end
    end
  end
end

local function footerLines(self)
  if self.message then
    local a, b = self.message:match("^(.-)\n(.*)$")
    return a or self.message, b or ""
  end

  local machine = self:selected()
  if not machine then return "No machines found.", "B: BACK" end

  if self.phase == "quantity" then
    return ("HOW MANY? x%02d"):format(self.qty), "A: OK   B: CANCEL"
  end
  if self.phase == "confirm" then
    local marker = self.choice == 1 and ">YES    NO" or " YES   >NO"
    return ("%s x%d - FREE"):format(machine.itemName, self.qty), marker
  end
  return ("OWNED x%d"):format(self:owned(machine)), "A: BUY SELECT: INFO"
end

local SPECIAL_TYPES = {
  FIRE = true, WATER = true, GRASS = true, ELECTRIC = true,
  PSYCHIC = true, ICE = true, DRAGON = true, DARK = true,
}

local function moveCategory(move)
  local t = tostring(move and move.type or ""):upper()
  if t == "" then return "-" end
  return SPECIAL_TYPES[t] and "SPECIAL" or "PHYSICAL"
end

local function statText(value, zeroMeansDash, suffix)
  local n = tonumber(value)
  if n == nil then return "-" end
  if zeroMeansDash and n == 0 then return "-" end
  if math.floor(n) == n then n = math.floor(n) end
  return tostring(n) .. (suffix or "")
end

local function cleanDescription(text)
  text = tostring(text or "")
  text = text:gsub("<NEXT>", " "):gsub("[\n\v\f]", " ")
  text = text:gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  return text
end

local function wrapWords(text, width, maxLines)
  local lines, line = {}, ""
  for word in cleanDescription(text):gmatch("%S+") do
    local candidate = line == "" and word or (line .. " " .. word)
    if #candidate <= width then
      line = candidate
    else
      if line ~= "" then lines[#lines + 1] = line end
      line = word
      if #lines >= maxLines then break end
    end
  end
  if #lines < maxLines and line ~= "" then lines[#lines + 1] = line end
  if #lines == 0 then lines[1] = "No description." end
  return lines
end

function FreeTMShop:drawDetails()
  local machine = self:selected()
  if not machine then self.phase = "list" return end
  local data = self.game and self.game.data or {}
  local move = data.moves and data.moves[machine.move] or {}
  local name = move.name or tostring(machine.move or "?")
  local effect = move.effect
  if effect == nil or effect == "" then effect = "-" end
  effect = tostring(effect):gsub("_", " ")
  if #effect > 18 then effect = effect:sub(1, 18) end

  Chrome.clear()
  Chrome.box(0, 0, 20, 18)
  local title = (machine.itemName or "TM/HM") .. " " .. name
  if #title > 18 then title = title:sub(1, 18) end
  Chrome.print(title, 1, 1)
  Chrome.print("TYPE " .. tostring(move.type or "-"), 1, 3)
  Chrome.print("CLASS " .. moveCategory(move), 1, 4)
  Chrome.print("POWER " .. statText(move.power, true), 1, 5)
  Chrome.print("ACCURACY " .. statText(move.accuracy, true, "%"), 1, 6)
  Chrome.print("PP " .. statText(move.pp, false), 1, 7)
  Chrome.print("EFFECT " .. effect, 1, 8)
  Chrome.print("CHANCE " .. statText(move.effectChance, true, "%"), 1, 9)
  Chrome.print("DESCRIPTION", 1, 11)
  local lines = wrapWords(move.description, 18, 3)
  for i, line in ipairs(lines) do Chrome.print(line, 1, 11 + i) end
  Chrome.print("SELECT/A/B: BACK", 1, 16)
  love.graphics.setColor(1, 1, 1, 1)
end

function FreeTMShop:drawPanel()
  if self.phase == "details" then return self:drawDetails() end
  Chrome.clear()
  Chrome.box(0, 0, 20, 13)
  Chrome.print("TM/HM SHOP", 2, 1)
  Chrome.printRight(("%d/%d"):format(self.index, #self.rows), 18, 1)

  for row = 1, VISIBLE_ROWS do
    local i = self.scroll + row
    local machine = self.rows[i]
    if machine then
      local ty = 2 + row
      if i == self.index then Chrome.cursor(1, ty) end
      Chrome.print(tmLabel(self.game and self.game.data, machine), 2, ty)
    end
  end

  Chrome.box(0, 12, 20, 6)
  local line1, line2 = footerLines(self)
  Chrome.print(line1 or "", 1, 14)
  Chrome.print(line2 or "", 1, 16)
  love.graphics.setColor(1, 1, 1, 1)
end

function FreeTMShop:draw()
  self:drawPanel()
end

function FreeTMShop:drawWidescreen(winW, winH)
  local G = love.graphics
  if type(Chrome.letterbox) ~= "function"
      or type(Chrome.fitScale) ~= "function"
      or type(Chrome.fitOrigin) ~= "function" then
    return self:drawPanel()
  end
  Chrome.letterbox(winW, winH, 1, 1, 1)
  local scale = Chrome.fitScale(winW, winH)
  G.push()
  G.translate(Chrome.fitOrigin(winW, winH, scale))
  G.scale(scale, scale)
  self:drawPanel()
  G.pop()
end

-- ========================================================================
-- Outer mart chooser. The blocking Gen 2 pokemart command owns this state
-- until LEAVE/B closes it. NORMAL SHOP pushes the native MartMenu temporarily
-- and comes back here when the clerk finishes.
-- ========================================================================

local ShopChooser = {}
ShopChooser.__index = ShopChooser
ShopChooser.isOpaque = false

local CHOICES = { "NORMAL SHOP", "TM/HM SHOP", "LEAVE" }

function ShopChooser.new(game, opts)
  opts = opts or {}
  local self = setmetatable({}, ShopChooser)
  self.game = game
  self.opts = opts
  self.onClose = opts.onClose
  self.index = 1
  self.screenId = "AllTmShopGen2Chooser"
  return self
end

function ShopChooser:wantsFillScale() return true end

function ShopChooser:close()
  if self.onClose then self.onClose() end
end

function ShopChooser:openNormal()
  local game = self.game
  if not (game and game.stack) then return end
  local opts = {}
  for k, v in pairs(self.opts or {}) do opts[k] = v end
  local marts = opts.marts or (game.data and game.data.gen2Marts)
  opts.marts = filteredMarts(game.data, marts, opts.martId)

  local child
  opts.onClose = function()
    popTop(game, child)
  end
  child = VanillaMartMenu.new(game, opts)
  child.screenId = "Gen2MartMenu"
  game.stack:push(child)
end

function ShopChooser:openTMShop()
  local game = self.game
  if not (game and game.stack) then return end
  local child
  child = FreeTMShop.new(game, {
    save = self.opts.save or game.save,
    onClose = function() popTop(game, child) end,
  })
  game.stack:push(child)
end

function ShopChooser:update(_dt)
  local input = self.game and self.game.input
  if not input then return end
  if input:wasPressed("up") then
    self.index = self.index > 1 and self.index - 1 or #CHOICES
  elseif input:wasPressed("down") then
    self.index = self.index < #CHOICES and self.index + 1 or 1
  elseif input:wasPressed("b") then
    self:close()
  elseif input:wasPressed("a") then
    if self.index == 1 then
      self:openNormal()
    elseif self.index == 2 then
      self:openTMShop()
    else
      self:close()
    end
  end
end

function ShopChooser:drawPanel()
  Chrome.box(0, 0, 16, 9)
  Chrome.print("MART", 2, 1)
  for i, label in ipairs(CHOICES) do
    local ty = i * 2
    if i == self.index then Chrome.cursor(1, ty) end
    Chrome.print(label, 2, ty)
  end
  love.graphics.setColor(1, 1, 1, 1)
end

function ShopChooser:draw()
  self:drawPanel()
end

return function(mod)
  -- Every TM/HM in the dedicated catalogue is free. TMs are sellable in the
  -- native mart, so price zero also prevents a free-machine money loop. HMs
  -- are normally non-tossable/non-sellable, but zeroing them keeps the data
  -- contract consistent with the catalogue.
  local patched, tmCount, hmCount = 0, 0, 0
  for id, def in mod.content.items:each() do
    local kind = machineInfo(def)
    if kind then
      mod.content.items:patch(id, { price = 0 })
      patched = patched + 1
      if kind == "TM" then tmCount = tmCount + 1 else hmCount = hmCount + 1 end
    end
  end

  -- Gen 2 pokemart scripts push Gen2MartMenu, not Gen 1's ShopMenu.
  mod.content.screens:register("Gen2MartMenu", { new = ShopChooser.new })

  mod.exports.listTMs = discoverTMs
  mod.exports.listMachines = discoverMachines
  mod.exports.listHMs = discoverHMs
  mod.exports.normalStock = normalStock
  mod.exports.machineInfo = machineInfo
  mod.exports.filteredMarts = filteredMarts
  mod.exports.machineCount = patched
  mod.exports.tmCount = tmCount
  mod.exports.hmCount = hmCount
  mod.exports.numTMs = NUM_TMS
  mod.exports.numHMs = NUM_HMS
  mod.exports.FreeTMShop = FreeTMShop
  mod.exports.ShopChooser = ShopChooser
end
