local pushed = {}

local Bag = {}
function Bag.add(save, id, qty)
  local nextValue = (save.inventory[id] or 0) + qty
  if nextValue > 99 then return false end
  save.inventory[id] = nextValue
  return true
end
package.preload["src.inventory.Bag"] = function() return Bag end

local Chrome = setmetatable({}, { __index = function() return function() end end })
package.preload["src.ui.gen2.Chrome"] = function() return Chrome end
package.preload["src.core.Sound"] = function()
  return { play = function() end }
end

local NativeMart = {}
function NativeMart.new(game, opts)
  return { class = "Gen2MartMenu", game = game, opts = opts }
end
package.preload["src.ui.gen2.MartMenu"] = function() return NativeMart end

local items = { POTION = { name = "POTION", pocket = "ITEM", price = 300 } }
local moves = {}
for i = 1, 50 do
  local id = ("TM_MOVE_%02d"):format(i)
  local move = ("MOVE_%02d"):format(i)
  items[id] = {
    id = id,
    name = ("TM%02d"):format(i),
    tmLabel = ("TM%02d"):format(i),
    pocket = "TM_HM",
    tmNumber = i,
    teaches = move,
    price = i * 100,
  }
  moves[move] = {
    name = ("MOVE %02d"):format(i), type = "NORMAL", power = 50,
    accuracy = 95, pp = 20, effect = "NORMAL_HIT", effectChance = 0,
    description = "A test move used to verify the SELECT information panel.",
  }
end
for i = 1, 7 do
  local id = ("HM_%02d"):format(i)
  local move = ("HM_MOVE_%02d"):format(i)
  items[id] = {
    id = id,
    name = ("HM%02d"):format(i),
    tmLabel = ("HM%02d"):format(i),
    pocket = "TM_HM",
    tmNumber = 50 + i,
    teaches = move,
    canToss = false,
    price = 5000,
  }
  moves[move] = {
    name = ("HM MOVE %02d"):format(i), type = "WATER", power = 80,
    accuracy = 100, pp = 15, effect = "NORMAL_HIT", effectChance = 0,
    description = "Reusable hidden machine move.",
  }
end

local itemRegistry = { patches = {} }
function itemRegistry:each() return next, items, nil end
function itemRegistry:patch(id, patch)
  self.patches[id] = patch
  for k, v in pairs(patch) do items[id][k] = v end
end
local screens = { values = {} }
function screens:register(id, value) self.values[id] = value end

local mod = {
  content = { items = itemRegistry, screens = screens },
  exports = {},
}

local chunk, err = loadfile("main.lua")
assert(chunk, err)
chunk()(mod)

assert(mod.exports.tmCount == 50)
assert(mod.exports.hmCount == 7)
assert(mod.exports.machineCount == 57)
assert(mod.exports.numTMs == 50)
assert(mod.exports.numHMs == 7)
assert(items.TM_MOVE_01.price == 0 and items.TM_MOVE_50.price == 0)
assert(items.HM_01.price == 0 and items.HM_07.price == 0)
assert(itemRegistry.patches.HM_01 ~= nil)

local tms = mod.exports.listTMs({ items = items, moves = moves })
local hms = mod.exports.listHMs({ items = items, moves = moves })
local machines = mod.exports.listMachines({ items = items, moves = moves })
assert(#tms == 50 and #hms == 7 and #machines == 57)
assert(machines[1].kind == "TM" and machines[1].number == 1)
assert(machines[50].kind == "TM" and machines[50].number == 50)
assert(machines[51].kind == "HM" and machines[51].number == 1)
assert(machines[57].kind == "HM" and machines[57].number == 7)

local stock = mod.exports.normalStock({ items = items },
  { "POTION", "TM_MOVE_01", "HM_01", "TM_MOVE_50" })
assert(#stock == 1 and stock[1] == "POTION")

local marts = { lists = { { "POTION", "TM_MOVE_01", "HM_01" } } }
local filtered = mod.exports.filteredMarts({ items = items }, marts, 0)
assert(#filtered.lists[1] == 1 and filtered.lists[1][1] == "POTION")
assert(#marts.lists[1] == 3) -- source was not mutated

assert(screens.values.Gen2MartMenu)

local input = { pressed = {} }
function input:wasPressed(k) return self.pressed[k] == true end
local stack = {
  values = {},
  push = function(self, obj) self.values[#self.values + 1] = obj; pushed[#pushed + 1] = obj end,
  pop = function(self) table.remove(self.values) end,
  top = function(self) return self.values[#self.values] end,
}
local game = {
  data = { items = items, moves = moves, gen2Marts = marts },
  save = { inventory = {}, money = 0 },
  input = input,
  stack = stack,
}

local chooser = screens.values.Gen2MartMenu.new(game, {
  save = game.save, marts = marts, martType = 0, martId = 0,
  onClose = function() end,
})
assert(chooser.screenId == "AllTmShopGen2Chooser")
chooser:openNormal()
assert(pushed[#pushed].class == "Gen2MartMenu")
assert(#pushed[#pushed].opts.marts.lists[1] == 1)
stack:pop()

chooser:openTMShop()
local shop = pushed[#pushed]
assert(shop.screenId == "AllTmShopGen2Catalogue")
assert(#shop.rows == 57)
assert(shop.rows[1].kind == "TM" and shop.rows[50].kind == "TM")
assert(shop.rows[51].kind == "HM" and shop.rows[57].kind == "HM")

-- SELECT opens move details; SELECT/A/B returns to the list.
input.pressed = { select = true }
shop:update(0)
assert(shop.phase == "details")
input.pressed = { select = true }
shop:update(0)
assert(shop.phase == "list")
input.pressed = {}

-- TMs keep quantity purchasing.
shop.index = 1
shop:beginPurchase()
assert(shop.phase == "quantity" and shop.qtyMax == 99)
shop.qty = 3
shop:beginConfirm()
shop:finishPurchase()
assert(game.save.inventory.TM_MOVE_01 == 3)
assert(shop.phase == "list")

-- HMs are offered, but only one reusable copy can be bought.
shop.index = 51
shop:beginPurchase()
assert(shop.phase == "quantity" and shop.qtyMax == 1 and shop.qty == 1)
shop:beginConfirm()
shop:finishPurchase()
assert(game.save.inventory.HM_01 == 1)
shop.message = nil
shop:beginPurchase()
assert(shop.message and shop.message:find("already have", 1, true))

print("all_tm_shop_gen2_test: ok")
