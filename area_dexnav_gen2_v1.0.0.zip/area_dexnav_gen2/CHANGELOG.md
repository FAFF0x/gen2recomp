# Changelog

## 1.0.0
- Native Gold/Silver/Crystal port of Area DexNav.
- SELECT activation in the Gen 2 overworld.
- Uses Gen 2 grass encounter tables by MORN/DAY/NITE.
- Uses water encounters while SURFing.
- Preserves Gen 2 30/30/20/10/5/4/1 grass slot weights.
- Preserves Gen 2 60/30/10 water slot weights.
- Supports active swarms through the world's live wild tables.
- Supports Bug-Catching Contest encounters and Contest battle mode.
- Uses `save.pokedex.caught` to filter already-caught species.
- Preserves Ruins of Alph Unown unlock/form rules.
- SELECT intentionally replaces the registered-item shortcut while enabled.
