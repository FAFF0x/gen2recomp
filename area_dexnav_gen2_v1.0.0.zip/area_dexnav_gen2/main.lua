-- Area DexNav Gen 2
-- Press SELECT in the overworld to encounter an uncaught species from the
-- current Gold/Silver/Crystal encounter table.

local Encounter = require("src.battle.gen2.Encounter")
local Mon = require("src.battle.gen2.Mon")
local Unown = require("src.core.gen2.Unown")
local BugContest = require("src.core.gen2.BugContest")
local FieldMoves = require("src.world.gen2.FieldMoves")
local Strings = require("src.core.Strings")

local PATCH_KEY = "__area_dexnav_gen2_select_dispatch_v1"

local function isCaught(game, species)
  local dex = game and game.save and game.save.pokedex
  if not dex then return false end
  if dex.caught and dex.caught[species] == true then return true end
  -- Compatibility with very old/pre-Gen2-shaped saves.
  return dex.owned and dex.owned[species] == true or false
end

local function validSpecies(game, species)
  return species ~= nil and game and game.data and game.data.pokemon
    and game.data.pokemon[species] ~= nil
end

local function currentDaytime(world)
  local tod = (world and (world.tod or world.daytime)) or "DAY"
  if tod == "DARK" then return "NITE" end
  if tod ~= "MORN" and tod ~= "DAY" and tod ~= "NITE" then return "DAY" end
  return tod
end

local function canMeetUnown(world)
  if not world then return false end
  if type(world.unownUnlockFlags) ~= "function" then return true end
  local flags = world:unownUnlockFlags()
  return Unown.anyUnlocked(flags)
end

local function addSlot(rows, game, world, slot, weight, source)
  if type(slot) ~= "table" then return end
  local species = slot.species
  local level = tonumber(slot.level)
  weight = tonumber(weight) or 0
  if not (validSpecies(game, species) and level and weight > 0) then return end
  if isCaught(game, species) then return end
  if species == Unown.SPECIES and not canMeetUnown(world) then return end
  rows[#rows + 1] = {
    species = species,
    level = math.max(1, math.floor(level)),
    weight = weight,
    source = source,
  }
end

local function normalCandidates(game, world)
  local map = world and world.map
  local mapId = map and map.id
  if not (mapId and world) then return {}, nil, mapId, "no_encounters" end
  if world.noWildEncounters then return {}, nil, mapId, "no_encounters" end

  local tables
  if type(world.wildTables) == "function" then
    tables = world:wildTables()
  end
  tables = tables or world.encounters or (game and game.data and game.data.encounters)
  if type(tables) ~= "table" then
    return {}, nil, mapId, "no_encounters"
  end

  local rows = {}
  local surfing = FieldMoves.isSurfing(world.playerState)
  if surfing then
    local entry = tables.water and tables.water[mapId]
    if not (entry and (tonumber(entry.rate) or 0) > 0 and entry.slots) then
      return rows, "water", mapId, "no_encounters"
    end
    local previous = 0
    for index, slot in ipairs(entry.slots) do
      local cumulative = Encounter.WATER_SLOT_CHANCES[index]
      local weight = cumulative and math.max(0, cumulative - previous) or 1
      if cumulative then previous = cumulative end
      addSlot(rows, game, world, slot, weight, "water")
    end
    return rows, "water", mapId, (#rows > 0 and nil or "complete")
  end

  local entry = tables.grass and tables.grass[mapId]
  local daytime = currentDaytime(world)
  local rate = entry and entry.rates
    and (entry.rates[daytime] or entry.rates.DAY) or 0
  local slots = entry and entry.slots
    and (entry.slots[daytime] or entry.slots.DAY)
  if not (entry and (tonumber(rate) or 0) > 0 and slots) then
    return rows, "grass", mapId, "no_encounters"
  end

  local previous = 0
  for index, slot in ipairs(slots) do
    local cumulative = Encounter.GRASS_SLOT_CHANCES[index]
    local weight = cumulative and math.max(0, cumulative - previous) or 1
    if cumulative then previous = cumulative end
    addSlot(rows, game, world, slot, weight, "grass")
  end
  return rows, "grass", mapId, (#rows > 0 and nil or "complete")
end

-- During the Bug-Catching Contest the cart does not use National Park's
-- ordinary grass table. Preserve that special table and battle mode.
local function contestCandidates(game, world)
  local rows = {}
  local source = BugContest.contestMons(game and game.data)
  local remaining = 100
  for _, slot in ipairs(source or {}) do
    if remaining <= 0 then break end
    local weight = math.min(math.max(0, tonumber(slot.chance) or 0), remaining)
    remaining = remaining - weight
    local species = slot.species
    if validSpecies(game, species) and not isCaught(game, species) and weight > 0 then
      rows[#rows + 1] = {
        species = species,
        min = math.max(1, math.floor(tonumber(slot.min) or 1)),
        max = math.max(1, math.floor(tonumber(slot.max) or slot.min or 1)),
        weight = weight,
        source = "contest",
      }
    end
  end
  return rows, "contest", world and world.map and world.map.id,
    (#rows > 0 and nil or "complete")
end

local function candidates(game, world)
  if game and game.save and BugContest.isActive(game.save) then
    return contestCandidates(game, world)
  end
  return normalCandidates(game, world)
end

local function randomInt(rng, low, high)
  if high < low then high = low end
  if rng then return rng(low, high) end
  if love and love.math and love.math.random then
    return love.math.random(low, high)
  end
  return math.random(low, high)
end

local function pickTarget(game, world, rng)
  local rows, terrain, mapId, reason = candidates(game, world)
  if #rows == 0 then return nil, reason, terrain, mapId end

  local total = 0
  for _, row in ipairs(rows) do total = total + (row.weight or 0) end
  if total <= 0 then return nil, "no_encounters", terrain, mapId end

  local roll = randomInt(rng, 1, total)
  local chosen = rows[#rows]
  for _, row in ipairs(rows) do
    roll = roll - row.weight
    if roll <= 0 then chosen = row break end
  end

  local level = chosen.level
  if not level then
    level = randomInt(rng, chosen.min or 1, chosen.max or chosen.min or 1)
  end
  return {
    species = chosen.species,
    level = level,
    source = chosen.source,
  }, nil, terrain, mapId
end

local function hasUsableParty(game)
  for _, mon in ipairs(game and game.save and game.save.party or {}) do
    if not mon.isEgg and (tonumber(mon.hp) or 0) > 0 then return true end
  end
  return false
end

local function say(game, text)
  if game and game.say then game:say(Strings(text)) end
end

local function makeWild(game, world, target)
  local opts
  if target.species == Unown.SPECIES
      and world and type(world.unownUnlockFlags) == "function" then
    local flags = world:unownUnlockFlags()
    if not Unown.anyUnlocked(flags) then return nil end
    opts = { dvs = Unown.wildDVs(flags, Mon.randomDVs) }
  end
  return Mon.new(game.data, target.species, target.level, opts)
end

local function activate(mod, game, world)
  if not (game and world and world.map) then return false end
  if not hasUsableParty(game) then
    say(game, "Your party cannot\nbattle.")
    return true
  end

  local target, reason = pickTarget(game, world)
  if not target then
    if reason == "complete" then
      say(game, "All POKéMON in\nthis area have\nbeen caught!")
    else
      say(game, "No wild POKéMON\nfound here.")
    end
    return true
  end

  local wild = makeWild(game, world, target)
  if not wild then
    say(game, "No wild POKéMON\nfound here.")
    return true
  end

  game.save.pokedex = game.save.pokedex or { seen = {}, caught = {} }
  game.save.pokedex.seen = game.save.pokedex.seen or {}
  game.save.pokedex.caught = game.save.pokedex.caught or {}
  game.save.pokedex.seen[target.species] = true

  local opts = { wild = wild }
  if target.source == "contest" then opts.contest = true end
  local ok = world:startBattle(opts)
  if not ok then
    mod.log:warn("DexNav battle could not start on %s", tostring(world.map.id))
  end
  return true
end

-- Gen 2 already owns SELECT for the registered-item shortcut. DexNav replaces
-- that action while enabled. The wrapper is shared/keyed so hot reloads replace
-- the handler instead of stacking another monkey patch every time.
local function installSelectHandler(mod, game)
  if not (game and type(game.useSelectItem) == "function") then
    mod.log:warn("Gen 2 SELECT handler unavailable")
    return
  end

  local patch = rawget(game, PATCH_KEY)
  if not patch then
    patch = { original = game.useSelectItem, handlers = {} }
    rawset(game, PATCH_KEY, patch)
    game.useSelectItem = function(self, ...)
      local live = rawget(self, PATCH_KEY)
      if live then
        local ids = {}
        for id in pairs(live.handlers) do ids[#ids + 1] = id end
        table.sort(ids)
        for _, id in ipairs(ids) do
          local entry = live.handlers[id]
          if entry and entry.fn then
            local ok, handled = pcall(entry.fn, self)
            if not ok then
              if entry.onError then entry.onError(handled) end
            elseif handled then
              return
            end
          end
        end
        return live.original(self, ...)
      end
    end
  end

  patch.handlers[mod.id] = {
    fn = function(liveGame)
      local world = liveGame and liveGame.world
      if not (world and world.map) then return false end
      if type(world.acceptsMenuInput) == "function"
          and not world:acceptsMenuInput() then return false end
      return activate(mod, liveGame, world)
    end,
    onError = function(err)
      mod.log:error("DexNav SELECT handler failed: %s", tostring(err))
    end,
  }
end

return function(mod)
  mod.exports.candidates = candidates
  mod.exports.pickTarget = pickTarget
  mod.exports.activate = function(game, world)
    return activate(mod, game, world)
  end

  mod.events:on("game.ready", function(payload)
    local game = payload and payload.game
    if game then installSelectHandler(mod, game) end
  end)

  mod.log:info("Area DexNav Gen 2 loaded")
end
