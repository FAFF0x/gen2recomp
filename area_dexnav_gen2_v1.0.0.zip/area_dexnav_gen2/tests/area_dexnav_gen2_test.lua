local script = (arg and arg[0]) or "tests/area_dexnav_gen2_test.lua"
local root = script:match("^(.*)[/\\]") or "tests"
local mainPath = root .. "/../main.lua"

package.preload["src.battle.gen2.Encounter"] = function()
  return {
    GRASS_SLOT_CHANCES = {30,60,80,90,95,99,100},
    WATER_SLOT_CHANCES = {60,90,100},
  }
end
package.preload["src.battle.gen2.Mon"] = function()
  return {
    randomDVs = function() return {} end,
    new = function(_, species, level, opts)
      return { species = species, level = level, hp = 10, opts = opts }
    end,
  }
end
package.preload["src.core.gen2.Unown"] = function()
  return {
    SPECIES = "UNOWN",
    anyUnlocked = function(flags) return flags and flags.any == true end,
    wildDVs = function() return { attack = 15 } end,
  }
end
package.preload["src.core.gen2.BugContest"] = function()
  return {
    isActive = function(save) return save and save.bugContest == true end,
    contestMons = function()
      return {
        { chance=70, species="CATERPIE", min=7, max=8 },
        { chance=30, species="PINSIR", min=13, max=14 },
        { chance=255, species="VENOMOTH", min=30, max=40 },
      }
    end,
  }
end
package.preload["src.world.gen2.FieldMoves"] = function()
  return { isSurfing = function(state) return state == "SURF" end }
end
package.preload["src.core.Strings"] = function()
  return function(s) return s end
end

local init = assert(loadfile(mainPath))()
local ready
local logs = {}
local mod = {
  id = "area_dexnav_gen2",
  exports = {},
  events = { on = function(_, name, fn) if name == "game.ready" then ready = fn end end },
  log = {
    info = function(_, s) logs[#logs+1] = s end,
    warn = function(_, s) logs[#logs+1] = s end,
    error = function(_, s) logs[#logs+1] = s end,
  },
}
init(mod)
assert(type(ready) == "function", "game.ready handler registered")

local pokemon = {
  PIDGEY={}, HOOTHOOT={}, RATTATA={}, TENTACOOL={}, MAGIKARP={},
  CATERPIE={}, PINSIR={}, VENOMOTH={}, UNOWN={},
}
local encounters = {
  grass = {
    ROUTE_29 = {
      rates = { MORN=20, DAY=20, NITE=20 },
      slots = {
        MORN = {
          {species="PIDGEY",level=2},{species="PIDGEY",level=2},
          {species="RATTATA",level=3},{species="RATTATA",level=3},
          {species="PIDGEY",level=3},{species="RATTATA",level=4},
          {species="PIDGEY",level=4},
        },
        DAY = {
          {species="PIDGEY",level=2},{species="PIDGEY",level=2},
          {species="RATTATA",level=3},{species="RATTATA",level=3},
          {species="PIDGEY",level=3},{species="RATTATA",level=4},
          {species="PIDGEY",level=4},
        },
        NITE = {
          {species="HOOTHOOT",level=2},{species="HOOTHOOT",level=2},
          {species="RATTATA",level=3},{species="RATTATA",level=3},
          {species="HOOTHOOT",level=3},{species="RATTATA",level=4},
          {species="HOOTHOOT",level=4},
        },
      },
    },
  },
  water = {
    ROUTE_29 = { rate=20, slots={
      {species="TENTACOOL",level=10},
      {species="TENTACOOL",level=15},
      {species="MAGIKARP",level=20},
    }},
  },
}

local game = {
  data = { pokemon=pokemon, encounters=encounters },
  save = { party={{species="CYNDAQUIL",hp=10}}, pokedex={seen={},caught={RATTATA=true}} },
  originalSelect = 0,
  useSelectItem = function(self) self.originalSelect = self.originalSelect + 1 end,
  said = nil,
  say = function(self, s) self.said = s end,
}
local world = {
  game=game, map={id="ROUTE_29"}, playerState="NORMAL", tod="NITE",
  encounters=encounters, noWildEncounters=false, started=nil,
  acceptsMenuInput=function() return true end,
  wildTables=function(self) return self.encounters end,
  unownUnlockFlags=function() return {any=true} end,
  startBattle=function(self, opts) self.started=opts return true end,
}
game.world = world
ready({game=game})

-- Night table + caught filtering: only HOOTHOOT remains.
local rows, terrain = mod.exports.candidates(game, world)
assert(terrain == "grass", "land uses grass table")
assert(#rows == 4, "four Hoothoot slots survive caught Rattata filtering")
for _, row in ipairs(rows) do assert(row.species == "HOOTHOOT") end

-- SELECT starts DexNav instead of the registered item.
game:useSelectItem()
assert(game.originalSelect == 0, "registered SELECT item is replaced")
assert(world.started and world.started.wild.species == "HOOTHOOT", "night target starts battle")
assert(game.save.pokedex.seen.HOOTHOOT == true, "target is marked seen")

-- Surfing exclusively uses water; after Tentacool is caught only Magikarp remains.
world.started=nil
world.playerState="SURF"
game.save.pokedex.caught.TENTACOOL=true
local waterRows, waterTerrain = mod.exports.candidates(game, world)
assert(waterTerrain == "water", "surf uses water table")
assert(#waterRows == 1 and waterRows[1].species == "MAGIKARP", "water caught filter")

-- Live/swarm table is used instead of the raw cache.
world.playerState="NORMAL"
world.tod="DAY"
world.wildTables=function()
  return {grass={ROUTE_29={rates={DAY=20},slots={DAY={
    {species="HOOTHOOT",level=6},{species="HOOTHOOT",level=6},
    {species="HOOTHOOT",level=6},{species="HOOTHOOT",level=6},
    {species="HOOTHOOT",level=6},{species="HOOTHOOT",level=6},
    {species="HOOTHOOT",level=6},
  }}}},water={}}
end
game.save.pokedex.caught.HOOTHOOT=nil
local swarmRows=mod.exports.candidates(game,world)
assert(#swarmRows==7 and swarmRows[1].level==6,"live/swarm table honored")

-- Contest sentinel row is unreachable and must not leak into DexNav weighting.
game.save.bugContest=true
game.save.pokedex.caught.CATERPIE=true
local contestRows, contestTerrain=mod.exports.candidates(game,world)
assert(contestTerrain=="contest","contest table selected")
assert(#contestRows==1 and contestRows[1].species=="PINSIR","contest unreachable sentinel excluded")
local target=mod.exports.pickTarget(game,world,function(a,b) return a end)
assert(target.species=="PINSIR" and target.level==13,"contest level range preserved")

game.save.bugContest=nil
print("area_dexnav_gen2_test: ok")
