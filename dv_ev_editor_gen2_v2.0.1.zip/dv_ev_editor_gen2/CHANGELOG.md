# Changelog

## 2.0.1

- Separates the final **Sp. Atk** and **Sp. Def** readouts instead of compressing them into one `SpA / SpD` field.
- Adds dedicated read-only **SP. ATK STAT** and **SP. DEF STAT** rows to the Gen2 Modern UI adapter.
- Keeps the real Gen 2 model intact: one shared Special DV and one shared Special Stat EXP word.
- Reworks the native 20x18 editor layout so the two Special stats remain readable without overlapping edit controls.
- Prevents Modern UI clicks on the read-only Special-stat rows from accidentally starting an edit on the previous row.

## 2.0.0

- Native Generation II port for Gold, Silver and Crystal.
- Adds `DV/EV` after `STATS` in the normal Gen 2 party submenu.
- Uses `src.battle.gen2.Mon` for Gen 2 DV, Stat EXP and stat recalculation rules.
- Correctly models one shared Special DV and one shared Special Stat EXP word for Sp. Atk / Sp. Def.
- Preserves derived HP DV behavior.
- Preserves missing HP when recalculating stats; fainted Pokémon remain fainted.
- Keeps the v1.1.0 START shortcut to maximize all DVs and Stat EXP.
- Excludes the editor from battle party submenus.
- Adds optional `gen2_modern_ui` adapter support.
