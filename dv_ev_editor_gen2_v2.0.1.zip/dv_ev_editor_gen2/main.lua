-- DV EV Editor Gen 2 v2.0.1 for Gen1Recomp / Gen2Recomp
-- Adds a DV/EV page to the out-of-battle Gen 2 Pokemon party submenu.
-- Generation II uses four editable DVs (HP is derived) and five Stat EXP words.

local Mon = require("src.battle.gen2.Mon")
local Chrome = require("src.ui.gen2.Chrome")
local Font = require("src.render.Font")

local DV_ROWS = {
  { key = "attack",  label = "ATK" },
  { key = "defense", label = "DEF" },
  { key = "speed",   label = "SPD" },
  { key = "special", label = "SPC" },
}

-- Gen 2 still stores only five Stat EXP words. Special Attack and Special
-- Defense share the same Special Stat EXP word just as they share one DV.
local STAT_EXP_ROWS = {
  { key = "hp",      label = "HP"  },
  { key = "attack",  label = "ATK" },
  { key = "defense", label = "DEF" },
  { key = "speed",   label = "SPD" },
  { key = "special", label = "SPC" },
}

local function clampInteger(value, minimum, maximum)
  value = math.floor(tonumber(value) or minimum)
  if value < minimum then return minimum end
  if value > maximum then return maximum end
  return value
end

local function effectiveEv(statExp)
  -- CalcStat searches for the smallest root whose square is >= Stat EXP,
  -- then divides it by four. This is the cart's effective 0..63 term.
  local root = math.min(255,
    math.ceil(math.sqrt(clampInteger(statExp, 0, Mon.MAX_STAT_EXP or 65535))))
  return math.floor(root / 4)
end

local function ensureMon(game, mon)
  if type(mon) ~= "table" then return false end
  mon.dvs = mon.dvs or {}
  -- Old/cross-generation records sometimes use specialAttack/specialDefense.
  if mon.dvs.special == nil then
    mon.dvs.special = mon.dvs.specialAttack or mon.dvs.specialDefense
  end
  for _, row in ipairs(DV_ROWS) do
    mon.dvs[row.key] = clampInteger(mon.dvs[row.key], 0, Mon.MAX_DV or 15)
  end
  mon.dvs.hp = Mon.hpDV(mon.dvs)

  mon.statExp = mon.statExp or {}
  if mon.statExp.special == nil then
    mon.statExp.special = clampInteger(
      mon.statExp.specialAttack or mon.statExp.specialDefense, 0,
      Mon.MAX_STAT_EXP or 65535)
  end
  for _, row in ipairs(STAT_EXP_ROWS) do
    mon.statExp[row.key] = clampInteger(mon.statExp[row.key], 0,
      Mon.MAX_STAT_EXP or 65535)
  end

  return true
end

local function recalculate(game, mon)
  if not ensureMon(game, mon) then return end
  local data = game and game.data
  local def = data and data.pokemon and data.pokemon[mon.species]
  if not (def and def.baseStats) then return end
  if not mon.stats then Mon.refreshStats(mon, data) end

  local oldMax = (mon.maxHp or (mon.stats and mon.stats.hp) or 1)
  local oldHp = clampInteger(mon.hp, 0, oldMax)
  local missing = math.max(0, oldMax - oldHp)

  mon.dvs.hp = Mon.hpDV(mon.dvs)
  if Mon.syncIdentity then Mon.syncIdentity(mon, data) end
  local stats = Mon.stats(def.baseStats, mon.dvs, mon.level or 1, mon.statExp)
  mon.stats = stats
  mon.maxHp = stats.hp

  -- Preserve missing HP like the original editor. A fainted mon stays fainted.
  if oldHp <= 0 then
    mon.hp = 0
  else
    mon.hp = math.max(1, math.min(stats.hp, stats.hp - missing))
  end
end

local function maximizeDvEv(game, mon)
  if not ensureMon(game, mon) then return end
  for _, row in ipairs(DV_ROWS) do mon.dvs[row.key] = Mon.MAX_DV or 15 end
  mon.dvs.hp = Mon.hpDV(mon.dvs)
  for _, row in ipairs(STAT_EXP_ROWS) do
    mon.statExp[row.key] = Mon.MAX_STAT_EXP or 65535
  end
  recalculate(game, mon)
end

local function actualStat(mon, key)
  return (mon.stats and mon.stats[key]) or 0
end

local function padded(value, width)
  return ("%0" .. tostring(width) .. "d"):format(value or 0)
end

local function monName(game, mon)
  local data = game and game.data
  local def = data and data.pokemon and data.pokemon[mon.species]
  return mon.nickname or mon.name or (def and def.name) or tostring(mon.species)
end

return function(mod)
  local Editor = {}
  Editor.__index = Editor
  Editor.isOpaque = true
  Editor.screenId = "DvEvEditorGen2"

  function Editor:wantsFillScale() return true end
  function Editor:drawsWidescreen() return true end

  function Editor.new(game, mon)
    ensureMon(game, mon)
    Mon.refreshStats(mon, game and game.data)
    return setmetatable({
      game = game,
      mon = mon,
      page = 1,
      row = 1,
      editing = false,
      editValue = 0,
      editDigit = 1,
      editWidth = 2,
      editMax = Mon.MAX_DV or 15,
      notice = nil,
      noticeFrames = 0,
    }, Editor)
  end

  function Editor:rowCount()
    return self.page == 1 and #DV_ROWS or #STAT_EXP_ROWS
  end

  function Editor:selectedRow()
    return (self.page == 1 and DV_ROWS or STAT_EXP_ROWS)[self.row]
  end

  function Editor:setPage(page)
    if page < 1 then page = 2 elseif page > 2 then page = 1 end
    self.page = page
    self.row = math.min(self.row, self:rowCount())
  end

  function Editor:startEdit()
    local row = self:selectedRow()
    if not row then return end
    if self.page == 1 then
      self.editValue = clampInteger(self.mon.dvs[row.key], 0, Mon.MAX_DV or 15)
      self.editWidth = 2
      self.editMax = Mon.MAX_DV or 15
    else
      self.editValue = clampInteger(self.mon.statExp[row.key], 0,
        Mon.MAX_STAT_EXP or 65535)
      self.editWidth = 5
      self.editMax = Mon.MAX_STAT_EXP or 65535
    end
    self.editDigit = 1
    self.editing = true
  end

  function Editor:changeDigit(delta)
    local place = 10 ^ (self.editWidth - self.editDigit)
    self.editValue = clampInteger(self.editValue + delta * place, 0, self.editMax)
  end

  function Editor:applyEdit()
    local row = self:selectedRow()
    if not row then return end
    if self.page == 1 then
      self.mon.dvs[row.key] = clampInteger(self.editValue, 0, Mon.MAX_DV or 15)
      self.mon.dvs.hp = Mon.hpDV(self.mon.dvs)
    else
      self.mon.statExp[row.key] = clampInteger(self.editValue, 0,
        Mon.MAX_STAT_EXP or 65535)
    end
    recalculate(self.game, self.mon)
    self.editing = false
  end

  function Editor:maxAll()
    maximizeDvEv(self.game, self.mon)
    self.editing = false
    self.notice = "MAX DVs + STAT EXP"
    self.noticeFrames = 132 -- about 2.2 seconds at 60 Hz
  end

  function Editor:update(_dt)
    local input = self.game and self.game.input
    if not input then return end
    if self.noticeFrames > 0 then self.noticeFrames = self.noticeFrames - 1 end

    if input:wasPressed("start") then
      self:maxAll()
      return
    end

    if self.editing then
      if input:wasPressed("left") then
        self.editDigit = self.editDigit > 1 and self.editDigit - 1 or self.editWidth
      elseif input:wasPressed("right") then
        self.editDigit = self.editDigit < self.editWidth and self.editDigit + 1 or 1
      elseif input:wasPressed("up") then
        self:changeDigit(1)
      elseif input:wasPressed("down") then
        self:changeDigit(-1)
      elseif input:wasPressed("a") then
        self:applyEdit()
      elseif input:wasPressed("b") then
        self.editing = false
      end
      return
    end

    local n = self:rowCount()
    if input:wasPressed("up") then
      self.row = self.row > 1 and self.row - 1 or n
    elseif input:wasPressed("down") then
      self.row = self.row < n and self.row + 1 or 1
    elseif input:wasPressed("left") then
      self:setPage(self.page - 1)
    elseif input:wasPressed("right") or input:wasPressed("select") then
      self:setPage(self.page + 1)
    elseif input:wasPressed("a") then
      self:startEdit()
    elseif input:wasPressed("b") then
      local stack = self.game and self.game.stack
      if stack then stack:pop() end
    end
  end

  local function drawDigitCursor(x, y, digit)
    love.graphics.rectangle("fill", x + (digit - 1) * 8, y + 7, 7, 1)
  end

  function Editor:drawHeader()
    Chrome.print("DV/EV", 1, 1)
    Chrome.print(self.page == 1 and "DVs 1/2" or "STAT EXP 2/2", 11, 1)
    Chrome.print(monName(self.game, self.mon), 1, 3)
    Chrome.print("Lv" .. tostring(self.mon.level or 1), 16, 3)
  end

  function Editor:drawDvPage()
    Chrome.print("HP DV", 2, 5)
    Chrome.printRight(padded(self.mon.dvs.hp, 2), 9, 5)
    Chrome.print("HP", 12, 5)
    Chrome.printRight(tostring(actualStat(self.mon, "hp")), 19, 5)

    for i, row in ipairs(DV_ROWS) do
      local y = 7 + (i - 1) * 2
      local value = self.mon.dvs[row.key] or 0
      if self.editing and self.row == i then value = self.editValue end
      if self.row == i then Chrome.cursor(1, y) end
      Chrome.print(row.label .. " DV", 2, y)
      Chrome.printRight(padded(value, 2), 9, y)
      if row.key == "special" then
        -- Gen 2 stores ONE Special DV, but it feeds TWO different final
        -- stats. Never squeeze them into a single "SpA / SpD" cell: that
        -- looks like one combined stat and becomes unreadable with Modern UI.
        Chrome.print("SHARED", 12, y)
      else
        local statKey = row.key
        Chrome.print("STAT", 11, y)
        Chrome.printRight(tostring(actualStat(self.mon, statKey)), 19, y)
      end
      if self.editing and self.row == i then
        drawDigitCursor(7 * 8, y * 8, self.editDigit)
      end
    end

    -- The two final Special stats are deliberately separate display lines.
    -- They share the DV above, but their base stats differ in Gen 2.
    Chrome.print("SP. ATK STAT", 2, 14)
    Chrome.printRight(tostring(actualStat(self.mon, "specialAttack")), 19, 14)
    Chrome.print("SP. DEF STAT", 2, 15)
    Chrome.printRight(tostring(actualStat(self.mon, "specialDefense")), 19, 15)
  end

  function Editor:drawStatExpPage()
    Chrome.print("RAW", 6, 5)
    Chrome.print("EV", 13, 5)
    Chrome.print("STAT", 16, 5)
    for i, row in ipairs(STAT_EXP_ROWS) do
      -- Shift the five editable rows up by one tile so the shared Special
      -- effort can still have a dedicated Sp. Atk / Sp. Def readout below.
      local y = 6 + (i - 1) * 2
      local raw = self.mon.statExp[row.key] or 0
      if self.editing and self.row == i then raw = self.editValue end
      if self.row == i then Chrome.cursor(1, y) end
      Chrome.print(row.label, 2, y)
      Chrome.print(padded(raw, 5), 6, y)
      Chrome.printRight(padded(effectiveEv(raw), 2), 14, y)
      if row.key == "special" then
        Chrome.print("S/D", 16, y)
      else
        Chrome.printRight(tostring(actualStat(self.mon, row.key)), 20, y)
      end
      if self.editing and self.row == i then
        drawDigitCursor(6 * 8, y * 8, self.editDigit)
      end
    end
    Chrome.print("SpA", 2, 15)
    Chrome.printRight(tostring(actualStat(self.mon, "specialAttack")), 9, 15)
    Chrome.print("SpD", 11, 15)
    Chrome.printRight(tostring(actualStat(self.mon, "specialDefense")), 19, 15)
  end

  function Editor:drawPanel()
    Chrome.clear()
    self:drawHeader()
    if self.page == 1 then self:drawDvPage() else self:drawStatExpPage() end
    if self.notice and self.noticeFrames > 0 then
      Chrome.print(self.notice, 1, 16)
    elseif self.editing then
      Chrome.print("L/R DIGIT U/D VALUE", 1, 16)
    else
      Chrome.print("L/R PAGE  A EDIT", 1, 16)
    end
    Chrome.print(self.editing and "A OK B CANCEL START MAX"
      or "B BACK SELECT PAGE START MAX", 1, 17)
    love.graphics.setColor(1, 1, 1, 1)
  end

  function Editor:draw()
    self:drawPanel()
  end

  function Editor:drawWidescreen(winW, winH)
    local G = love.graphics
    Chrome.letterbox(winW, winH, 1, 1, 1)
    local scale = Chrome.fitScale(winW, winH)
    local ox, oy = Chrome.fitOrigin(winW, winH, scale)
    G.push()
    G.translate(ox, oy)
    G.scale(scale, scale)
    self:drawPanel()
    G.pop()
  end

  -- Public Gen2 Modern UI adapter. The editor keeps all mutation/state logic;
  -- Modern UI may suppress only the native draw and dispatch semantic actions.
  local function modernRows(state)
    local rows = {}
    if state.page == 1 then
      rows[#rows + 1] = {
        label = "HP DV",
        value = ("%02d   HP %d"):format(state.mon.dvs.hp or 0,
          actualStat(state.mon, "hp")),
        enabled = false,
      }
      for i, row in ipairs(DV_ROWS) do
        local value = state.mon.dvs[row.key] or 0
        if state.editing and state.row == i then value = state.editValue end
        local stat
        if row.key == "special" then
          stat = "SHARED SPECIAL DV"
        else
          stat = "STAT " .. tostring(actualStat(state.mon, row.key))
        end
        local valueText = ("%02d   %s"):format(value, stat)
        if state.editing and state.row == i then
          valueText = valueText .. ("   DIGIT %d/%d"):format(
            state.editDigit or 1, state.editWidth or 2)
        end
        rows[#rows + 1] = {
          label = row.label .. " DV",
          value = valueText,
          marker = state.editing and state.row == i or nil,
          enabled = true,
        }
      end
      rows[#rows + 1] = {
        label = "SP. ATK STAT",
        value = tostring(actualStat(state.mon, "specialAttack")),
        enabled = false,
      }
      rows[#rows + 1] = {
        label = "SP. DEF STAT",
        value = tostring(actualStat(state.mon, "specialDefense")),
        enabled = false,
      }
    else
      for i, row in ipairs(STAT_EXP_ROWS) do
        local raw = state.mon.statExp[row.key] or 0
        if state.editing and state.row == i then raw = state.editValue end
        local stat = row.key == "special"
          and "SHARED SPECIAL EXP"
          or ("STAT %d"):format(actualStat(state.mon, row.key))
        local valueText = ("RAW %05d   EV %02d   %s"):format(
          raw, effectiveEv(raw), stat)
        if state.editing and state.row == i then
          valueText = valueText .. ("   DIGIT %d/%d"):format(
            state.editDigit or 1, state.editWidth or 5)
        end
        rows[#rows + 1] = {
          label = row.label,
          value = valueText,
          marker = state.editing and state.row == i or nil,
          enabled = true,
        }
      end
      rows[#rows + 1] = {
        label = "SP. ATK STAT",
        value = tostring(actualStat(state.mon, "specialAttack")),
        enabled = false,
      }
      rows[#rows + 1] = {
        label = "SP. DEF STAT",
        value = tostring(actualStat(state.mon, "specialDefense")),
        enabled = false,
      }
    end
    return rows
  end

  local function modernModel(state)
    local rows = modernRows(state)
    local index = state.page == 1 and math.min(#rows, (state.row or 1) + 1)
      or math.min(#rows, state.row or 1)
    return {
      title = (state.page == 1 and "DVs 1/2 - " or "STAT EXP 2/2 - ")
        .. monName(state.game, state.mon)
        .. (" Lv%d"):format(state.mon.level or 1),
      rows = rows,
      index = math.max(1, index),
      scroll = 0,
      footer = state.editing
        and { "L/R DIGIT", "U/D VALUE", "A OK", "B CANCEL", "START MAX ALL" }
        or { "L/R PAGE", "A EDIT", "B BACK", "START MAX ALL" },
    }
  end

  local modernUiContract = {
    apiVersion = 1,
    screens = {
      dv_ev_editor_gen2 = {
        match = function(state)
          return type(state) == "table" and state.screenId == "DvEvEditorGen2"
            and type(state.mon) == "table" and type(state.game) == "table"
        end,
        canSuppressNative = true,
        model = function(_, state) return modernModel(state) end,
        actions = {
          hover = function(_, state, index)
            index = math.floor(tonumber(index) or 0)
            if state.editing then return index > 0 end
            if state.page == 1 then
              if index < 2 or index > #DV_ROWS + 1 then return false end
              state.row = index - 1
            else
              if index < 1 or index > #STAT_EXP_ROWS then return false end
              state.row = index
            end
            return true
          end,
          select = function(_, state, index)
            index = math.floor(tonumber(index) or 0)
            if not state.editing then
              if state.page == 1 then
                -- HP DV plus the two final Special-stat rows are read-only.
                if index < 2 or index > #DV_ROWS + 1 then return false end
                state.row = index - 1
              else
                -- The last two rows are the separate Sp. Atk / Sp. Def
                -- readouts, not extra Gen 2 Stat EXP words.
                if index < 1 or index > #STAT_EXP_ROWS then return false end
                state.row = index
              end
              state:startEdit()
            else
              state:applyEdit()
            end
            return true
          end,
          up = function(_, state)
            if state.editing then state:changeDigit(1)
            else
              local n = state:rowCount()
              state.row = state.row > 1 and state.row - 1 or n
            end
            return true
          end,
          down = function(_, state)
            if state.editing then state:changeDigit(-1)
            else
              local n = state:rowCount()
              state.row = state.row < n and state.row + 1 or 1
            end
            return true
          end,
          left = function(_, state)
            if state.editing then
              state.editDigit = state.editDigit > 1 and state.editDigit - 1
                or state.editWidth
            else state:setPage(state.page - 1) end
            return true
          end,
          right = function(_, state)
            if state.editing then
              state.editDigit = state.editDigit < state.editWidth
                and state.editDigit + 1 or 1
            else state:setPage(state.page + 1) end
            return true
          end,
          back = function(_, state)
            if state.editing then state.editing = false
            else
              local stack = state.game and state.game.stack
              if stack then stack:pop() end
            end
            return true
          end,
          start = function(_, state)
            state:maxAll()
            return true
          end,
        },
      },
    },
  }

  local modernUiExports
  local modernUiRegistered = false
  local function ensureModernUiAdapter()
    if type(mod.find) ~= "function" then return false end
    local okFind, handle = pcall(mod.find, "gen2_modern_ui")
    if not okFind or type(handle) ~= "table" or type(handle.exports) ~= "table" then
      modernUiExports, modernUiRegistered = nil, false
      return false
    end
    local ex = handle.exports
    if type(ex.registerAdapter) ~= "function" then
      modernUiExports, modernUiRegistered = ex, false
      return false
    end
    if modernUiRegistered and modernUiExports == ex then return true end
    local ok, registered, reason = pcall(ex.registerAdapter, {
      owner = "dv_ev_editor_gen2",
      version = "2.0.1",
      contract = modernUiContract,
    })
    if ok and registered ~= false then
      modernUiExports, modernUiRegistered = ex, true
      return true
    end
    modernUiExports, modernUiRegistered = ex, false
    if mod.log and mod.log.warn then
      mod.log:warn("Gen2 Modern UI adapter unavailable: %s",
        tostring(ok and reason or registered))
    end
    return false
  end

  local function hasDvEv(items)
    for _, item in ipairs(items or {}) do
      if item.id == "DV_EV_EDITOR_GEN2" or item.label == "DV/EV" then return true end
    end
    return false
  end

  local function insertAfterStats(items, entry)
    local at = #items + 1
    for i, item in ipairs(items) do
      if item.id == "STATS" or item.label == "STATS" then at = i + 1 break end
    end
    table.insert(items, at, entry)
  end

  mod.hooks:wrap("ui.party.submenu", function(nextFn, game, items, mon, ctx)
    local result = nextFn(game, items, mon, ctx)
    if type(result) ~= "table" then result = items or {} end
    if not (ctx and ctx.battle) and not hasDvEv(result) then
      insertAfterStats(result, {
        id = "DV_EV_EDITOR_GEN2",
        label = "DV/EV",
        onSelect = function(selectedMon, selectedGame)
          ensureModernUiAdapter()
          local stack = selectedGame and selectedGame.stack
          if stack then stack:push(Editor.new(selectedGame, selectedMon)) end
        end,
      })
    end
    return result
  end, 0)

  if mod.events and mod.events.on then
    mod.events:on("game.ready", function() ensureModernUiAdapter() end)
  end
  ensureModernUiAdapter()

  mod.exports = mod.exports or {}
  mod.exports.effectiveEv = effectiveEv
  mod.exports.hpDv = Mon.hpDV
  mod.exports.maximizeDvEv = maximizeDvEv
  mod.exports.recalculate = recalculate
  mod.exports.Editor = Editor
  mod.exports.gen2ModernUi = modernUiContract
  mod.exports.ensureModernUiAdapter = ensureModernUiAdapter
  mod.exports.startMaxShortcut = true
  if mod.log and mod.log.info then
    mod.log:info("DV EV Editor Gen 2 v2.0.1 loaded - START = MAX ALL")
  end
end
