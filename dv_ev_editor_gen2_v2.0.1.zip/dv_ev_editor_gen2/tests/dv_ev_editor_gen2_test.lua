local root = ... or "."

package.preload["src.ui.gen2.Chrome"] = function()
  return {
    clear=function() end, print=function() end, printRight=function() end,
    cursor=function() end, letterbox=function() end, fitScale=function() return 1 end,
    fitOrigin=function() return 0,0 end,
  }
end
package.preload["src.render.Font"] = function() return {} end

local Mon = {
  MAX_DV = 15, MAX_STAT_EXP = 65535,
}
function Mon.hpDV(d)
  local function b(v) return (v or 0) % 2 end
  return b(d.attack)*8 + b(d.defense)*4 + b(d.speed)*2 + b(d.special)
end
local function stat(base,dv,level,se)
  return math.floor(((base*2 + dv*2 + math.floor(math.sqrt(se or 0)/4))*level)/100)+5
end
function Mon.stats(base,dvs,level,se)
  local sp=dvs.special or 0
  return {
    hp=math.floor(((base.hp*2+Mon.hpDV(dvs)*2+math.floor(math.sqrt(se.hp or 0)/4))*level)/100)+level+10,
    attack=stat(base.attack,dvs.attack,level,se.attack),
    defense=stat(base.defense,dvs.defense,level,se.defense),
    speed=stat(base.speed,dvs.speed,level,se.speed),
    specialAttack=stat(base.specialAttack,sp,level,se.special),
    specialDefense=stat(base.specialDefense,sp,level,se.special),
  }
end
function Mon.syncIdentity(mon)
  mon.genderRefreshed=true
  mon.dvs.hp=Mon.hpDV(mon.dvs)
end
function Mon.refreshStats(mon,data)
  local def=data.pokemon[mon.species]
  Mon.syncIdentity(mon,data)
  mon.stats=Mon.stats(def.baseStats,mon.dvs,mon.level,mon.statExp)
  mon.maxHp=mon.stats.hp
  if mon.hp==nil or mon.hp>mon.maxHp then mon.hp=mon.maxHp end
end
package.preload["src.battle.gen2.Mon"] = function() return Mon end

local wrapped
local mod = {
  exports = {},
  hooks = { wrap=function(_, name, fn) assert(name=="ui.party.submenu"); wrapped=fn end },
  events = { on=function() end },
  find = function() return nil end,
  log = { info=function() end, warn=function() end },
}

local factory = assert(loadfile(root .. "/main.lua"))()
factory(mod)
assert(type(wrapped)=="function", "party submenu hook registered")

local field = {
  {id="STATS",label="STATS"}, {id="SWITCH",label="SWITCH"},
  {id="MOVE",label="MOVE"}, {id="ITEM",label="ITEM"}, {id="CANCEL",label="CANCEL"},
}
local mon = {
  species="TESTMON", level=50, hp=100,
  dvs={attack=8, defense=8, speed=8, special=8},
  statExp={hp=0, attack=0, defense=0, speed=0, special=0},
}
local game = {
  data={pokemon={TESTMON={name="TESTMON",baseStats={hp=80,attack=90,defense=85,speed=70,specialAttack=100,specialDefense=95}}}},
  stack={ pushed=nil, push=function(self,s) self.pushed=s end, pop=function() end },
}
Mon.refreshStats(mon,game.data)
mon.hp=mon.maxHp-10
local out=wrapped(function(_,items) return items end,game,field,mon,{battle=false})
assert(out[2].id=="DV_EV_EDITOR_GEN2", "DV/EV inserted after STATS")
assert(out[2].label=="DV/EV", "DV/EV label")

local battle={{id="SWITCH",label="SWITCH"},{id="STATS",label="STATS"},{id="CANCEL",label="CANCEL"}}
local bout=wrapped(function(_,items) return items end,game,battle,mon,{battle=true})
assert(#bout==3, "battle submenu unchanged")

out[2].onSelect(mon,game)
local editor=assert(game.stack.pushed,"editor pushed")
assert(editor.screenId=="DvEvEditorGen2", "Gen2 editor screen id")

-- DV edit updates derived HP DV and final stats, preserving missing HP.
local oldMax=mon.maxHp
local missing=oldMax-mon.hp
editor.page=1; editor.row=1; editor.editValue=15; editor:applyEdit()
assert(mon.dvs.attack==15,"attack DV edited")
assert(mon.dvs.hp==Mon.hpDV(mon.dvs),"HP DV derived")
assert(mon.maxHp==mon.stats.hp,"max HP refreshed")
assert(mon.maxHp-mon.hp==missing,"missing HP preserved")
assert(mon.genderRefreshed==true,"DV-dependent identity refreshed")

-- Gen 2 Special Stat EXP is one shared word, not separate SpA/SpD EVs.
editor.page=2; editor.row=5; editor.editValue=40000; editor:applyEdit()
assert(mon.statExp.special==40000,"shared Special Stat EXP edited")
assert(mon.statExp.specialAttack==nil and mon.statExp.specialDefense==nil,
  "no invented sixth Stat EXP word")
local spa,spd=mon.stats.specialAttack,mon.stats.specialDefense
assert(spa~=spd,"shared Special effort feeds distinct Gen2 base SpA/SpD")

mod.exports.maximizeDvEv(game,mon)
for _,k in ipairs({"attack","defense","speed","special"}) do
  assert(mon.dvs[k]==15,"max DV "..k)
end
for _,k in ipairs({"hp","attack","defense","speed","special"}) do
  assert(mon.statExp[k]==65535,"max Stat EXP "..k)
end
assert(mon.dvs.hp==15,"perfect DVs derive HP DV 15")
assert(mod.exports.effectiveEv(65535)==63,"max effective EV is 63")

-- Modern UI must present Sp. Atk and Sp. Def as two distinct read-only rows.
local contract=assert(mod.exports.gen2ModernUi,"Modern UI contract exported")
local screen=assert(contract.screens.dv_ev_editor_gen2,"editor Modern UI screen exported")
editor.page=1; editor.row=4; editor.editing=false
local dvModel=screen.model(nil,editor)
assert(dvModel.rows[6].label=="SP. ATK STAT","Sp. Atk has its own Modern UI row")
assert(dvModel.rows[7].label=="SP. DEF STAT","Sp. Def has its own Modern UI row")
assert(dvModel.rows[6].value~=dvModel.rows[7].value,"Sp. Atk/Sp. Def final values remain distinct")
assert(screen.actions.select(nil,editor,6)==false,"Sp. Atk display row is read-only")
assert(editor.editing==false,"read-only Sp. Atk row cannot start an edit")
editor.page=2; editor.row=5; editor.editing=false
local evModel=screen.model(nil,editor)
assert(evModel.rows[6].label=="SP. ATK STAT","Stat EXP page separates Sp. Atk")
assert(evModel.rows[7].label=="SP. DEF STAT","Stat EXP page separates Sp. Def")
assert(screen.actions.select(nil,editor,7)==false,"Sp. Def display row is read-only")
assert(editor.editing==false,"read-only Sp. Def row cannot start an edit")

print("dv_ev_editor_gen2_test: ok")
