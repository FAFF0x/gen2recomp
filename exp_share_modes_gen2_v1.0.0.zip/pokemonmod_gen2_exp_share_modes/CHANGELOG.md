# Changelog

## 1.0.0

- Repackaged as a Gen 2-only standalone build with unique ID `pokemonmod_gen2_exp_share_modes`.
- Removed the manifest conflict with `exp_share_modes` so the launcher can import/retain both packages independently.
- Renamed the internal mod namespace to match the unique package identity.
- Added inter-mod coexistence guard: active `exp_share_modes` / `exp_share_modes_gen2` packages are detected and this build defers instead of installing a competing EXP hook.
- Preserved the native Gen 2 `battle.exp_award` implementation and all three EXP modes.

# Changelog

## 2.0.0
- Ported the mod natively to Gen 2.
- Added `games: ["gen2"]` and a separate `exp_share_modes_gen2` mod id.
- Reimplemented all three modes through the Gen 2 `battle.exp_award` hook.
- Preserved Gen 2 Stat EXP, Pokérus, Lucky Egg, traded bonuses, happiness, level-up and move-learning flow.
- Explicitly suppresses the vanilla held EXP.SHARE distribution effect while a custom mode is active.
- Excludes fainted Pokémon and Eggs from every mode.
- Added regression tests for Off, Classic and Modern Progressive recipient/divisor rules.
