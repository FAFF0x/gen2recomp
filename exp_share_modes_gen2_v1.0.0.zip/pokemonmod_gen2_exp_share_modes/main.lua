-- EXP Share Modes Gen 2
-- Native Gold/Silver/Crystal port of EXP Share Modes.
--
-- Gen 2 already exposes battle.exp_award around Battle:awardExperience.
-- Replacing the award at that seam lets the engine keep ownership of every
-- visible and mechanical consequence of EXP: Stat EXP, Pokerus, traded and
-- Lucky Egg bonuses, messages, level-ups, happiness and move learning.

local MOD_ID = "pokemonmod_gen2_exp_share_modes"
local VALID_MODE = { off = true, classic = true, modern = true }
local EQUIVALENT_MOD_IDS = { "exp_share_modes", "exp_share_modes_gen2" }

local function modeOf(mod)
  local mode = tostring(mod.options:get("mode") or "classic")
  return VALID_MODE[mode] and mode or "classic"
end

local function eligible(mon)
  return type(mon) == "table"
    and not mon.isEgg
    and (tonumber(mon.hp) or 0) > 0
end

local function contains(list, value)
  for _, candidate in ipairs(list or {}) do
    if candidate == value then return true end
  end
  return false
end

-- Returns party INDICES, because Battle:giveExperiencePass is indexed against
-- battle.party and its events also report the party slot.
local function livingPartyIndices(battle)
  local out = {}
  for index, mon in ipairs((battle and battle.party) or {}) do
    if eligible(mon) then out[#out + 1] = index end
  end
  return out
end

local function livingParticipantIndices(battle, ctx)
  local out = {}
  local seen = {}

  -- Gen 2 adds ctx.recipients: the exact participant indices captured before
  -- the hook runs. Prefer it over reading battle.participants again.
  for _, index in ipairs((ctx and ctx.recipients) or {}) do
    local mon = battle and battle.party and battle.party[index]
    if eligible(mon) and not seen[index] then
      seen[index] = true
      out[#out + 1] = index
    end
  end

  -- Defensive fallback for older compatible builds / unusual battle paths.
  if #out == 0 then
    local raw = battle and battle.participants or {}
    local ordered = {}
    for index in pairs(raw) do ordered[#ordered + 1] = index end
    table.sort(ordered)
    for _, index in ipairs(ordered) do
      local mon = battle and battle.party and battle.party[index]
      if eligible(mon) and not seen[index] then
        seen[index] = true
        out[#out + 1] = index
      end
    end
  end

  -- Match the engine's normal participant invariant if a custom battle path
  -- reached the hook with an empty participant set.
  if #out == 0 then
    local index = battle and battle.playerIndex
    local mon = index and battle.party and battle.party[index]
    if eligible(mon) then out[1] = index end
  end

  return out
end

local function benchIndices(battle, participants)
  local out = {}
  for _, index in ipairs(livingPartyIndices(battle)) do
    if not contains(participants, index) then out[#out + 1] = index end
  end
  return out
end

local function awardPass(battle, loser, recipients, divisor)
  if #recipients == 0 then return end
  local def = battle:speciesDef(loser)
  -- `halved=false` is intentional. Vanilla Gen 2 EXP.SHARE halves the enemy's
  -- base EXP/stat block and adds a holder pass. This mod replaces that whole
  -- distribution rule, so the held item must not silently tax or duplicate it.
  battle:giveExperiencePass(loser, def, recipients,
    math.max(1, math.floor(divisor or #recipients)), false)
end

local function distribute(mod, _nextFn, ctx)
  local battle = ctx and ctx.battle
  local loser = ctx and ctx.loser
  if not (battle and loser and battle.giveExperiencePass and battle.speciesDef) then
    -- On a malformed/older context, preserve the engine instead of swallowing
    -- the award. This is only a compatibility escape hatch.
    if _nextFn then return _nextFn(ctx) end
    return
  end

  local mode = modeOf(mod)
  local participants = livingParticipantIndices(battle, ctx)

  if mode == "off" then
    -- One full pool split only among conscious participants.
    awardPass(battle, loser, participants, #participants)
    return
  end

  if mode == "classic" then
    -- One full pool split across every conscious, non-Egg party member.
    local living = livingPartyIndices(battle)
    awardPass(battle, loser, living, #living)
    return
  end

  -- Modern Progressive:
  --   participants split 100% => divisor = participant count
  --   bench splits 50%       => divisor = bench count * 2
  awardPass(battle, loser, participants, #participants)
  local bench = benchIndices(battle, participants)
  awardPass(battle, loser, bench, #bench * 2)
end

return function(mod)
  mod.options:define({
    {
      key = "mode",
      label = "EXP SHARE MODE",
      type = "choice",
      default = "classic",
      choices = {
        { "OFF", "off" },
        { "CLASSIC EVEN SPLIT", "classic" },
        { "MODERN PROGRESSIVE", "modern" },
      },
    },
  })

  -- Coexistence guard: older/equivalent packages may be installed at the same
  -- time. optional_dependencies orders them before this mod, so mod.find can
  -- safely detect an active equivalent and avoid installing a second owner of
  -- battle.exp_award. This is intentionally not a manifest conflict: both
  -- packages may coexist in the manager; only one should own EXP distribution.
  local deferredTo
  if mod.find then
    for _, otherId in ipairs(EQUIVALENT_MOD_IDS) do
      local other = mod.find(otherId)
      if other then
        deferredTo = other.id or otherId
        break
      end
    end
  end

  if not deferredTo then
    mod.hooks:wrap("battle.exp_award", function(nextFn, ctx)
      return distribute(mod, nextFn, ctx)
    end, 100)
  end

  -- Small test/integration surface; these are pure helpers and do not mutate
  -- battle state by themselves.
  mod.exports.mode = function() return modeOf(mod) end
  mod.exports.eligible = eligible
  mod.exports.livingPartyIndices = livingPartyIndices
  mod.exports.livingParticipantIndices = livingParticipantIndices
  mod.exports.benchIndices = benchIndices
  mod.exports._distribute = function(nextFn, ctx)
    return distribute(mod, nextFn, ctx)
  end
  mod.exports.deferredTo = deferredTo
  mod.exports.active = deferredTo == nil

  if deferredTo then
    mod.log:warn("EXP distribution deferred to active equivalent mod '%s'", deferredTo)
  else
    mod.log:info("EXP Share Modes - Gen 2 loaded [" .. MOD_ID .. "] (default: Classic Even Split)")
  end
end
