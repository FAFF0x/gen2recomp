local source = debug.getinfo(1, "S").source:sub(2)
local root = source:match("^(.*)tests/") or ""
if root == "" then root = "." end
root = root:gsub("/$", "")

local capturedHook
local optionValue = "classic"
local mod = {
  options = {
    define = function() end,
    get = function(_, key)
      assert(key == "mode")
      return optionValue
    end,
  },
  hooks = {
    wrap = function(_, name, callback, priority)
      assert(name == "battle.exp_award")
      assert(priority == 100)
      capturedHook = callback
      return function() end
    end,
  },
  exports = {},
  log = { info = function() end },
}

local chunk = assert(loadfile(root .. "/main.lua"))
chunk()(mod)
assert(type(capturedHook) == "function", "battle.exp_award hook registered")

local function mon(hp, extra)
  local m = { hp = hp, species = "TEST" }
  for k, v in pairs(extra or {}) do m[k] = v end
  return m
end

local function fixture()
  local party = {
    mon(20), -- participant
    mon(30), -- living bench
    mon(0),  -- fainted participant: excluded
    mon(25), -- living bench
    mon(1, { isEgg = true }), -- Egg: excluded even with HP
  }
  local calls = {}
  local battle = {
    party = party,
    participants = { [1] = true, [3] = true },
    playerIndex = 1,
    speciesDef = function(_, loser)
      assert(loser.species == "FOE")
      return { baseExp = 100 }
    end,
    giveExperiencePass = function(_, loser, def, recipients, divisor, halved)
      assert(loser.species == "FOE")
      assert(def.baseExp == 100)
      calls[#calls + 1] = {
        recipients = recipients,
        divisor = divisor,
        halved = halved,
      }
    end,
  }
  return battle, calls
end

local function eqList(got, want, label)
  assert(#got == #want, label .. " length")
  for i = 1, #want do
    assert(got[i] == want[i], label .. " item " .. i)
  end
end

local loser = { species = "FOE", level = 10 }

-- OFF: fainted participant excluded; one full pool to slot 1.
do
  optionValue = "off"
  local battle, calls = fixture()
  capturedHook(function() error("vanilla must not run") end, {
    battle = battle, loser = loser, recipients = { 1, 3 },
  })
  assert(#calls == 1, "off has one pass")
  eqList(calls[1].recipients, { 1 }, "off recipients")
  assert(calls[1].divisor == 1, "off divisor")
  assert(calls[1].halved == false, "off ignores held EXP.SHARE tax")
end

-- CLASSIC: all living non-Egg party members split one 100% pool.
do
  optionValue = "classic"
  local battle, calls = fixture()
  capturedHook(function() error("vanilla must not run") end, {
    battle = battle, loser = loser, recipients = { 1, 3 },
  })
  assert(#calls == 1, "classic has one pass")
  eqList(calls[1].recipients, { 1, 2, 4 }, "classic recipients")
  assert(calls[1].divisor == 3, "classic divisor")
  assert(calls[1].halved == false, "classic ignores held EXP.SHARE tax")
end

-- MODERN: participants split 100%; living bench splits a separate 50% pool.
do
  optionValue = "modern"
  local battle, calls = fixture()
  capturedHook(function() error("vanilla must not run") end, {
    battle = battle, loser = loser, recipients = { 1, 3 },
  })
  assert(#calls == 2, "modern has participant and bench passes")
  eqList(calls[1].recipients, { 1 }, "modern participant recipients")
  assert(calls[1].divisor == 1, "modern participant divisor")
  eqList(calls[2].recipients, { 2, 4 }, "modern bench recipients")
  assert(calls[2].divisor == 4, "modern bench divisor gives 50% pool")
  assert(calls[1].halved == false and calls[2].halved == false,
    "modern ignores held EXP.SHARE tax")
end

-- Fallback: a malformed old hook context must call vanilla rather than eat EXP.
do
  optionValue = "classic"
  local used = false
  capturedHook(function(ctx) used = ctx.marker end, { marker = true })
  assert(used == true, "malformed context falls back to vanilla")
end

-- Empty participant list falls back to active player when eligible.
do
  optionValue = "off"
  local battle, calls = fixture()
  battle.participants = {}
  capturedHook(function() error("vanilla must not run") end, {
    battle = battle, loser = loser, recipients = {},
  })
  eqList(calls[1].recipients, { 1 }, "active fallback")
end

-- Coexistence: if an older equivalent mod is active, this package must defer
-- instead of installing a second EXP hook.
do
  local wraps = 0
  local deferMod = {
    options = {
      define = function() end,
      get = function(_, key) assert(key == "mode"); return "classic" end,
    },
    hooks = {
      wrap = function() wraps = wraps + 1 end,
    },
    find = function(id)
      if id == "exp_share_modes_gen2" then
        return { id = id, version = "2.0.0", exports = {} }
      end
      return nil
    end,
    exports = {},
    log = { info = function() end, warn = function() end },
  }
  local deferredChunk = assert(loadfile(root .. "/main.lua"))
  deferredChunk()(deferMod)
  assert(wraps == 0, "active equivalent prevents second EXP hook")
  assert(deferMod.exports.active == false, "deferred build reports inactive ownership")
  assert(deferMod.exports.deferredTo == "exp_share_modes_gen2", "deferred target exported")
end

print("exp_share_modes_gen2_test: ok")
