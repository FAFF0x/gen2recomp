# Changelog

## 1.0.3
- Rebuilt the Mart integration around the actual multi-generation Gen 2 screen registry.
- Fixes EVOLUTION being invisible under Modern UI Gen 2 v1.0.15.
- Fixes coexistence with all_tm_shop_gen2 v1.1.0.
- Uses a dynamic Gen2ScriptMenu-compatible outer chooser so Modern UI renders every row.
- Uses `mod.content.screens:get()` to preserve the previous Gen2MartMenu factory.
- Uses `override()` rather than an invalid/fragile duplicate screen registration.
- Declares all_tm_shop_gen2 as an optional dependency so it is ordered first when installed.
- NORMAL SHOP preserves the previous/native Gen 2 Mart.
- TM/HM SHOP delegates to All TM Shop when present.
- EVOLUTION SHOP uses the native Gen2 MartMenu purchase flow with price 0.
- Corrected evolution method discovery to the real Gen 2 ids `EVOLVE_ITEM` and `EVOLVE_TRADE`.
- Keeps explicit `games: ["gen2"]` targeting.

## 1.0.2
- Corrected launcher generation targeting.
- Attempted to decorate Gen2MartMenu at runtime; Modern UI could hide the added row.

## 1.0.1
- Incorrect generation metadata attempt.

## 1.0.0
- Initial release.
