-- Free Evolution Shop Gen 2 v1.0.3
--
-- Target runtime:
--   bryanthaboi/gen1recomp multi-generation engine, Gen 2 arm.
--
-- Why v1.0.2 failed:
--   * Modern UI v1.0.15 reconstructs Gen2MartMenu's TOP presentation from
--     semantic state and deliberately renders BUY / SELL / QUIT. Replacing an
--     individual MartMenu instance's drawTopMenu() therefore cannot add a
--     visible fourth row while Modern UI owns the presentation.
--   * all_tm_shop_gen2 replaces the Gen2MartMenu registry entry with its own
--     chooser, so a decorator waiting for the native MartMenu is not the root
--     shop flow when that mod is installed.
--
-- v1.0.3 composes at the screen-registry seam instead:
--   1. Capture the Gen2MartMenu factory that already exists. With the optional
--      dependency ordering this is All TM Shop's chooser when it is installed.
--   2. Override Gen2MartMenu with a new outer chooser.
--   3. The outer chooser deliberately exposes the Gen2ScriptMenu semantic
--      surface (screenId/items/row/col/cols/title), which Modern UI v1.0.15
--      renders dynamically instead of hardcoding its rows.
--   4. NORMAL SHOP delegates to the previous/native Gen 2 mart.
--   5. TM/HM SHOP delegates to All TM Shop when that mod is present.
--   6. EVOLUTION SHOP opens the real native Gen2 MartMenu directly in BUY
--      phase with a zero-priced evolution-item catalogue. All purchase,
--      quantity, bag-capacity and confirmation logic remains engine-native.

local Chrome = require("src.ui.gen2.Chrome")
local VanillaMartMenu = require("src.ui.gen2.MartMenu")

local previousMartScreen = nil
local modRef = nil

local CANONICAL = {
  "SUN_STONE",
  "MOON_STONE",
  "FIRE_STONE",
  "THUNDERSTONE",
  "WATER_STONE",
  "LEAF_STONE",
  "KINGS_ROCK",
  "METAL_COAT",
  "DRAGON_SCALE",
  "UP_GRADE",
}

local function normalized(value)
  return tostring(value or ""):upper():gsub("[^A-Z0-9]", "")
end

local function shallowCopy(source)
  local out = {}
  for k, v in pairs(source or {}) do out[k] = v end
  return out
end

local function itemLookup(items)
  local byName = {}
  for id, def in pairs(items or {}) do
    byName[normalized(id)] = id
    if type(def) == "table" then
      if def.id then byName[normalized(def.id)] = id end
      if def.name then byName[normalized(def.name)] = id end
    end
  end
  return byName
end

local function resolveItem(items, lookup, ref)
  if ref == nil then return nil end
  if items and items[ref] then return ref end
  return lookup[normalized(ref)]
end

-- Extract the actual Gen 2 evolution triggers from the merged Pokemon data.
-- Gold/Silver/Crystal spell these methods EVOLVE_ITEM and EVOLVE_TRADE.
local function evolutionItemIds(data)
  local items = (data and data.items) or {}
  local lookup = itemLookup(items)
  local seen, ids = {}, {}

  local function add(ref)
    local id = resolveItem(items, lookup, ref)
    if id and items[id] and not seen[id] then
      seen[id] = true
      ids[#ids + 1] = id
    end
  end

  for _, def in pairs((data and data.pokemon) or {}) do
    for _, evo in ipairs((def and def.evolutions) or {}) do
      if evo.method == "EVOLVE_ITEM" then
        add(evo.item)
      elseif evo.method == "EVOLVE_TRADE" and evo.item then
        -- King's Rock / Metal Coat / Dragon Scale / Up-Grade.
        add(evo.item)
      end
    end
  end

  -- Standard G/S/C fallback, also gives stable ordering on older caches.
  for _, id in ipairs(CANONICAL) do add(id) end

  local rank = {}
  for index, id in ipairs(CANONICAL) do rank[normalized(id)] = index end

  table.sort(ids, function(a, b)
    local da, db = items[a] or {}, items[b] or {}
    local ra = rank[normalized(a)] or rank[normalized(da.name)] or 999
    local rb = rank[normalized(b)] or rank[normalized(db.name)] or 999
    if ra ~= rb then return ra < rb end
    return tostring(da.name or a) < tostring(db.name or b)
  end)

  return ids
end

local function evolutionEntries(game)
  local out = {}
  local data = game and game.data or {}
  local items = data.items or {}
  for _, id in ipairs(evolutionItemIds(data)) do
    local def = items[id]
    out[#out + 1] = {
      id = id,
      name = (def and def.name) or id,
      price = 0,
    }
  end
  return out
end

local function popTop(game, expected)
  local stack = game and game.stack
  if not stack then return false end

  if type(stack.top) == "function" then
    local ok, top = pcall(stack.top, stack)
    if ok and expected and top ~= expected then return false end
  end

  if type(stack.pop) == "function" then
    stack:pop()
    return true
  end
  return false
end

local function factoryFunction(record)
  if type(record) == "function" then return record end
  if type(record) == "table" and type(record.new) == "function" then
    return record.new
  end
  return nil
end

local function instantiatePrevious(game, opts)
  local factory = factoryFunction(previousMartScreen)
  if not factory then return nil end

  local ok, state = pcall(factory, game, opts or {})
  if not ok then
    if modRef then
      modRef.log:warn("Previous Gen2MartMenu factory failed: %s", tostring(state))
    end
    return nil
  end
  return state
end

-- ========================================================================
-- Modern-UI-safe outer chooser.
--
-- It is requested through the Gen2MartMenu registry, but intentionally
-- identifies itself as Gen2ScriptMenu. Modern UI v1.0.15's presenter for that
-- semantic screen reads state.items dynamically, so EVOLUTION SHOP remains
-- visible instead of being replaced by its hardcoded BUY/SELL/QUIT model.
-- ========================================================================

local ShopChooser = {}
ShopChooser.__index = ShopChooser
ShopChooser.isOpaque = false

function ShopChooser.new(game, opts)
  opts = opts or {}
  local self = setmetatable({}, ShopChooser)
  self.game = game
  self.opts = opts
  self.onClose = opts.onClose

  -- Probe the previously-installed mart factory. all_tm_shop_gen2's chooser
  -- publishes openTMShop(); native/other marts do not.
  local probe = instantiatePrevious(game, opts)
  self.hasTMShop = probe ~= nil and type(probe.openTMShop) == "function"

  self.items = { "NORMAL SHOP" }
  self.actions = { "normal" }

  if self.hasTMShop then
    self.items[#self.items + 1] = "TM/HM SHOP"
    self.actions[#self.actions + 1] = "tm"
  end

  self.items[#self.items + 1] = "EVOLUTION SHOP"
  self.actions[#self.actions + 1] = "evolution"

  self.items[#self.items + 1] = "LEAVE"
  self.actions[#self.actions + 1] = "leave"

  -- Public semantic fields consumed by Gen2ScriptMenu / Modern UI.
  self.screenId = "Gen2ScriptMenu"
  self.title = "POKéMART"
  self.row = 1
  self.col = 1
  self.cols = 1
  self.index = 1
  return self
end

function ShopChooser:wantsFillScale()
  return true
end

function ShopChooser:syncIndex()
  self.index = self.row
end

function ShopChooser:move(delta)
  local count = #self.items
  if count == 0 then return end
  self.row = ((self.row - 1 + delta) % count) + 1
  self:syncIndex()
end

function ShopChooser:close()
  if self.onClose then self.onClose() end
end

local function pushNativeNormal(self)
  local game = self.game
  if not (game and game.stack) then return false end

  local childOpts = shallowCopy(self.opts)
  local child
  childOpts.onClose = function()
    popTop(game, child)
  end

  child = VanillaMartMenu.new(game, childOpts)
  child.screenId = "Gen2MartMenu"
  game.stack:push(child)
  return true
end

function ShopChooser:openNormal()
  local game = self.game
  if not (game and game.stack) then return end

  -- If All TM Shop is the previous Gen2MartMenu owner, use its NORMAL SHOP
  -- path. This preserves its filtering of TM/HM machines from normal shelves.
  local helper = instantiatePrevious(game, self.opts)
  if helper and type(helper.openNormal) == "function" then
    helper:openNormal()
    return
  end

  -- Preserve any other previous Gen2MartMenu replacement as the normal shop
  -- rather than silently discarding it.
  if helper then
    local childOpts = shallowCopy(self.opts)
    local child
    childOpts.onClose = function()
      popTop(game, child)
    end

    child = instantiatePrevious(game, childOpts)
    if child then
      child.screenId = child.screenId or "Gen2MartMenu"
      game.stack:push(child)
      return
    end
  end

  pushNativeNormal(self)
end

function ShopChooser:openTMShop()
  local helper = instantiatePrevious(self.game, self.opts)
  if helper and type(helper.openTMShop) == "function" then
    helper:openTMShop()
  end
end

function ShopChooser:openEvolutionShop()
  local game = self.game
  if not (game and game.stack) then return end

  -- Always build this catalogue on the real Gen 2 native MartMenu. We force
  -- STANDARD dialogue only for this child so Herb/Bargain/Pharmacy-specific
  -- intros cannot leak into the evolution catalogue.
  local childOpts = shallowCopy(self.opts)
  childOpts.martType = 0

  local child = VanillaMartMenu.new(game, childOpts)
  child.entries = evolutionEntries(game)
  child.phase = "buy"
  child.index = 1
  child.scroll = 0
  child.message = nil
  child.confirm = nil
  child.isOpaque = true
  child.screenId = "Gen2MartMenu"
  child._freeEvolutionShopGen2 = true

  -- B/CANCEL returns to our outer chooser instead of entering the native
  -- BUY/SELL/QUIT top menu.
  child.leaveBuy = function(state)
    state.isOpaque = nil
    popTop(game, state)
  end

  game.stack:push(child)

  if modRef then
    modRef.log:info("EVOLUTION SHOP opened with %d Gen 2 evolution items",
      #child.entries)
  end
end

function ShopChooser:update(_dt)
  local input = self.game and self.game.input
  if not input then return end

  if input:wasPressed("up") then
    self:move(-1)
  elseif input:wasPressed("down") then
    self:move(1)
  elseif input:wasPressed("b") then
    self:close()
  elseif input:wasPressed("a") then
    local action = self.actions[self.row]
    if action == "normal" then
      self:openNormal()
    elseif action == "tm" then
      self:openTMShop()
    elseif action == "evolution" then
      self:openEvolutionShop()
    else
      self:close()
    end
  end
end

-- Vanilla/Modern-UI-disabled fallback. With Modern UI enabled this native
-- draw is suppressed and the Gen2ScriptMenu presenter renders state.items.
function ShopChooser:drawPanel()
  local count = #self.items
  local height = math.min(17, 3 + count * 2)

  Chrome.box(0, 0, 19, height)
  Chrome.print("POKéMART", 2, 1)

  for i, label in ipairs(self.items) do
    local y = i * 2 + 1
    if i == self.row then Chrome.cursor(1, y) end
    Chrome.print(label, 2, y)
  end

  love.graphics.setColor(1, 1, 1, 1)
end

function ShopChooser:draw()
  self:drawPanel()
end

return function(mod)
  modRef = mod

  -- Because all_tm_shop_gen2 is an OPTIONAL dependency, the loader orders it
  -- before this mod when present. `get` therefore captures its already-folded
  -- Gen2MartMenu screen factory. With no TM shop installed this is nil and we
  -- fall back to the native Gen 2 MartMenu.
  previousMartScreen = mod.content.screens:get("Gen2MartMenu")

  -- This is intentionally OVERRIDE, not REGISTER: we are composing the
  -- existing Gen2MartMenu entry rather than colliding with it.
  mod.content.screens:override("Gen2MartMenu", { new = ShopChooser.new })

  local count = 0
  for _ in ipairs(evolutionItemIds(mod.game and mod.game.data)) do
    count = count + 1
  end

  mod.exports.evolutionItemIds = evolutionItemIds
  mod.exports.evolutionEntries = evolutionEntries
  mod.exports.ShopChooser = ShopChooser
  mod.exports.previousMartScreen = previousMartScreen

  mod.log:info(
    "Free Evolution Shop Gen 2 installed: dynamic Gen2 chooser, %d evolution items",
    count
  )
end
