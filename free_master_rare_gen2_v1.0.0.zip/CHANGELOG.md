# Changelog

## 1.0.0

- Repackaged as a dedicated Pokemon MOD Gen 2 build.
- Changed manifest ID to `pokemonmod_gen2_free_master_rare`.
- Explicitly restricted the package to `games: ["gen2"]`.
- Removed hard conflicts with older Free Master Ball / Rare Candy packages.
- Added optional ordering and runtime coexistence guards for legacy equivalent mods.
- Added a namespaced MartMenu patch marker.
- Preserved the native Gen2MartMenu for Modern UI compatibility.
