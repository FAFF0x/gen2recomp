-- Free Master Ball + Rare Candy - Gen 2 (Pokemon MOD) v1.0.0
--
-- Gen 2-only, coexistence-safe build.
-- Adds MASTER BALL and RARE CANDY to every STANDARD Gen 2 Poke Mart
-- without replacing Gen2MartMenu.

return function(mod)
  local ITEMS = { "MASTER_BALL", "RARE_CANDY" }

  -- If the old combined build is already active, let it own the feature.
  -- optional_dependencies makes a present/active legacy build load first.
  local legacyCombined = mod.find and mod.find("free_master_rare_gen2")
  if legacyCombined then
    mod.log:warn("free_master_rare_gen2 is already active; skipping duplicate Gen 2 mart augmentation")
    return
  end

  -- If one of the older single-item mods is active, leave that item to it
  -- while still providing the other item. This prevents duplicate wrappers
  -- from fighting over the same stock entry.
  local ownedElsewhere = {
    MASTER_BALL = mod.find and mod.find("free_master_ball") ~= nil or false,
    RARE_CANDY = mod.find and mod.find("free_rare_candy") ~= nil or false,
  }

  -- Gen 2 MartMenu reads each item's live price for display/payment.
  -- Price 0 preserves the intended behaviour and prevents sell-back profit.
  local available = {}
  for _, id in ipairs(ITEMS) do
    if not ownedElsewhere[id] then
      local def = mod.content.items:get(id)
      if def then
        mod.content.items:patch(id, { price = 0 })
        available[id] = true
      else
        mod.log:warn("%s is missing from the Gen 2 item registry", id)
      end
    else
      mod.log:info("%s is already owned by an active legacy mod; leaving it untouched", id)
    end
  end

  if not next(available) then
    mod.log:info("No mart items need augmentation in this build")
    return
  end

  -- Preserve the native Gen 2 Mart screen so UI mods keep the original
  -- BUY/SELL/quantity/confirmation state machine.
  local MartMenu = require("src.ui.gen2.MartMenu")

  -- Namespaced guard for this build. Also honor the old combined guard if a
  -- legacy package patched the class before mod.find could identify it.
  if MartMenu.__pokemonmodGen2FreeMasterRarePatched or MartMenu.__freeMasterRareGen2Patched then
    mod.log:warn("A compatible Gen 2 mart augmentation is already installed; skipping duplicate wrapper")
    return
  end

  local vanillaBuildEntries = MartMenu.buildEntries
  MartMenu.buildEntries = function(self, ...)
    vanillaBuildEntries(self, ...)

    if self.martType ~= "STANDARD" then return end

    local present = {}
    for _, entry in ipairs(self.entries or {}) do
      if entry and entry.id then
        present[entry.id] = true
      end
    end

    self.entries = self.entries or {}
    for _, id in ipairs(ITEMS) do
      if available[id] and not present[id] then
        local def = self.items and self.items[id]
        self.entries[#self.entries + 1] = {
          id = id,
          name = (def and def.name) or id,
          price = (def and def.price) or 0,
        }
        present[id] = true
      end
    end
  end

  MartMenu.__pokemonmodGen2FreeMasterRarePatched = true

  mod.exports = {
    version = "1.0.0",
    gen2_only = true,
    items = { MASTER_BALL = true, RARE_CANDY = true },
  }

  mod.log:info("Gen 2 free MASTER BALL / RARE CANDY mart augmentation installed")
end
