-- Headless contract test for Pokemon MOD Gen 2 Free Master Ball + Rare Candy.
local patched = {}
local defs = {
  MASTER_BALL = { id = "MASTER_BALL", name = "MASTER BALL", price = 9999 },
  RARE_CANDY = { id = "RARE_CANDY", name = "RARE CANDY", price = 4800 },
  POTION = { id = "POTION", name = "POTION", price = 300 },
}
local MartMenu = {}
function MartMenu.buildEntries(self)
  self.entries = { { id = "POTION", name = "POTION", price = 300 } }
end
package.preload["src.ui.gen2.MartMenu"] = function() return MartMenu end

local active = {}
local mod = {
  find = function(id) return active[id] end,
  content = { items = {
    get = function(_, id) return defs[id] end,
    patch = function(_, id, p)
      for k, v in pairs(p) do defs[id][k] = v end
      patched[id] = true
    end,
  } },
  log = {
    warn = function() end,
    error = function() end,
    info = function() end,
  },
  exports = {},
}

local chunk = assert(loadfile((arg[0]:gsub("tests/contract.lua$", "")) .. "main.lua"))
chunk()(mod)

assert(patched.MASTER_BALL and patched.RARE_CANDY)
assert(defs.MASTER_BALL.price == 0 and defs.RARE_CANDY.price == 0)
assert(MartMenu.__pokemonmodGen2FreeMasterRarePatched == true)

local standard = { martType = "STANDARD", items = defs }
MartMenu.buildEntries(standard)
assert(#standard.entries == 3)
assert(standard.entries[2].id == "MASTER_BALL")
assert(standard.entries[3].id == "RARE_CANDY")

for _, kind in ipairs({ "BITTER", "BARGAIN", "PHARMACY" }) do
  local shop = { martType = kind, items = defs }
  MartMenu.buildEntries(shop)
  assert(#shop.entries == 1, kind .. " shop was modified")
end

print("contract-ok")
