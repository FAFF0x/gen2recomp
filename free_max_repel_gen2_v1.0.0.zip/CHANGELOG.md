# Changelog

## 1.0.0
- Initial release.
- MAX REPEL costs 0.
- MAX REPEL is added to every standard Gen 2 Poké Mart.
- Specialty shops are not modified.
