-- Free Max Repel - Gen 2 v1.0.0
--
-- Adds MAX REPEL to every STANDARD Gen 2 Poke Mart for 0.
-- The native Gen2MartMenu remains the screen owner, so this composes with
-- Modern UI and other mods that present or extend the normal mart screen.

return function(mod)
  local ITEM_ID = "MAX_REPEL"

  local def = mod.content.items:get(ITEM_ID)
  if not def then
    mod.log:error("%s is missing from the Gen 2 item registry", ITEM_ID)
    return
  end

  -- MartMenu reads the live item price for display and payment.
  -- Zero also prevents a buy-for-free / sell-for-profit loop.
  mod.content.items:patch(ITEM_ID, { price = 0 })

  local MartMenu = require("src.ui.gen2.MartMenu")
  if MartMenu.__freeMaxRepelGen2Patched then
    mod.log:warn("Free Max Repel Gen 2 mart wrapper already installed")
    return
  end

  local vanillaBuildEntries = MartMenu.buildEntries

  MartMenu.buildEntries = function(self, ...)
    vanillaBuildEntries(self, ...)

    -- Do not alter bargain/pharmacy/other specialty shop inventories.
    if self.martType ~= "STANDARD" then return end

    self.entries = self.entries or {}

    -- If this mart already sells MAX REPEL, keep its normal position but
    -- ensure the visible price reflects the patched item definition.
    for _, entry in ipairs(self.entries) do
      if entry and entry.id == ITEM_ID then
        entry.price = 0
        return
      end
    end

    local itemDef = self.items and self.items[ITEM_ID]
    self.entries[#self.entries + 1] = {
      id = ITEM_ID,
      name = (itemDef and itemDef.name) or "MAX REPEL",
      price = 0,
    }
  end

  MartMenu.__freeMaxRepelGen2Patched = true
  mod.log:info("MAX REPEL set to 0 and added to all standard Gen 2 Poke Marts")
end
