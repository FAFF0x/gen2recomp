# Changelog

## 2.0.0

- Port nativo Gen 2 di HM Anywhere.
- Supportate tutte le HM Gen 2: CUT, FLY, SURF, STRENGTH, FLASH, WATERFALL, WHIRLPOOL.
- Uso senza insegnamento tramite `fieldmove.eligibility` per le azioni contestuali.
- Aggiunto Start → HM Gen 2 con uso manuale tramite il vero `World:useFieldMove`.
- Conservati i Badge Johto corretti e tutte le restrizioni native delle mappe.
- Conservato CTX ON / CTX OFF per abilitare/disabilitare soltanto il supplemento contestuale.
- Rimosse dal submenu Pokémon soltanto le righe field-move HM ridondanti; DIG, HEADBUTT,
  ROCK SMASH, SOFTBOILED/MILK DRINK, SWEET SCENT e TELEPORT restano invariati.
- Aggiunti WATERFALL e WHIRLPOOL rispetto alla versione Gen 1.
- Schermata HM predisposta per il presenter semantico di Gen2 Modern UI.
