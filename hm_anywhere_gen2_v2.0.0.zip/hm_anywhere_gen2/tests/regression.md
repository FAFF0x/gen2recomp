# HM Anywhere Gen 2 regression checklist

- HM detection uses `item.machine.kind == "HM"` + `machine.move`.
- A real party move user always wins over HM Anywhere.
- CTX ON substitutes an HM-device helper only for owned HM moves.
- CTX OFF restores vanilla contextual eligibility when nobody knows the move.
- WATERFALL and WHIRLPOOL are included.
- Party submenu removes only HM field rows, never Gen 2 TM/utility field moves.
- Start menu gets one HM row only when at least one HM is owned.
- Manual use calls `World:useFieldMove`, so badges/map restrictions stay native.
- FLY opens the native Gen 2 fly picker and preserves the queued field move.
- Custom HM screen exposes `Gen2HmAnywhereMenu`, `items`, `rows`, and `index` for Modern UI.
