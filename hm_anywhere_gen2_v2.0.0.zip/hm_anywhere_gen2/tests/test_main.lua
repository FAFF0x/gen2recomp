local root = os.getenv("HM_ANYWHERE_ROOT")
assert(root and root ~= "", "pass mod root")

local wrappers = {}
local eventHandlers = {}
local saved = {}
local logs = {}
local mod = {
  hooks = {
    wrap = function(_, name, fn)
      wrappers[name] = fn
      return function() wrappers[name] = nil end
    end,
  },
  events = {
    on = function(_, name, fn) eventHandlers[name] = fn end,
  },
  save = {
    get = function(_, key, default)
      local v = saved[key]
      if v == nil then return default end
      return v
    end,
    set = function(_, key, value) saved[key] = value end,
  },
  ui = {
    insertBefore = function(items, anchor, item)
      local out, inserted = {}, false
      for _, row in ipairs(items) do
        if not inserted and tostring(row.label or "") == anchor then
          out[#out + 1] = item
          inserted = true
        end
        out[#out + 1] = row
      end
      if not inserted then out[#out + 1] = item end
      return out
    end,
  },
  log = {
    info = function(_, fmt, ...)
      logs[#logs + 1] = string.format(fmt, ...)
    end,
  },
  exports = {},
}

local init = assert(loadfile(root .. "/main.lua"))()
assert(type(init) == "function")
init(mod)

assert(type(wrappers["fieldmove.eligibility"]) == "function")
assert(type(wrappers["ui.party.submenu"]) == "function")
assert(type(wrappers["ui.start_menu.items"]) == "function")

local data = { items = {
  HM_CUT = { machine = { kind = "HM", move = "CUT" } },
  HM_SURF = { machine = { kind = "HM", move = "SURF" } },
  HM_WATERFALL = { machine = { kind = "HM", move = "WATERFALL" } },
  HM_WHIRLPOOL = { machine = { kind = "HM", move = "WHIRLPOOL" } },
  TM_HEADBUTT = { machine = { kind = "TM", move = "HEADBUTT" } },
} }
local save = {
  inventory = { HM_CUT = 1, HM_WATERFALL = 1, HM_WHIRLPOOL = 1 },
  party = {
    { isEgg = true, species = "TOGEPI" },
    { species = "CYNDAQUIL", hp = 0, moves = {} },
  },
}

-- CTX defaults ON: owned HM substitutes the first non-Egg party member.
do
  local nextCalls = 0
  local mon, idx = wrappers["fieldmove.eligibility"](
    function(moveId, ctx) nextCalls = nextCalls + 1; return nil end,
    "CUT", { save = save, data = data, party = save.party })
  assert(nextCalls == 1)
  assert(mon == save.party[2], "owned CUT should use first non-Egg helper")
  assert(idx == 2, "helper party index should survive")
end

-- WATERFALL / WHIRLPOOL are Gen 2 additions and must be covered.
for _, moveId in ipairs({ "WATERFALL", "WHIRLPOOL" }) do
  local mon = wrappers["fieldmove.eligibility"](
    function() return nil end, moveId,
    { save = save, data = data, party = save.party })
  assert(mon == save.party[2], moveId .. " should be eligible from owned HM")
end

-- A real move user always wins, including while CTX is later disabled.
do
  saved.contextualActions = false
  local real = { species = "TOTODILE" }
  local mon, idx = wrappers["fieldmove.eligibility"](
    function() return real, 6 end, "SURF",
    { save = save, data = data, party = save.party })
  assert(mon == real and idx == 6, "vanilla move user must be preserved")
  local missing = wrappers["fieldmove.eligibility"](
    function() return nil end, "CUT",
    { save = save, data = data, party = save.party })
  assert(missing == nil, "CTX OFF must not substitute an HM helper")
  saved.contextualActions = true
end

-- No owned HM: do not unlock the move.
do
  local noHmSave = { inventory = {}, party = save.party }
  local mon = wrappers["fieldmove.eligibility"](
    function() return nil end, "SURF",
    { save = noHmSave, data = data, party = save.party })
  assert(mon == nil)
end

-- Only the seven HM field rows are removed; Gen 2 utility field moves stay.
do
  local input = {
    { id = "CUT", label = "CUT", fieldMove = true },
    { id = "WATERFALL", label = "WATERFALL", fieldMove = true },
    { id = "HEADBUTT", label = "HEADBUTT", fieldMove = true },
    { id = "ROCK_SMASH", label = "ROCK SMASH", fieldMove = true },
    { id = "STATS", label = "STATS" },
  }
  local out = wrappers["ui.party.submenu"](
    function(_, items) return items end, {}, input, {}, { battle = false })
  local ids = {}
  for _, row in ipairs(out) do ids[row.id] = true end
  assert(not ids.CUT and not ids.WATERFALL)
  assert(ids.HEADBUTT and ids.ROCK_SMASH and ids.STATS)

  local battle = wrappers["ui.party.submenu"](
    function(_, items) return items end, {}, input, {}, { battle = true })
  assert(#battle == #input, "battle submenu must not be filtered")
end

-- Start -> HM is inserted only with an owned HM and creates a semantic Gen2 screen.
do
  local pushed
  local game = {
    save = save,
    data = data,
    stack = { push = function(_, state) pushed = state end },
  }
  local out = wrappers["ui.start_menu.items"](
    function(_, items) return items end, game,
    { { label = "POKéMON" }, { label = "SAVE" } })
  local hm
  for _, row in ipairs(out) do if row.label == "HM" then hm = row end end
  assert(hm and type(hm.onSelect) == "function")
  hm.onSelect(game)
  assert(pushed and pushed.screenId == "Gen2HmAnywhereMenu")
  assert(pushed.items == pushed.rows and type(pushed.index) == "number")
  local foundCut, foundWaterfall, foundWhirlpool, foundCtx = false, false, false, false
  for _, row in ipairs(pushed.items) do
    foundCut = foundCut or row.id == "CUT"
    foundWaterfall = foundWaterfall or row.id == "WATERFALL"
    foundWhirlpool = foundWhirlpool or row.id == "WHIRLPOOL"
    foundCtx = foundCtx or row.id == "CONTEXT"
  end
  assert(foundCut and foundWaterfall and foundWhirlpool and foundCtx)

  -- Manual CUT delegates to the native World:useFieldMove path.
  local calledMove, calledMon
  game.world = {
    useFieldMove = function(_, moveId, mon)
      calledMove, calledMon = moveId, mon
      return { ok = false }
    end,
  }
  pushed.index = 1
  pushed:choose()
  assert(calledMove == "CUT" and calledMon == save.party[2])

  -- Toggle updates both persistent state and visible row label.
  for i, row in ipairs(pushed.items) do
    if row.id == "CONTEXT" then pushed.index = i break end
  end
  pushed:choose()
  assert(saved.contextualActions == false)
  assert(pushed.items[pushed.index].label == "CTX OFF")


  -- Manual FLY uses the native destination picker and only queues the field
  -- move after a destination has been chosen.
  save.inventory.HM_FLY = 1
  data.items.HM_FLY = { machine = { kind = "HM", move = "FLY" } }
  local flyPushed
  local flyGame = {
    save = save, data = data,
    stack = {
      push = function(_, state) flyPushed = state end,
      clear = function() end,
    },
  }
  local chosenCb
  flyGame.world = {
    useFieldMove = function(self, moveId, mon)
      assert(moveId == "FLY")
      return { ok = true, action = "fly", mon = mon }
    end,
    openFlyMap = function(self, mon, opts)
      chosenCb = opts.onChosen
      return true
    end,
    exitMenusFadeForFly = function(self) self.flyFade = true end,
  }
  local flyOut = wrappers["ui.start_menu.items"](
    function(_, items) return items end, flyGame, { { label = "SAVE" } })
  local flyHm
  for _, row in ipairs(flyOut) do if row.label == "HM" then flyHm = row end end
  flyHm.onSelect(flyGame)
  local flyIndex
  for i, row in ipairs(flyPushed.items) do
    if row.id == "FLY" then flyIndex = i break end
  end
  assert(flyIndex, "FLY row should be listed when HM_FLY is owned")
  flyPushed.index = flyIndex
  flyPushed:choose()
  assert(type(chosenCb) == "function", "FLY must open the native picker")
  assert(flyGame.world.queuedFieldMove == nil, "FLY must not queue before destination")
  chosenCb("SPAWN_GOLDENROD")
  assert(flyGame.world.queuedFieldMove
    and flyGame.world.queuedFieldMove.flySpawn == "SPAWN_GOLDENROD")
  assert(flyGame.world.flyFade == true)

  local noHmGame = {
    save = { inventory = {}, party = save.party }, data = data,
  }
  local unchanged = wrappers["ui.start_menu.items"](
    function(_, items) return items end, noHmGame, { { label = "SAVE" } })
  assert(#unchanged == 1 and unchanged[1].label == "SAVE")
end

assert(type(eventHandlers["game.ready"]) == "function")
eventHandlers["game.ready"]({ game = { save = save, data = data } })
assert(#logs >= 1)

print("HM_ANYWHERE_GEN2_TEST_OK")
