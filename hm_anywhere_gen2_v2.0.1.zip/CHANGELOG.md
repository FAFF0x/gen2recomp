## 2.0.1

- Fixed native Gen 2 HM detection: use `HM_<MOVE>` / `item.teaches` instead of the Gen 1-only `item.machine` shape.
- Fixed contextual HM eligibility when the Gen 2 hook context does not provide `data.items`.
- Restored the Start -> HM menu whenever at least one supported HM is owned.
- Removed the stale `<2.0.0` engine-version cap from the manifest.

# Changelog

## 2.0.0

- Port nativo Gen 2 di HM Anywhere.
- Supportate tutte le HM Gen 2: CUT, FLY, SURF, STRENGTH, FLASH, WATERFALL, WHIRLPOOL.
- Uso senza insegnamento tramite `fieldmove.eligibility` per le azioni contestuali.
- Aggiunto Start → HM Gen 2 con uso manuale tramite il vero `World:useFieldMove`.
- Conservati i Badge Johto corretti e tutte le restrizioni native delle mappe.
- Conservato CTX ON / CTX OFF per abilitare/disabilitare soltanto il supplemento contestuale.
- Rimosse dal submenu Pokémon soltanto le righe field-move HM ridondanti; DIG, HEADBUTT,
  ROCK SMASH, SOFTBOILED/MILK DRINK, SWEET SCENT e TELEPORT restano invariati.
- Aggiunti WATERFALL e WHIRLPOOL rispetto alla versione Gen 1.
- Schermata HM predisposta per il presenter semantico di Gen2 Modern UI.
