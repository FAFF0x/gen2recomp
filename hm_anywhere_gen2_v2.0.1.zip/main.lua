-- HM Anywhere - Gen 2 v2.0.1
--
-- Owning the corresponding HM is enough to use a Gen 2 field move without
-- teaching it to a Pokemon. Badge, terrain, map, bike and visited-flypoint
-- restrictions remain owned by the native Gen 2 field-move engine.
--
-- Contextual actions are implemented through the engine's official
-- fieldmove.eligibility hook. Manual Start -> HM actions call the native
-- World:useFieldMove path, so the two modes cannot drift apart on rules.

local FIELD_HMS = {
  CUT = true,
  FLY = true,
  SURF = true,
  STRENGTH = true,
  FLASH = true,
  WATERFALL = true,
  WHIRLPOOL = true,
}

local HM_ORDER = {
  "CUT", "FLY", "SURF", "STRENGTH", "FLASH", "WATERFALL", "WHIRLPOOL",
}

local HM_LABEL = {
  CUT = "CUT",
  FLY = "FLY",
  SURF = "SURF",
  STRENGTH = "STRENGTH",
  FLASH = "FLASH",
  WATERFALL = "WATERFALL",
  WHIRLPOOL = "WHIRLPOOL",
}

local HM_ITEM_ALIASES = {
  CUT = { "HM_CUT", "HM_01", "HM01" },
  FLY = { "HM_FLY", "HM_02", "HM02" },
  SURF = { "HM_SURF", "HM_03", "HM03" },
  STRENGTH = { "HM_STRENGTH", "HM_04", "HM04" },
  FLASH = { "HM_FLASH", "HM_05", "HM05" },
  WHIRLPOOL = { "HM_WHIRLPOOL", "HM_06", "HM06" },
  WATERFALL = { "HM_WATERFALL", "HM_07", "HM07" },
}

local DEVICE_MON = {
  nickname = "HM DEVICE",
  name = "HM DEVICE",
  moves = {},
}

local function hasCount(value)
  if type(value) == "number" then return value > 0 end
  return value == true
end

-- Gen 2 HM ownership. Native Gen 2 records use item.teaches / tmLabel;
-- legacy item.machine is accepted only as a compatibility fallback.
local function ownedHM(save, data, moveId)
  local inventory = save and save.inventory or {}
  local items = data and data.items or {}

  -- Native Gen 2 data does NOT use Gen 1's item.machine record.  Gold /
  -- Silver / Crystal extract TM/HMs as HM_<MOVE> / TM_<MOVE>, with the taught
  -- move in item.teaches and the visible HM number in item.tmLabel.  Check the
  -- vanilla id first so fieldmove.eligibility also works when its Gen 2 ctx
  -- does not carry data.items.
  for _, nativeId in ipairs(HM_ITEM_ALIASES[moveId] or { "HM_" .. tostring(moveId) }) do
    if hasCount(inventory[nativeId]) then
      return nativeId, items[nativeId]
    end
  end

  -- Scan definitions as well so a content mod can provide another HM item id.
  -- The legacy machine branch is kept only as a compatibility fallback for
  -- old caches / mods that still expose the Gen 1-shaped record.
  for itemId, count in pairs(inventory) do
    if hasCount(count) then
      local def = items[itemId]
      if type(def) == "table" then
        local isHm = (type(itemId) == "string" and itemId:match("^HM_"))
          or (type(def.tmLabel) == "string" and def.tmLabel:match("^HM%d+"))
        if isHm and def.teaches == moveId then
          return itemId, def
        end
        local machine = def.machine
        if machine and machine.kind == "HM" and machine.move == moveId then
          return itemId, def
        end
      end
    end
  end
  return nil
end

local function hasAnyHM(game)
  local save, data = game and game.save, game and game.data
  for _, moveId in ipairs(HM_ORDER) do
    if ownedHM(save, data, moveId) then return true end
  end
  return false
end

-- CheckPartyMove in Gen 2 does not require HP > 0; it only skips Eggs.  Match
-- that behavior so an HM device does not accidentally add a stricter rule.
local function fieldHelper(party)
  for index, mon in ipairs(party or {}) do
    if type(mon) == "table" and mon.isEgg ~= true then return mon, index end
  end
  -- The feature promise is "HM in Bag is enough". A pathological all-Egg
  -- party therefore still gets a harmless presentation record. FieldMoves
  -- only needs a nickname/species for text/sprite presentation; all actual
  -- badge and map legality is checked independently by the engine.
  return DEVICE_MON, nil
end

local function contextualEnabled(mod)
  return mod.save:get("contextualActions", true) ~= false
end

local function setContextual(mod, enabled)
  mod.save:set("contextualActions", enabled and true or false)
end

local function removeRedundantHmRows(items)
  local out = {}
  for _, item in ipairs(items or {}) do
    if not (item.fieldMove and FIELD_HMS[item.id]) then
      out[#out + 1] = item
    end
  end
  return out
end

local function exitToField(game)
  local stack = game and game.stack
  if stack and stack.clear then stack:clear() end
  local world = game and game.world
  if world and world.exitMenusFade and not world.mapSetup then
    world:exitMenusFade()
  end
end

local function useManualFieldMove(game, moveId)
  local world = game and game.world
  local save = game and game.save
  if not (world and world.useFieldMove and save) then return false end

  local mon = fieldHelper(save.party)
  local result = world:useFieldMove(moveId, mon)
  if not (result and result.ok) then return false end

  -- FLY is the one menu HM whose successful result must open a destination
  -- picker before the queued action can run. This mirrors PartyMenu's native
  -- Gen 2 field-move branch, including the dedicated fly menu fade.
  if result.action == "fly" and world.openFlyMap then
    world.queuedFieldMove = nil
    local opened = world:openFlyMap(mon, {
      onChosen = function(spawnId)
        result.flySpawn = spawnId
        world.queuedFieldMove = result
        if world.exitMenusFadeForFly then
          world:exitMenusFadeForFly()
        elseif world.exitMenusFade then
          world:exitMenusFade()
        end
        local stack = game and game.stack
        if stack and stack.clear then stack:clear() end
      end,
      -- World:openFlyMap itself pops its Pokegear screen on cancel. The HM
      -- menu remains underneath, exactly like cancelling native FLY returns
      -- to the Pokemon menu.
      onCancel = function() end,
    })
    if opened then return true end
    -- Headless/older-cache fallback: let the normal queued path run.
    world.queuedFieldMove = result
  end

  exitToField(game)
  return true
end

-- -------------------------------------------------------------------------
-- Gen 2-native Start -> HM screen.
--
-- Public semantic fields (screenId/items/index/title/footer) are intentional:
-- Gen2 Modern UI can present this screen through its generic Gen2 presenter,
-- while the draw() below remains a faithful native fallback when Modern UI is
-- not installed.
-- -------------------------------------------------------------------------

local HmMenu = {}
HmMenu.__index = HmMenu
HmMenu.isOpaque = false

local function menuRows(game, mod)
  local rows = {}
  for _, moveId in ipairs(HM_ORDER) do
    if ownedHM(game and game.save, game and game.data, moveId) then
      rows[#rows + 1] = {
        id = moveId,
        moveId = moveId,
        label = HM_LABEL[moveId] or moveId,
      }
    end
  end
  rows[#rows + 1] = {
    id = "CONTEXT",
    label = contextualEnabled(mod) and "CTX ON" or "CTX OFF",
  }
  return rows
end

function HmMenu.new(game, mod)
  local self = setmetatable({}, HmMenu)
  self.game = game
  self.mod = mod
  self.screenId = "Gen2HmAnywhereMenu"
  self.title = "HM ANYWHERE"
  self.footer = "A use   B back"
  self.items = menuRows(game, mod)
  self.rows = self.items
  self.index = 1
  return self
end

function HmMenu:close()
  local stack = self.game and self.game.stack
  if stack and stack.pop then stack:pop() end
end

function HmMenu:choose()
  local row = self.items[self.index]
  if not row then return end
  if row.id == "CONTEXT" then
    local enabled = not contextualEnabled(self.mod)
    setContextual(self.mod, enabled)
    row.label = enabled and "CTX ON" or "CTX OFF"
    self.mod.log:info("HM Anywhere Gen 2 contextual actions: %s",
      enabled and "ON" or "OFF")
    return
  end
  useManualFieldMove(self.game, row.moveId)
end

function HmMenu:update(_dt)
  local input = self.game and self.game.input
  if not input or #self.items == 0 then return end
  if input:wasPressed("up") then
    self.index = self.index > 1 and self.index - 1 or #self.items
  elseif input:wasPressed("down") then
    self.index = self.index < #self.items and self.index + 1 or 1
  elseif input:wasPressed("a") or input:wasPressed("start") then
    self:choose()
  elseif input:wasPressed("b") then
    self:close()
  end
end

function HmMenu:draw()
  local Chrome = require("src.ui.gen2.Chrome")
  local count = #self.items
  local visible = math.min(count, 8)
  local top = math.max(0, math.min(self.index - 1, math.max(0, count - visible)))
  Chrome.box(5, 0, 15, 18)
  for slot = 1, visible do
    local i = top + slot
    local row = self.items[i]
    if row then
      local y = 1 + (slot - 1) * 2
      if i == self.index then Chrome.cursor(6, y) end
      Chrome.print(row.label or row.id or "?", 7, y)
    end
  end
  love.graphics.setColor(1, 1, 1, 1)
end

-- -------------------------------------------------------------------------

return function(mod)
  local liveGame
  -- The engine's Gen 2 FieldMoves.partyMoveUser calls this hook from the
  -- contextual OW paths. Preserve a real move user when one exists; only when
  -- vanilla found nobody do we substitute ownership of the HM in the Bag.
  mod.hooks:wrap("fieldmove.eligibility", function(next_, moveId, ctx)
    local mon, index = next_(moveId, ctx)
    if mon then return mon, index end
    if not FIELD_HMS[moveId] or not contextualEnabled(mod) then return nil end
    local data = (ctx and ctx.data) or (liveGame and liveGame.data)
    if not ownedHM(ctx and ctx.save, data, moveId) then return nil end
    return fieldHelper(ctx and ctx.party)
  end)

  -- Field HM rows on an individual Pokemon become redundant: Start -> HM is
  -- the manual path and contextual A uses the eligibility hook. HMs remain
  -- fully teachable and usable in battle; non-HM field moves stay untouched.
  mod.hooks:wrap("ui.party.submenu", function(next_, game, items, mon, ctx)
    local out = next_(game, items, mon, ctx)
    if type(out) ~= "table" or (ctx and ctx.battle) then return out end
    return removeRedundantHmRows(out)
  end)

  -- Start -> HM appears whenever at least one real HM is owned. The screen is
  -- pushed above StartMenu, so B naturally returns to StartMenu without
  -- rebuilding or duplicating it.
  mod.hooks:wrap("ui.start_menu.items", function(next_, game, items)
    local out = next_(game, items)
    if type(out) ~= "table" or not hasAnyHM(game) then return out end
    for _, item in ipairs(out) do
      if tostring(item.label or ""):upper() == "HM" then return out end
    end
    return mod.ui.insertBefore(out, "SAVE", {
      label = "HM",
      desc = { "Use owned HMs", "without teaching" },
      onSelect = function(liveGame)
        local stack = liveGame and liveGame.stack
        if stack and stack.push then stack:push(HmMenu.new(liveGame, mod)) end
      end,
    })
  end)

  mod.events:on("game.ready", function(event)
    local game = event and event.game
    if not game then return end
    liveGame = game
    mod.log:info(
      "HM Anywhere Gen 2 installed: CUT/FLY/SURF/STRENGTH/FLASH/WATERFALL/WHIRLPOOL; contextual actions %s",
      contextualEnabled(mod) and "ON" or "OFF")
  end)

  mod.exports.ownedHM = function(game, moveId)
    return ownedHM(game and game.save, game and game.data, moveId) ~= nil
  end
  mod.exports.contextualEnabled = function()
    return contextualEnabled(mod)
  end
  mod.exports.setContextual = function(enabled)
    setContextual(mod, enabled)
  end
  mod.exports.hasBadge = function(game, moveId)
    local ok, FieldMoves = pcall(require, "src.world.gen2.FieldMoves")
    if not ok then return false end
    local badge = FieldMoves.BADGE and FieldMoves.BADGE[moveId]
    return FieldMoves.hasBadge(game and game.save, badge)
  end
end
