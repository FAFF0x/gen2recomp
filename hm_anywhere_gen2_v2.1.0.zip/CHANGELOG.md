# Changelog

## 2.1.0

- Aggiunto Start -> TM con schermata semantica `Gen2TmAnywhereMenu`.
- Aggiunte tutte le TM da campo di Gold/Silver/Crystal: HEADBUTT (TM02),
  ROCK SMASH (TM08), SWEET SCENT (TM12) e DIG (TM28).
- Le quattro mosse funzionano possedendo la TM, senza insegnarla.
- HEADBUTT e ROCK SMASH funzionano anche tramite le interazioni contestuali.
- DIG conserva i controlli nativi CAVE/DUNGEON e il ritorno all'ingresso.
- Supportati record correnti `ITEM_nnn` / `item.machine` e cache legacy
  `TM_<MOVE>` / `item.teaches`.
- Il toggle CTX ora controlla sia HM sia TM da campo.
- Corretto il recupero della squadra da `save.party` nel contesto reale
  `fieldmove.eligibility`.

## 2.0.2

- Fixed Start -> HM on the native engine: the START-menu callback now retains
  its game context even when `Menu` calls `onSelect()` without arguments.
- Fixed the blank HM submenu by rendering through the native Gen 2
  `src.render.Font` / `src.ui.Theme` API.
- Kept `src.ui.gen2.Chrome` as a guarded compatibility fallback for UI mods
  that still expose it.
- Added regressions for argument-free menu selection and visible HM labels.

## 2.0.1

- Fixed native Gen 2 HM detection: use `HM_<MOVE>` / `item.teaches` instead of the Gen 1-only `item.machine` shape.
- Fixed contextual HM eligibility when the Gen 2 hook context does not provide `data.items`.
- Restored the Start -> HM menu whenever at least one supported HM is owned.
- Removed the stale `<2.0.0` engine-version cap from the manifest.

## 2.0.0

- Port nativo Gen 2 di HM Anywhere.
- Supportate tutte le HM Gen 2: CUT, FLY, SURF, STRENGTH, FLASH, WATERFALL, WHIRLPOOL.
- Uso senza insegnamento tramite `fieldmove.eligibility` per le azioni contestuali.
- Aggiunto Start → HM Gen 2 con uso manuale tramite il vero `World:useFieldMove`.
- Conservati i Badge Johto corretti e tutte le restrizioni native delle mappe.
- Conservato CTX ON / CTX OFF per abilitare/disabilitare soltanto il supplemento contestuale.
- Rimosse dal submenu Pokémon soltanto le righe field-move HM ridondanti; DIG, HEADBUTT,
  ROCK SMASH, SOFTBOILED/MILK DRINK, SWEET SCENT e TELEPORT restano invariati.
- Aggiunti WATERFALL e WHIRLPOOL rispetto alla versione Gen 1.
- Schermata HM predisposta per il presenter semantico di Gen2 Modern UI.
