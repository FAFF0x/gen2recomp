# HM & Field TM Anywhere - Gen 2

Port nativo Gen 2 di **HM Anywhere**, esteso alle TM da campo, per Pokémon
Gold / Silver / Crystal in Gen2Recomped.

## Funzione principale

Per usare una HM fuori dalla lotta **non devi più insegnarla a un Pokémon**.
È sufficiente possedere la relativa HM nella Bag.

La mod supporta tutte le sette HM da campo della Gen 2:

- **CUT**
- **FLY**
- **SURF**
- **STRENGTH**
- **FLASH**
- **WATERFALL**
- **WHIRLPOOL**

Supporta inoltre tutte le TM di Gold/Silver/Crystal che hanno una funzione
nativa nell'overworld:

- **TM02 – HEADBUTT**
- **TM08 – ROCK SMASH**
- **TM12 – SWEET SCENT**
- **TM28 – DIG**

È sufficiente conservare la relativa TM nella Bag; non serve insegnarla.
TELEPORT, SOFTBOILED e MILK DRINK non sono incluse perché in seconda
generazione non sono TM.

## Badge e restrizioni NON vengono rimossi

HM Anywhere sostituisce soltanto il requisito "un Pokémon deve conoscere la mossa".
Tutto il resto continua a essere deciso dal motore Gen 2 originale.

Badge richiesti:

- CUT → **HIVE BADGE**
- FLASH → **ZEPHYR BADGE**
- SURF → **FOG BADGE**
- FLY → **STORM BADGE**
- STRENGTH → **PLAIN BADGE**
- WHIRLPOOL → **GLACIER BADGE**
- WATERFALL → **RISING BADGE**

Restano inoltre valide le normali restrizioni di terreno e mappa: FLY solo dove consentito,
SURF solo sull'acqua valida, FLASH nelle aree appropriate, WATERFALL/WHIRLPOOL sui relativi
tiles, ecc.

## Start → HM

Se possiedi almeno una HM, nel menu START compare **HM**.
Il sottomenu mostra dinamicamente solo le HM realmente possedute e permette di usarle
senza scegliere un Pokémon.

La schermata espone `screenId = Gen2HmAnywhereMenu` e campi semantici `items/index`, quindi
**Gen2 Modern UI** può modernizzarla senza una patch dedicata.

## Start → TM

Se possiedi almeno una delle quattro TM da campo, nel menu START compare
**TM**. La schermata `Gen2TmAnywhereMenu` mostra soltanto le TM possedute:

- HEADBUTT controlla l'albero di fronte al giocatore;
- ROCK SMASH controlla la roccia frantumabile di fronte al giocatore;
- SWEET SCENT cerca un incontro nella zona corrente;
- DIG funziona soltanto in CAVE/DUNGEON con un ingresso registrato e riporta
  correttamente all'uscita.

Le TM non vengono consumate quando si usa la loro mossa nell'overworld.

## CTX ON / CTX OFF

Nel menu HM è presente il toggle:

- **CTX ON**: le normali azioni contestuali Gen 2 possono usare la HM/TM
  posseduta anche se nessun Pokémon conosce la mossa. Oltre alle HM, questo
  abilita direttamente HEADBUTT sugli alberi e ROCK SMASH sulle rocce.
- **CTX OFF**: le interazioni contestuali tornano vanilla; un Pokémon che conosce davvero
  la mossa continua naturalmente a funzionare. Start → HM e Start → TM
  continuano invece a usare le macchine direttamente dalla Bag.

La preferenza è salvata tramite il sistema di save della mod.

## Compatibilità

La mod non sostituisce PartyMenu, StartMenu o le routine dei field move. Usa
gli hook `fieldmove.eligibility`, `ui.party.submenu` e
`ui.start_menu.items`; le TM delegano a `gen2FieldMoveAt` e al percorso
nativo di DIG. Questo mantiene testi, animazioni e regole di
Gold/Silver/Crystal.

Le HM restano insegnabili e utilizzabili normalmente in battaglia.
Lo stesso vale per le TM.

## Novità v2.1.0

- Nuovo menu START → TM.
- Uso senza insegnamento di HEADBUTT, ROCK SMASH, SWEET SCENT e DIG.
- Supporto sia agli ID leggibili (`TM_HEADBUTT`) sia ai record nativi
  `ITEM_nnn` con `item.machine`.
- Le interazioni contestuali riconoscono anche le TM possedute.


## Fix v2.0.2

La v2.0.1 dipendeva da due comportamenti non presenti nel motore Gen 2
attuale: si aspettava che il menu START passasse `game` alla callback HM e
provava a disegnare il sottomenu con `src.ui.gen2.Chrome`. Il risultato poteva
essere la mancata apertura del menu oppure una schermata senza le HM.

La v2.0.2 conserva il contesto di gioco ricevuto dall'hook START e usa il
renderer nativo `src.render.Font` / `src.ui.Theme`, mantenendo un fallback
protetto per le UI che espongono ancora `Chrome`.

## Fix v2.0.1

La v2.0.0 cercava erroneamente `item.machine`, una struttura Gen 1.
I dati nativi Gen 2 usano invece `HM_<MOVE>`, `item.teaches`, `item.tmNumber` e `item.tmLabel`.
La v2.0.1 riconosce quindi correttamente le HM possedute e ripristina sia **Start → HM** sia le azioni contestuali.
