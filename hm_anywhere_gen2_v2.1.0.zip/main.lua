-- HM & Field TM Anywhere - Gen 2 v2.1.0
--
-- Owning the corresponding HM or overworld-capable TM is enough to use its
-- Gen 2 field move without teaching it to a Pokemon. Badge, terrain, map,
-- bike and visited-flypoint restrictions remain owned by the native engine.
--
-- Contextual actions are implemented through the engine's official
-- fieldmove.eligibility hook. Manual actions delegate to the engine's native
-- field-move entry points, so map and terrain rules remain authoritative.

local FIELD_HMS = {
  CUT = true,
  FLY = true,
  SURF = true,
  STRENGTH = true,
  FLASH = true,
  WATERFALL = true,
  WHIRLPOOL = true,
}

-- The four Generation 2 TMs whose moves have native overworld behavior.
-- TELEPORT, SOFTBOILED and MILK DRINK can also be field moves, but none of
-- them is a TM in Gold/Silver/Crystal and therefore does not belong here.
local FIELD_TMS = {
  HEADBUTT = true,
  ROCK_SMASH = true,
  SWEET_SCENT = true,
  DIG = true,
}

local HM_ORDER = {
  "CUT", "FLY", "SURF", "STRENGTH", "FLASH", "WATERFALL", "WHIRLPOOL",
}

local TM_ORDER = {
  "HEADBUTT", "ROCK_SMASH", "SWEET_SCENT", "DIG",
}

local HM_LABEL = {
  CUT = "CUT",
  FLY = "FLY",
  SURF = "SURF",
  STRENGTH = "STRENGTH",
  FLASH = "FLASH",
  WATERFALL = "WATERFALL",
  WHIRLPOOL = "WHIRLPOOL",
}

local TM_LABEL = {
  HEADBUTT = "HEADBUTT",
  ROCK_SMASH = "ROCK SMASH",
  SWEET_SCENT = "SWEET SCENT",
  DIG = "DIG",
}

local HM_ITEM_ALIASES = {
  CUT = { "HM_CUT", "HM_01", "HM01" },
  FLY = { "HM_FLY", "HM_02", "HM02" },
  SURF = { "HM_SURF", "HM_03", "HM03" },
  STRENGTH = { "HM_STRENGTH", "HM_04", "HM04" },
  FLASH = { "HM_FLASH", "HM_05", "HM05" },
  WHIRLPOOL = { "HM_WHIRLPOOL", "HM_06", "HM06" },
  WATERFALL = { "HM_WATERFALL", "HM_07", "HM07" },
}

local TM_ITEM_ALIASES = {
  HEADBUTT = { "TM_HEADBUTT", "TM_02", "TM02" },
  ROCK_SMASH = { "TM_ROCK_SMASH", "TM_08", "TM08" },
  SWEET_SCENT = { "TM_SWEET_SCENT", "TM_12", "TM12" },
  DIG = { "TM_DIG", "TM_28", "TM28" },
}

local DEVICE_MON = {
  nickname = "HM DEVICE",
  name = "HM DEVICE",
  moves = {},
}

local TM_DEVICE_MON = {
  nickname = "TM DEVICE",
  name = "TM DEVICE",
  moves = {},
}

local function hasCount(value)
  if type(value) == "number" then return value > 0 end
  return value == true
end

-- Gen 2 HM ownership across current item.machine records, earlier
-- item.teaches/tmLabel caches and readable aliases supplied by content mods.
local function ownedHM(save, data, moveId)
  local inventory = save and save.inventory or {}
  local items = data and data.items or {}

  -- Check readable aliases first so fieldmove.eligibility also works when an
  -- earlier Gen 2 hook context does not carry data.items.
  for _, nativeId in ipairs(HM_ITEM_ALIASES[moveId] or { "HM_" .. tostring(moveId) }) do
    if hasCount(inventory[nativeId]) then
      return nativeId, items[nativeId]
    end
  end

  -- Scan definitions as well: current native GSC imports use ITEM_nnn ids and
  -- carry their machine identity inside the definition.
  for itemId, count in pairs(inventory) do
    if hasCount(count) then
      local def = items[itemId]
      if type(def) == "table" then
        local isHm = (type(itemId) == "string" and itemId:match("^HM_"))
          or (type(def.tmLabel) == "string" and def.tmLabel:match("^HM%d+"))
        if isHm and def.teaches == moveId then
          return itemId, def
        end
        local machine = def.machine
        if machine and machine.kind == "HM" and machine.move == moveId then
          return itemId, def
        end
      end
    end
  end
  return nil
end

-- Field-TM ownership across the data shapes used by current Gen2Recomped,
-- older caches and content mods. Current native ITEM_nnn records carry
-- item.machine; earlier builds exposed item.teaches / item.tmLabel, while
-- some mods use readable TM_<MOVE> ids directly.
local function ownedTM(save, data, moveId)
  local inventory = save and save.inventory or {}
  local items = data and data.items or {}

  for _, alias in ipairs(TM_ITEM_ALIASES[moveId] or {}) do
    if hasCount(inventory[alias]) then return alias, items[alias] end
  end

  for itemId, count in pairs(inventory) do
    if hasCount(count) then
      local def = items[itemId]
      if type(def) == "table" then
        local machine = def.machine
        if machine and machine.kind == "TM" and machine.move == moveId then
          return itemId, def
        end
        local isTm = (type(itemId) == "string" and itemId:match("^TM_"))
          or (type(def.key) == "string" and def.key:match("^TM_?%d+"))
          or (type(def.tmLabel) == "string" and def.tmLabel:match("^TM%d+"))
        if isTm and def.teaches == moveId then return itemId, def end
      end
    end
  end
  return nil
end

local function hasAnyHM(game)
  local save, data = game and game.save, game and game.data
  for _, moveId in ipairs(HM_ORDER) do
    if ownedHM(save, data, moveId) then return true end
  end
  return false
end

local function hasAnyTM(game)
  local save, data = game and game.save, game and game.data
  for _, moveId in ipairs(TM_ORDER) do
    if ownedTM(save, data, moveId) then return true end
  end
  return false
end

-- CheckPartyMove in Gen 2 does not require HP > 0; it only skips Eggs.  Match
-- that behavior so an HM device does not accidentally add a stricter rule.
local function fieldHelper(party, fallback)
  for index, mon in ipairs(party or {}) do
    if type(mon) == "table" and mon.isEgg ~= true then return mon, index end
  end
  -- The feature promise is "HM in Bag is enough". A pathological all-Egg
  -- party therefore still gets a harmless presentation record. FieldMoves
  -- only needs a nickname/species for text/sprite presentation; all actual
  -- badge and map legality is checked independently by the engine.
  return fallback or DEVICE_MON, nil
end

local function contextualEnabled(mod)
  return mod.save:get("contextualActions", true) ~= false
end

local function setContextual(mod, enabled)
  mod.save:set("contextualActions", enabled and true or false)
end

local function removeRedundantHmRows(items)
  local out = {}
  for _, item in ipairs(items or {}) do
    if not (item.fieldMove and FIELD_HMS[item.id]) then
      out[#out + 1] = item
    end
  end
  return out
end

local function exitToField(game)
  local stack = game and game.stack
  if stack and stack.clear then stack:clear() end
  local world = game and game.world
  if world and world.exitMenusFade and not world.mapSetup then
    world:exitMenusFade()
  end
end

local function useManualFieldMove(game, moveId)
  local world = game and game.world
  local save = game and game.save
  if not (world and world.useFieldMove and save) then return false end

  local mon = fieldHelper(save.party)
  local result = world:useFieldMove(moveId, mon)
  if not (result and result.ok) then return false end

  -- FLY is the one menu HM whose successful result must open a destination
  -- picker before the queued action can run. This mirrors PartyMenu's native
  -- Gen 2 field-move branch, including the dedicated fly menu fade.
  if result.action == "fly" and world.openFlyMap then
    world.queuedFieldMove = nil
    local opened = world:openFlyMap(mon, {
      onChosen = function(spawnId)
        result.flySpawn = spawnId
        world.queuedFieldMove = result
        if world.exitMenusFadeForFly then
          world:exitMenusFadeForFly()
        elseif world.exitMenusFade then
          world:exitMenusFade()
        end
        local stack = game and game.stack
        if stack and stack.clear then stack:clear() end
      end,
      -- World:openFlyMap itself pops its Pokegear screen on cancel. The HM
      -- menu remains underneath, exactly like cancelling native FLY returns
      -- to the Pokemon menu.
      onCancel = function() end,
    })
    if opened then return true end
    -- Headless/older-cache fallback: let the normal queued path run.
    world.queuedFieldMove = result
  end

  exitToField(game)
  return true
end

local DIG_TILESETS = {
  FOREST = true, CEMETERY = true, CAVERN = true,
  FACILITY = true, INTERIOR = true,
}
local GEN2_DIG_ENVIRONMENTS = { [4] = true, [7] = true }

local function closeMenuState(game, menu)
  local stack = game and game.stack
  if not (stack and stack.pop) then return end
  if stack.top then
    local ok, top = pcall(stack.top, stack)
    if ok and top ~= nil and top ~= menu then return end
  end
  stack:pop()
end

local function showCannotUse(game)
  local stack = game and game.stack
  if not (stack and stack.push) then return end
  local ok, TextBox = pcall(require, "src.render.TextBox")
  if ok and TextBox and type(TextBox.new) == "function" then
    stack:push(TextBox.new(game, "You can't use that\nhere."))
  end
end

local function canDigHere(world)
  local map = world and world.map
  local def = map and map.def
  if not def or map.id == "AGATHAS_ROOM" then return false end
  local environment = def.environment
  local validEnvironment = GEN2_DIG_ENVIRONMENTS[environment]
    or environment == "CAVE" or environment == "DUNGEON"
    or DIG_TILESETS[def.tileset]
  if not validEnvironment or not world.escapePoint then return false end
  return world:escapePoint() ~= nil
end

-- Current Gen2Recomped exposes native HEADBUTT/ROCK SMASH/SWEET SCENT via
-- gen2FieldMoveAt and DIG via beginTeleportOut. Older compatible builds may
-- expose the generic World:useFieldMove path, retained as a final fallback.
local function useManualTmMove(game, moveId, menu)
  local world = game and (game.world or game.overworld)
  local save = game and game.save
  if not (world and save) then return false end
  local mon = fieldHelper(save.party, TM_DEVICE_MON)

  if moveId == "DIG" and world.beginTeleportOut then
    closeMenuState(game, menu)
    if not canDigHere(world) then
      showCannotUse(game)
      return false
    end
    world:beginTeleportOut(nil, { escape = true })
    return true
  end

  if world.gen2FieldMoveAt and world.player and world.player.facingCell then
    local fx, fy = world.player:facingCell()
    closeMenuState(game, menu)
    local used = world:gen2FieldMoveAt(moveId, mon, fx, fy)
    if not used then showCannotUse(game) end
    return used and true or false
  end

  if world.useFieldMove then
    -- useManualFieldMove reads game.world; normalize an overworld-only game
    -- for older presenter integrations without changing its identity.
    if not game.world then game.world = world end
    return useManualFieldMove(game, moveId)
  end

  closeMenuState(game, menu)
  showCannotUse(game)
  return false
end

-- -------------------------------------------------------------------------
-- Gen 2-native Start -> HM / TM screens.
--
-- Public semantic fields (screenId/items/index/title/footer) are intentional:
-- Gen2 Modern UI can present this screen through its generic Gen2 presenter,
-- while the draw() below remains a faithful native fallback when Modern UI is
-- not installed.
-- -------------------------------------------------------------------------

local HmMenu = {}
HmMenu.__index = HmMenu
HmMenu.isOpaque = false

local function hmMenuRows(game, mod)
  local rows = {}
  for _, moveId in ipairs(HM_ORDER) do
    if ownedHM(game and game.save, game and game.data, moveId) then
      rows[#rows + 1] = {
        id = moveId,
        moveId = moveId,
        label = HM_LABEL[moveId] or moveId,
      }
    end
  end
  rows[#rows + 1] = {
    id = "CONTEXT",
    label = contextualEnabled(mod) and "CTX ON" or "CTX OFF",
  }
  return rows
end

function HmMenu.new(game, mod)
  local self = setmetatable({}, HmMenu)
  self.game = game
  self.mod = mod
  self.screenId = "Gen2HmAnywhereMenu"
  self.title = "HM ANYWHERE"
  self.footer = "A use   B back"
  self.items = hmMenuRows(game, mod)
  self.rows = self.items
  self.index = 1
  return self
end

function HmMenu:close()
  local stack = self.game and self.game.stack
  if stack and stack.pop then stack:pop() end
end

function HmMenu:choose()
  local row = self.items[self.index]
  if not row then return end
  if row.id == "CONTEXT" then
    local enabled = not contextualEnabled(self.mod)
    setContextual(self.mod, enabled)
    row.label = enabled and "CTX ON" or "CTX OFF"
    self.mod.log:info("HM Anywhere Gen 2 contextual actions: %s",
      enabled and "ON" or "OFF")
    return
  end
  useManualFieldMove(self.game, row.moveId)
end

function HmMenu:update(_dt)
  local input = self.game and self.game.input
  if not input or #self.items == 0 then return end
  if input:wasPressed("up") then
    self.index = self.index > 1 and self.index - 1 or #self.items
  elseif input:wasPressed("down") then
    self.index = self.index < #self.items and self.index + 1 or 1
  elseif input:wasPressed("a") or input:wasPressed("start") then
    self:choose()
  elseif input:wasPressed("b") then
    self:close()
  end
end

function HmMenu:draw()
  local count = #self.items
  local visible = math.min(count, 8)
  local top = math.max(0, math.min(self.index - 1, math.max(0, count - visible)))

  -- Gen2Recomped exposes its native menu renderer through Font/Theme.  The
  -- old src.ui.gen2.Chrome path is retained only as a compatibility fallback
  -- for builds or UI mods that provide it.
  local okFont, Font = pcall(require, "src.render.Font")
  local okTheme, Theme = pcall(require, "src.ui.Theme")
  if okFont and okTheme and Font and Theme
      and type(Font.drawBox) == "function"
      and type(Font.draw) == "function"
      and type(Font.drawCode) == "function" then
    Font.drawBox(5, 0, 15, 18)
    if love and love.graphics and love.graphics.setColor then
      love.graphics.setColor(0, 0, 0, 1)
    end
    for slot = 1, visible do
      local i = top + slot
      local row = self.items[i]
      if row then
        local y = 1 + (slot - 1) * 2
        Font.draw(row.label or row.id or "?", 7 * 8, y * 8)
        if i == self.index then
          Font.drawCode(Theme.cursor or 0xED, 6 * 8, y * 8)
        end
      end
    end
  else
    local okChrome, Chrome = pcall(require, "src.ui.gen2.Chrome")
    if okChrome and Chrome and type(Chrome.box) == "function"
        and type(Chrome.cursor) == "function"
        and type(Chrome.print) == "function" then
      Chrome.box(5, 0, 15, 18)
      for slot = 1, visible do
        local i = top + slot
        local row = self.items[i]
        if row then
          local y = 1 + (slot - 1) * 2
          if i == self.index then Chrome.cursor(6, y) end
          Chrome.print(row.label or row.id or "?", 7, y)
        end
      end
    end
  end
  if love and love.graphics and love.graphics.setColor then
    love.graphics.setColor(1, 1, 1, 1)
  end
end

local TmMenu = {}
TmMenu.__index = TmMenu
TmMenu.isOpaque = false

local function tmMenuRows(game, mod)
  local rows = {}
  for _, moveId in ipairs(TM_ORDER) do
    local itemId = ownedTM(game and game.save, game and game.data, moveId)
    if itemId then
      rows[#rows + 1] = {
        id = moveId,
        moveId = moveId,
        itemId = itemId,
        label = TM_LABEL[moveId] or moveId,
      }
    end
  end
  rows[#rows + 1] = {
    id = "CONTEXT",
    label = contextualEnabled(mod) and "CTX ON" or "CTX OFF",
  }
  return rows
end

function TmMenu.new(game, mod)
  local self = setmetatable({}, TmMenu)
  self.game = game
  self.mod = mod
  self.screenId = "Gen2TmAnywhereMenu"
  self.title = "TM ANYWHERE"
  self.footer = "A use   B back"
  self.items = tmMenuRows(game, mod)
  self.rows = self.items
  self.index = 1
  return self
end

function TmMenu:close()
  return HmMenu.close(self)
end

function TmMenu:choose()
  local row = self.items[self.index]
  if not row then return end
  if row.id == "CONTEXT" then
    local enabled = not contextualEnabled(self.mod)
    setContextual(self.mod, enabled)
    row.label = enabled and "CTX ON" or "CTX OFF"
    self.mod.log:info("Field TM Anywhere Gen 2 contextual actions: %s",
      enabled and "ON" or "OFF")
    return
  end
  useManualTmMove(self.game, row.moveId, self)
end

function TmMenu:update(dt)
  return HmMenu.update(self, dt)
end

function TmMenu:draw()
  return HmMenu.draw(self)
end

-- -------------------------------------------------------------------------

return function(mod)
  local liveGame
  -- Contextual OW paths call this hook through OverworldState:partyKnows.
  -- Preserve a real move user when one exists; only when vanilla found nobody
  -- do we substitute ownership of the corresponding HM or field TM in Bag.
  mod.hooks:wrap("fieldmove.eligibility", function(next_, moveId, ctx)
    local mon, index = next_(moveId, ctx)
    if mon then return mon, index end
    if not contextualEnabled(mod) then return nil end
    local data = (ctx and ctx.data) or (liveGame and liveGame.data)
    local save = ctx and ctx.save
    local fallback
    if FIELD_HMS[moveId] then
      if not ownedHM(save, data, moveId) then return nil end
      fallback = DEVICE_MON
    elseif FIELD_TMS[moveId] then
      if not ownedTM(save, data, moveId) then return nil end
      fallback = TM_DEVICE_MON
    else
      return nil
    end
    local party = (ctx and ctx.party) or (save and save.party)
    return fieldHelper(party, fallback)
  end)

  -- Field HM rows on an individual Pokemon become redundant: Start -> HM is
  -- the manual path and contextual A uses the eligibility hook. HMs remain
  -- fully teachable and usable in battle; non-HM field moves stay untouched.
  mod.hooks:wrap("ui.party.submenu", function(next_, game, items, mon, ctx)
    local out = next_(game, items, mon, ctx)
    if type(out) ~= "table" or (ctx and ctx.battle) then return out end
    return removeRedundantHmRows(out)
  end)

  -- Start -> HM and Start -> TM appear independently according to the
  -- machines currently owned. Both callbacks capture the hook's game because
  -- the native Menu invokes onSelect() with no arguments.
  mod.hooks:wrap("ui.start_menu.items", function(next_, game, items)
    local out = next_(game, items)
    if type(out) ~= "table" then return out end

    local function hasLabel(label)
      for _, item in ipairs(out) do
        if tostring(item.label or ""):upper() == label then return true end
      end
      return false
    end

    local function activeGame(selectedGame)
      if type(selectedGame) == "table" and selectedGame.save
          and selectedGame.stack then
        return selectedGame
      end
      return game or liveGame
    end

    if hasAnyHM(game) and not hasLabel("HM") then
      out = mod.ui.insertBefore(out, "SAVE", {
        label = "HM",
        desc = { "Use owned HMs", "without teaching" },
        onSelect = function(selectedGame)
          local current = activeGame(selectedGame)
          local stack = current and current.stack
          if stack and stack.push then stack:push(HmMenu.new(current, mod)) end
        end,
      }) or out
    end

    if hasAnyTM(game) and not hasLabel("TM") then
      out = mod.ui.insertBefore(out, "SAVE", {
        label = "TM",
        desc = { "Use field TMs", "without teaching" },
        onSelect = function(selectedGame)
          local current = activeGame(selectedGame)
          local stack = current and current.stack
          if stack and stack.push then stack:push(TmMenu.new(current, mod)) end
        end,
      }) or out
    end

    return out
  end)

  mod.events:on("game.ready", function(event)
    local game = event and event.game
    if not game then return end
    liveGame = game
    mod.log:info(
      "HM & Field TM Anywhere Gen 2 installed: 7 HMs + HEADBUTT/ROCK SMASH/SWEET SCENT/DIG; contextual actions %s",
      contextualEnabled(mod) and "ON" or "OFF")
  end)

  mod.exports.ownedHM = function(game, moveId)
    return ownedHM(game and game.save, game and game.data, moveId) ~= nil
  end
  mod.exports.ownedTM = function(game, moveId)
    return ownedTM(game and game.save, game and game.data, moveId) ~= nil
  end
  mod.exports.fieldTMs = function()
    local out = {}
    for i, moveId in ipairs(TM_ORDER) do out[i] = moveId end
    return out
  end
  mod.exports.contextualEnabled = function()
    return contextualEnabled(mod)
  end
  mod.exports.setContextual = function(enabled)
    setContextual(mod, enabled)
  end
  mod.exports.hasBadge = function(game, moveId)
    if FIELD_TMS[moveId] then return true end
    if not FIELD_HMS[moveId] then return false end
    local okDefaults, FieldDefaults = pcall(require, "src.world.FieldDefaults")
    local okBadges, Badges = pcall(require, "src.inventory.Badges")
    if not (okDefaults and okBadges and game) then return false end
    local gates = FieldDefaults.constant(game.data, "hmBadges") or {}
    local gate = gates[moveId]
    if not (gate and gate.badge) then return true end
    return Badges.has(game.save, { id = gate.badge }) and true or false
  end
end
