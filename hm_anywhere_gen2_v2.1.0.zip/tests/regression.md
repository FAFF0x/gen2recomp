# HM & Field TM Anywhere Gen 2 regression checklist

- HM detection uses `item.machine.kind == "HM"` + `machine.move`.
- A real party move user always wins over HM Anywhere.
- CTX ON substitutes an HM-device helper only for owned HM moves.
- CTX OFF restores vanilla contextual eligibility when nobody knows the move.
- WATERFALL and WHIRLPOOL are included.
- Party submenu removes only HM field rows, never Gen 2 TM/utility field moves.
- Start menu gets one HM row only when at least one HM is owned.
- Manual use calls `World:useFieldMove`, so badges/map restrictions stay native.
- FLY opens the native Gen 2 fly picker and preserves the queued field move.
- Custom HM screen exposes `Gen2HmAnywhereMenu`, `items`, `rows`, and `index` for Modern UI.
- Start menu gets one TM row only when at least one supported field TM is owned.
- TM screen exposes `Gen2TmAnywhereMenu`, `items`, `rows`, and `index`.
- TM02 HEADBUTT, TM08 ROCK SMASH, TM12 SWEET SCENT and TM28 DIG are listed.
- Native `ITEM_nnn` + `item.machine` and legacy readable TM ids are detected.
- CTX ON supplies a helper for owned field TMs; CTX OFF restores vanilla.
- HEADBUTT/ROCK SMASH/SWEET SCENT use `gen2FieldMoveAt`.
- DIG works only in a valid cave/dungeon with an escape point and calls
  `beginTeleportOut(..., { escape = true })`.
