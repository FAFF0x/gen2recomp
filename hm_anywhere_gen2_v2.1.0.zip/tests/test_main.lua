local root = os.getenv("HM_ANYWHERE_ROOT")
assert(root and root ~= "", "pass mod root")

local wrappers = {}
local eventHandlers = {}
local saved = {}
local logs = {}
local mod = {
  hooks = {
    wrap = function(_, name, fn)
      wrappers[name] = fn
      return function() wrappers[name] = nil end
    end,
  },
  events = {
    on = function(_, name, fn) eventHandlers[name] = fn end,
  },
  save = {
    get = function(_, key, default)
      local v = saved[key]
      if v == nil then return default end
      return v
    end,
    set = function(_, key, value) saved[key] = value end,
  },
  ui = {
    insertBefore = function(items, anchor, item)
      local out, inserted = {}, false
      for _, row in ipairs(items) do
        if not inserted and tostring(row.label or "") == anchor then
          out[#out + 1] = item
          inserted = true
        end
        out[#out + 1] = row
      end
      if not inserted then out[#out + 1] = item end
      return out
    end,
  },
  log = {
    info = function(_, fmt, ...)
      logs[#logs + 1] = string.format(fmt, ...)
    end,
  },
  exports = {},
}

local init = assert(loadfile(root .. "/main.lua"))()
assert(type(init) == "function")
init(mod)

assert(type(wrappers["fieldmove.eligibility"]) == "function")
assert(type(wrappers["ui.party.submenu"]) == "function")
assert(type(wrappers["ui.start_menu.items"]) == "function")

local data = { items = {
  -- Native Gen 2 extractor shape: no item.machine record.
  HM_CUT = { teaches = "CUT", tmNumber = 51, tmLabel = "HM01" },
  HM_SURF = { teaches = "SURF", tmNumber = 53, tmLabel = "HM03" },
  HM_WATERFALL = { teaches = "WATERFALL", tmNumber = 57, tmLabel = "HM07" },
  HM_WHIRLPOOL = { teaches = "WHIRLPOOL", tmNumber = 56, tmLabel = "HM06" },
  ITEM_250 = {
    key = "HM_05",
    machine = { kind = "HM", move = "FLASH", number = 5 },
  },
  -- Both supported field-TM shapes: readable legacy ids and current native
  -- ITEM_nnn records carrying item.key + item.machine.
  TM_HEADBUTT = { teaches = "HEADBUTT", tmNumber = 2, tmLabel = "TM02" },
  ITEM_199 = {
    key = "TM_08",
    machine = { kind = "TM", move = "ROCK_SMASH", number = 8 },
  },
  ITEM_203 = {
    key = "TM_12",
    machine = { kind = "TM", move = "SWEET_SCENT", number = 12 },
  },
  TM_DIG = { teaches = "DIG", tmNumber = 28, tmLabel = "TM28" },
} }
local save = {
  inventory = {
    HM_CUT = 1, HM_WATERFALL = 1, HM_WHIRLPOOL = 1,
    ITEM_250 = 1,
    TM_HEADBUTT = 1, ITEM_199 = 1, ITEM_203 = 1, TM_DIG = 1,
  },
  party = {
    { isEgg = true, species = "TOGEPI" },
    { species = "CYNDAQUIL", hp = 0, moves = {} },
  },
}

-- CTX defaults ON: owned HM substitutes the first non-Egg party member.
do
  local nextCalls = 0
  local mon, idx = wrappers["fieldmove.eligibility"](
    function(moveId, ctx) nextCalls = nextCalls + 1; return nil end,
    -- Gen 2's hook ctx may omit data; native HM_<MOVE> detection must still work.
    "CUT", { save = save, party = save.party })
  assert(nextCalls == 1)
  assert(mon == save.party[2], "owned CUT should use first non-Egg helper")
  assert(idx == 2, "helper party index should survive")
end

-- WATERFALL / WHIRLPOOL are Gen 2 additions; FLASH also exercises the
-- current native ITEM_nnn + item.machine shape.
for _, moveId in ipairs({ "WATERFALL", "WHIRLPOOL", "FLASH" }) do
  local mon = wrappers["fieldmove.eligibility"](
    function() return nil end, moveId,
    { save = save, data = data, party = save.party })
  assert(mon == save.party[2], moveId .. " should be eligible from owned HM")
end

-- Owned overworld TMs use the same contextual eligibility hook. Current
-- OverworldState supplies save/data but no separate ctx.party field, so the
-- party must also be recovered from save.party.
for _, moveId in ipairs({ "HEADBUTT", "ROCK_SMASH", "SWEET_SCENT", "DIG" }) do
  local mon, idx = wrappers["fieldmove.eligibility"](
    function() return nil end, moveId, { save = save, data = data })
  assert(mon == save.party[2], moveId .. " should be eligible from its owned TM")
  assert(idx == 2, moveId .. " should preserve the helper party index")
end

-- A real move user always wins, including while CTX is later disabled.
do
  saved.contextualActions = false
  local real = { species = "TOTODILE" }
  local mon, idx = wrappers["fieldmove.eligibility"](
    function() return real, 6 end, "SURF",
    { save = save, data = data, party = save.party })
  assert(mon == real and idx == 6, "vanilla move user must be preserved")
  local missing = wrappers["fieldmove.eligibility"](
    function() return nil end, "CUT",
    { save = save, data = data, party = save.party })
  assert(missing == nil, "CTX OFF must not substitute an HM helper")
  local missingTm = wrappers["fieldmove.eligibility"](
    function() return nil end, "HEADBUTT",
    { save = save, data = data, party = save.party })
  assert(missingTm == nil, "CTX OFF must not substitute a TM helper")
  saved.contextualActions = true
end

-- No owned HM: do not unlock the move.
do
  local noHmSave = { inventory = {}, party = save.party }
  local mon = wrappers["fieldmove.eligibility"](
    function() return nil end, "SURF",
    { save = noHmSave, data = data, party = save.party })
  assert(mon == nil)
end


-- An unowned field TM is never unlocked.
do
  local noTmSave = {
    inventory = { HM_CUT = 1 },
    party = save.party,
  }
  local mon = wrappers["fieldmove.eligibility"](
    function() return nil end, "HEADBUTT",
    { save = noTmSave, data = data, party = save.party })
  assert(mon == nil)
end

-- Only the seven HM field rows are removed; Gen 2 utility field moves stay.
do
  local input = {
    { id = "CUT", label = "CUT", fieldMove = true },
    { id = "WATERFALL", label = "WATERFALL", fieldMove = true },
    { id = "HEADBUTT", label = "HEADBUTT", fieldMove = true },
    { id = "ROCK_SMASH", label = "ROCK SMASH", fieldMove = true },
    { id = "STATS", label = "STATS" },
  }
  local out = wrappers["ui.party.submenu"](
    function(_, items) return items end, {}, input, {}, { battle = false })
  local ids = {}
  for _, row in ipairs(out) do ids[row.id] = true end
  assert(not ids.CUT and not ids.WATERFALL)
  assert(ids.HEADBUTT and ids.ROCK_SMASH and ids.STATS)

  local battle = wrappers["ui.party.submenu"](
    function(_, items) return items end, {}, input, {}, { battle = true })
  assert(#battle == #input, "battle submenu must not be filtered")
end

-- Start -> HM and Start -> TM are inserted independently and create semantic
-- Gen2 screens.
do
  local pushed
  local popCalls = 0
  local game = {
    save = save,
    data = data,
    stack = {
      push = function(_, state) pushed = state end,
      pop = function() popCalls = popCalls + 1 end,
    },
  }
  local out = wrappers["ui.start_menu.items"](
    function(_, items) return items end, game,
    { { label = "POKéMON" }, { label = "SAVE" } })
  local hm, tm
  for _, row in ipairs(out) do
    if row.label == "HM" then hm = row end
    if row.label == "TM" then tm = row end
  end
  assert(hm and type(hm.onSelect) == "function")
  assert(tm and type(tm.onSelect) == "function")
  -- The engine's generic Menu invokes onSelect with no arguments. The hook
  -- must retain the game it received when the START rows were constructed.
  hm.onSelect()
  assert(pushed and pushed.screenId == "Gen2HmAnywhereMenu")
  assert(pushed.items == pushed.rows and type(pushed.index) == "number")
  local foundCut, foundWaterfall, foundWhirlpool, foundCtx = false, false, false, false
  for _, row in ipairs(pushed.items) do
    foundCut = foundCut or row.id == "CUT"
    foundWaterfall = foundWaterfall or row.id == "WATERFALL"
    foundWhirlpool = foundWhirlpool or row.id == "WHIRLPOOL"
    foundCtx = foundCtx or row.id == "CONTEXT"
  end
  assert(foundCut and foundWaterfall and foundWhirlpool and foundCtx)

  -- The native Gen 2 renderer must draw every visible HM row. v2.0.1 tried
  -- to require the non-existent src.ui.gen2.Chrome module instead.
  local drawn, boxDrawn, cursorDrawn = {}, false, false
  package.loaded["src.render.Font"] = nil
  package.loaded["src.ui.Theme"] = nil
  package.preload["src.render.Font"] = function()
    return {
      drawBox = function() boxDrawn = true end,
      draw = function(label) drawn[label] = true end,
      drawCode = function() cursorDrawn = true end,
    }
  end
  package.preload["src.ui.Theme"] = function() return { cursor = 0xED } end
  love = { graphics = { setColor = function() end } }
  pushed:draw()
  assert(boxDrawn and cursorDrawn, "native HM menu chrome must be drawn")
  assert(drawn.CUT and drawn.WATERFALL and drawn.WHIRLPOOL
    and drawn["CTX ON"], "owned HM labels must be visible")

  -- Manual CUT delegates to the native World:useFieldMove path.
  local calledMove, calledMon
  game.world = {
    useFieldMove = function(_, moveId, mon)
      calledMove, calledMon = moveId, mon
      return { ok = false }
    end,
  }
  pushed.index = 1
  pushed:choose()
  assert(calledMove == "CUT" and calledMon == save.party[2])

  -- Toggle updates both persistent state and visible row label.
  for i, row in ipairs(pushed.items) do
    if row.id == "CONTEXT" then pushed.index = i break end
  end
  pushed:choose()
  assert(saved.contextualActions == false)
  assert(pushed.items[pushed.index].label == "CTX OFF")
  saved.contextualActions = true

  -- Start -> TM lists only the four owned Gen 2 TMs with native overworld
  -- behavior and exposes the same semantic fields as the HM screen.
  tm.onSelect()
  local tmPushed = pushed
  assert(tmPushed and tmPushed.screenId == "Gen2TmAnywhereMenu")
  assert(tmPushed.items == tmPushed.rows and tmPushed.title == "TM ANYWHERE")
  local tmRows = {}
  for i, row in ipairs(tmPushed.items) do tmRows[row.id] = i end
  assert(tmRows.HEADBUTT and tmRows.ROCK_SMASH and tmRows.SWEET_SCENT
    and tmRows.DIG and tmRows.CONTEXT)

  for key in pairs(drawn) do drawn[key] = nil end
  tmPushed:draw()
  assert(drawn.HEADBUTT and drawn["ROCK SMASH"] and drawn["SWEET SCENT"]
    and drawn.DIG and drawn["CTX ON"], "owned field-TM labels must be visible")

  -- HEADBUTT / ROCK SMASH / SWEET SCENT delegate to the engine's native
  -- Gen 2 field-move dispatcher using the first non-Egg helper.
  local nativeMove, nativeMon, nativeX, nativeY
  game.world = {
    player = { facingCell = function() return 7, 9 end },
    gen2FieldMoveAt = function(_, moveId, mon, x, y)
      nativeMove, nativeMon, nativeX, nativeY = moveId, mon, x, y
      return true
    end,
  }
  tmPushed.index = tmRows.HEADBUTT
  tmPushed:choose()
  assert(nativeMove == "HEADBUTT" and nativeMon == save.party[2])
  assert(nativeX == 7 and nativeY == 9 and popCalls == 1)
  assert(save.inventory.TM_HEADBUTT == 1,
    "using a field TM must not consume the machine")

  -- DIG uses Gen 2's recorded cave entrance and native teleport-out path.
  local digPushed, digPopCalls, digOpts
  local digGame = {
    save = save, data = data,
    stack = {
      push = function(_, state) digPushed = state end,
      pop = function() digPopCalls = (digPopCalls or 0) + 1 end,
    },
  }
  digGame.world = {
    map = { id = "DARK_CAVE", def = { environment = 4, tileset = "CAVERN" } },
    escapePoint = function() return { map = "ROUTE_31", x = 3, y = 2 } end,
    beginTeleportOut = function(_, _, opts) digOpts = opts end,
  }
  local digOut = wrappers["ui.start_menu.items"](
    function(_, items) return items end, digGame, { { label = "SAVE" } })
  local digTm
  for _, row in ipairs(digOut) do if row.label == "TM" then digTm = row end end
  assert(digTm)
  digTm.onSelect()
  local digIndex
  for i, row in ipairs(digPushed.items) do
    if row.id == "DIG" then digIndex = i break end
  end
  assert(digIndex)
  digPushed.index = digIndex
  digPushed:choose()
  assert(digPopCalls == 1 and digOpts and digOpts.escape == true)


  -- Manual FLY uses the native destination picker and only queues the field
  -- move after a destination has been chosen.
  save.inventory.HM_FLY = 1
  data.items.HM_FLY = { teaches = "FLY", tmNumber = 52, tmLabel = "HM02" }
  local flyPushed
  local flyGame = {
    save = save, data = data,
    stack = {
      push = function(_, state) flyPushed = state end,
      clear = function() end,
    },
  }
  local chosenCb
  flyGame.world = {
    useFieldMove = function(self, moveId, mon)
      assert(moveId == "FLY")
      return { ok = true, action = "fly", mon = mon }
    end,
    openFlyMap = function(self, mon, opts)
      chosenCb = opts.onChosen
      return true
    end,
    exitMenusFadeForFly = function(self) self.flyFade = true end,
  }
  local flyOut = wrappers["ui.start_menu.items"](
    function(_, items) return items end, flyGame, { { label = "SAVE" } })
  local flyHm
  for _, row in ipairs(flyOut) do if row.label == "HM" then flyHm = row end end
  flyHm.onSelect()
  local flyIndex
  for i, row in ipairs(flyPushed.items) do
    if row.id == "FLY" then flyIndex = i break end
  end
  assert(flyIndex, "FLY row should be listed when HM_FLY is owned")
  flyPushed.index = flyIndex
  flyPushed:choose()
  assert(type(chosenCb) == "function", "FLY must open the native picker")
  assert(flyGame.world.queuedFieldMove == nil, "FLY must not queue before destination")
  chosenCb("SPAWN_GOLDENROD")
  assert(flyGame.world.queuedFieldMove
    and flyGame.world.queuedFieldMove.flySpawn == "SPAWN_GOLDENROD")
  assert(flyGame.world.flyFade == true)

  local noHmGame = {
    save = { inventory = {}, party = save.party }, data = data,
  }
  local unchanged = wrappers["ui.start_menu.items"](
    function(_, items) return items end, noHmGame, { { label = "SAVE" } })
  assert(#unchanged == 1 and unchanged[1].label == "SAVE")

  local onlyTmGame = {
    save = { inventory = { TM_HEADBUTT = 1 }, party = save.party }, data = data,
  }
  local onlyTm = wrappers["ui.start_menu.items"](
    function(_, items) return items end, onlyTmGame, { { label = "SAVE" } })
  assert(#onlyTm == 2 and onlyTm[1].label == "TM"
    and onlyTm[2].label == "SAVE", "TM entry must not depend on owning an HM")

  local onlyHmGame = {
    save = { inventory = { HM_CUT = 1 }, party = save.party }, data = data,
  }
  local onlyHm = wrappers["ui.start_menu.items"](
    function(_, items) return items end, onlyHmGame, { { label = "SAVE" } })
  assert(#onlyHm == 2 and onlyHm[1].label == "HM"
    and onlyHm[2].label == "SAVE", "HM entry must not depend on owning a TM")
end

assert(type(eventHandlers["game.ready"]) == "function")
eventHandlers["game.ready"]({ game = { save = save, data = data } })
assert(#logs >= 1)
assert(mod.exports.ownedTM({ save = save, data = data }, "HEADBUTT") == true)
assert(mod.exports.ownedTM({ save = { inventory = {} }, data = data }, "HEADBUTT") == false)
local fieldTMs = mod.exports.fieldTMs()
assert(#fieldTMs == 4 and fieldTMs[1] == "HEADBUTT" and fieldTMs[4] == "DIG")

print("HM_ANYWHERE_GEN2_TEST_OK")
