# Changelog

## 1.0.0

- Initial Gen 2 release.
- Adds **INSTANT HATCH** to Egg party submenus outside battle.
- Uses the native Gen 2 hatch flow instead of manually replacing the Egg.
- Preserves hatch animation, nickname prompt, Pokédex updates, caught data and Togepi event handling.
- Ensures only the selected Egg is included in the forced hatch queue.
- Compatible with other `ui.party.submenu` extensions and optional Gen2 Modern UI.
