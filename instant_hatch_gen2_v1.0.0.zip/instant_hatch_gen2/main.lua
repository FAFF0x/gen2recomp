-- Instant Hatch Gen 2 v1.0.0 for Gen1Recomp / Gen2Recomp
-- Adds INSTANT HATCH to an Egg's out-of-battle party submenu.
-- The action deliberately delegates to World:hatchEggs() so the normal Gen 2
-- hatch animation, nickname prompt, Pokedex updates and special side effects
-- remain engine-owned.

local Breeding = require("src.core.gen2.Breeding")

local ENTRY_ID = "INSTANT_HATCH_GEN2"
local ENTRY_LABEL = "INSTANT HATCH"

local function partySlot(game, mon)
  local party = game and game.save and game.save.party
  if type(party) ~= "table" then return nil end
  for index, candidate in ipairs(party) do
    if candidate == mon then return index end
  end
  return nil
end

local function hasEntry(items)
  for _, item in ipairs(items or {}) do
    if item.id == ENTRY_ID then return true end
  end
  return false
end

local function insertAfterStats(items, entry)
  local at = #items + 1
  for index, item in ipairs(items) do
    if item.id == "STATS" or item.label == "STATS" then
      at = index + 1
      break
    end
  end
  table.insert(items, at, entry)
end

-- World:hatchEggs() snapshots every party Egg whose eggSteps is already zero.
-- An instant hatch must affect ONLY the Egg the player selected, so any other
-- already-ready Egg is parked at 1 just long enough for that snapshot and is
-- immediately restored afterwards.  The selected Egg remains at zero and the
-- engine owns everything from "Huh?" onward.
local function instantHatch(game, mon)
  if type(mon) ~= "table" or not Breeding.isEgg(mon) then return false end
  local save = game and game.save
  local party = save and save.party
  local world = game and game.world
  if type(party) ~= "table" or not (world and world.hatchEggs) then return false end

  local slot = partySlot(game, mon)
  if not slot or party[slot] ~= mon then return false end

  local parked = {}
  for index, candidate in ipairs(party) do
    if index ~= slot and Breeding.isEgg(candidate)
        and (candidate.eggSteps or 0) == 0 then
      parked[#parked + 1] = candidate
      candidate.eggSteps = 1
    end
  end

  mon.eggSteps = 0

  -- PokemonActionSubmenu is under the START menu.  Natural HatchEggs runs in
  -- the overworld, so leave all menus before starting the exact same sequence.
  local stack = game and game.stack
  if stack and stack.clear then stack:clear() end

  local ok, err = pcall(function() world:hatchEggs() end)

  -- hatchEggs has already captured its queue synchronously.  Restore any Eggs
  -- that were naturally ready so the mod never steals or delays their hatch.
  for _, candidate in ipairs(parked) do
    if Breeding.isEgg(candidate) then candidate.eggSteps = 0 end
  end

  if not ok then error(err, 0) end
  return true
end

return function(mod)
  mod.hooks:wrap("ui.party.submenu", function(nextFn, game, items, mon, ctx)
    local result = nextFn(game, items, mon, ctx)
    if type(result) ~= "table" then result = items or {} end

    -- Field PokemonActionSubmenu only.  BattleMonMenu must stay untouched.
    if ctx and ctx.battle then return result end
    if not (ctx and ctx.overworld) then return result end
    if not Breeding.isEgg(mon) or hasEntry(result) then return result end

    insertAfterStats(result, {
      id = ENTRY_ID,
      label = ENTRY_LABEL,
      onSelect = function(selectedMon, selectedGame)
        return instantHatch(selectedGame, selectedMon)
      end,
    })
    return result
  end, 0)

  mod.exports = mod.exports or {}
  mod.exports.instantHatch = instantHatch
  mod.exports.partySlot = partySlot
  mod.exports.entryId = ENTRY_ID
  mod.exports.entryLabel = ENTRY_LABEL

  if mod.log and mod.log.info then
    mod.log:info("Instant Hatch Gen 2 v1.0.0 loaded")
  end
end
