-- ROM-free smoke/regression test for Instant Hatch Gen 2.

package.path = "./?.lua;./?/init.lua;" .. package.path

local function check(name, value)
  if not value then error("FAIL: " .. name, 2) end
end

local function eq(name, got, want)
  if got ~= want then
    error(("FAIL: %s (got %s, want %s)"):format(name, tostring(got), tostring(want)), 2)
  end
end

package.preload["src.core.gen2.Breeding"] = function()
  return {
    isEgg = function(mon) return type(mon) == "table" and mon.isEgg == true end,
  }
end

local wrapped
local mod = {
  hooks = {
    wrap = function(_, name, callback)
      eq("hook name", name, "ui.party.submenu")
      wrapped = callback
    end,
  },
  exports = {},
  log = { info = function() end },
}

local root = (... and tostring(...):match("^(.*)%.tests%.[^.]+$"))
local entry = assert(loadfile("main.lua"))
entry()(mod)
check("submenu hook registered", wrapped ~= nil)
check("instantHatch exported", type(mod.exports.instantHatch) == "function")

local function baseItems()
  return {
    { id = "STATS", label = "STATS" },
    { id = "SWITCH", label = "SWITCH" },
    { id = "CANCEL", label = "CANCEL" },
  }
end

local function passthrough(_game, items) return items end

-- Non-Eggs are untouched.
do
  local rows = wrapped(passthrough, {}, baseItems(), { isEgg = false },
    { battle = false, overworld = {} })
  eq("non-egg row count", #rows, 3)
end

-- Battle submenu is untouched even for an Egg fixture.
do
  local rows = wrapped(passthrough, {}, baseItems(), { isEgg = true },
    { battle = true, overworld = {} })
  eq("battle row count", #rows, 3)
end

-- Egg field submenu gets INSTANT HATCH directly after STATS.
local egg = { isEgg = true, eggSteps = 17 }
local rows = wrapped(passthrough, {}, baseItems(), egg,
  { battle = false, overworld = {} })
eq("egg row count", #rows, 4)
eq("instant row position", rows[2].id, "INSTANT_HATCH_GEN2")
eq("instant row label", rows[2].label, "INSTANT HATCH")
check("instant row callback", type(rows[2].onSelect) == "function")

-- Duplicate-safe when another wrapper already authored the row.
do
  local items = baseItems()
  table.insert(items, 2, { id = "INSTANT_HATCH_GEN2", label = "INSTANT HATCH" })
  local out = wrapped(passthrough, {}, items, egg,
    { battle = false, overworld = {} })
  eq("no duplicate", #out, 4)
end

-- The selected Egg alone is zero when World:hatchEggs snapshots its queue.
do
  local selected = { isEgg = true, eggSteps = 8 }
  local alreadyReady = { isEgg = true, eggSteps = 0 }
  local later = { isEgg = true, eggSteps = 3 }
  local mon = { isEgg = false }
  local party = { mon, selected, alreadyReady, later }
  local clearCount = 0
  local captured = {}
  local game
  local world = {
    hatchEggs = function()
      for i, candidate in ipairs(game.save.party) do
        if candidate.isEgg and (candidate.eggSteps or 0) == 0 then
          captured[#captured + 1] = i
        end
      end
      -- Simulate the selected slot being replaced synchronously later in the
      -- native flow; the parked Egg object remains available for restoration.
    end,
  }
  game = {
    save = { party = party },
    world = world,
    stack = { clear = function() clearCount = clearCount + 1 end },
  }

  check("instant hatch succeeds", mod.exports.instantHatch(game, selected))
  eq("menus cleared", clearCount, 1)
  eq("only selected queued", #captured, 1)
  eq("selected queued slot", captured[1], 2)
  eq("selected counter forced ready", selected.eggSteps, 0)
  eq("other ready egg restored", alreadyReady.eggSteps, 0)
  eq("later egg unchanged", later.eggSteps, 3)
end

-- A mon not present in the save party cannot hatch.
do
  local stranger = { isEgg = true, eggSteps = 5 }
  local called = false
  local game = {
    save = { party = {} },
    world = { hatchEggs = function() called = true end },
    stack = { clear = function() end },
  }
  check("foreign egg rejected", mod.exports.instantHatch(game, stranger) == false)
  check("world not called", called == false)
end

print("instant_hatch_gen2_test: ok")
