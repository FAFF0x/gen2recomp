# Changelog

## [1.0.0] - 2026-09-04

### Standalone Gen 2 packaging

- Forked from Item Shortcut - Gen 2 v2.0.1 into a separate install identity.
- Manifest ID changed to `pokemonmod_gen2_item_shortcut`.
- Restricted explicitly to `games: ["gen2"]`.
- Removed the hard conflict with `item_shortcut`.
- Added optional load-order references for `item_shortcut_gen2` and `item_shortcut`.
- Added runtime coexistence detection: if a known equivalent Item Shortcut is active, this build defers instead of installing a second input/Pack dispatcher.
- Save/options namespace now follows the unique standalone mod ID.
- Retained shared global dispatcher markers as a duplicate-wrapper mutex.
- Preserved the v2.0.1 `ListMenu.rows` crash fix and all Gen 2 functionality.
