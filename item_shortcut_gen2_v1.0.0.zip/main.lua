-- Item Shortcut - Gen 2 for Gen1Recomp
-- Five persistent Pack shortcuts, one FAST item, and press-to-bind controls.
-- Uses Gold/Silver/Crystal's native Pack/field-item paths instead of Gen 1 Bag code.
-- Standalone Pokemon MOD build: unique manifest/save/options identity, Gen 2 only.
-- The shared dispatcher keys below intentionally arbitrate runtime ownership
-- with legacy Item Shortcut builds so duplicate wrappers cannot stack.

local PATCH_KEY = "__item_shortcut_gen2_input_dispatch_v1"
local PACK_MENU_PATCH_KEY = "__item_shortcut_gen2_pack_assign_dispatch_v1"
local STATE_MARK = "__itemShortcutState"
local SLOT_COUNT = 5
local SAVE_KEY = "slots"
local FAST_SAVE_KEY = "fast_slot"

local MOD_ID = "pokemonmod_gen2_item_shortcut"
local EQUIVALENT_MOD_IDS = { "item_shortcut_gen2", "item_shortcut" }
local KEYBOARD_OPTION = "keyboard_key"
local GAMEPAD_OPTION = "gamepad_button"
local FAST_KEYBOARD_OPTION = "fast_keyboard_key"
local FAST_GAMEPAD_OPTION = "fast_gamepad_button"
local CONTROLS_MIGRATION_OPTION = "controls_capture_v200"
local CONTROL_ROW = "__control_mapping"

local DEFAULT_BINDINGS = {
  [KEYBOARD_OPTION] = "i",
  [GAMEPAD_OPTION] = "y",
  [FAST_KEYBOARD_OPTION] = "k",
  [FAST_GAMEPAD_OPTION] = "x",
}
local RUNTIME_BINDINGS = {}

local GAMEPAD_LABELS = {
  a = "A", b = "B", x = "X", y = "Y",
  back = "BACK", guide = "GUIDE", start = "START",
  leftstick = "L3", rightstick = "R3",
  leftshoulder = "L1", rightshoulder = "R1",
  triggerleft = "L2", triggerright = "R2",
  lefttrigger = "L2", righttrigger = "R2",
  dpup = "D-UP", dpdown = "D-DOWN",
  dpleft = "D-LEFT", dpright = "D-RIGHT",
}

local KEYBOARD_LABELS = {
  space = "SPACE", ["return"] = "ENTER", kpenter = "KP ENTER",
  tab = "TAB", backspace = "BACKSPACE", delete = "DELETE",
  insert = "INSERT", home = "HOME", ["end"] = "END",
  pageup = "PAGE UP", pagedown = "PAGE DOWN",
  lshift = "L SHIFT", rshift = "R SHIFT",
  lctrl = "L CTRL", rctrl = "R CTRL",
  lalt = "L ALT", ralt = "R ALT",
}

-- Gen 2 modules.  PackMenu is patched only at its item submenu seam so the
-- normal Pack remains the owner of USE/GIVE/TOSS/SEL and all pocket logic.
local PackMenu
local ListMenu
local Menu
local TextBox
local Font
local Chrome
local Strings

do
  local ok, module = pcall(require, "src.ui.gen2.PackMenu")
  if ok and type(module) == "table" then PackMenu = module end
  ok, module = pcall(require, "src.ui.ListMenu")
  if ok and type(module) == "table" then ListMenu = module end
  ok, module = pcall(require, "src.ui.Menu")
  if ok and type(module) == "table" then Menu = module end
  ok, module = pcall(require, "src.render.TextBox")
  if ok and type(module) == "table" then TextBox = module end
  ok, module = pcall(require, "src.render.Font")
  if ok and type(module) == "table" then Font = module end
  ok, module = pcall(require, "src.ui.gen2.Chrome")
  if ok and type(module) == "table" then Chrome = module end
  ok, module = pcall(require, "src.core.Strings")
  if ok then Strings = module end
end

local function mark(state)
  if type(state) == "table" then state[STATE_MARK] = true end
  return state
end

local function copySlots(source)
  local out = {}
  if type(source) ~= "table" then return out end
  for i = 1, SLOT_COUNT do
    if type(source[i]) == "string" and source[i] ~= "" then
      out[i] = source[i]
    end
  end
  return out
end

local function slotsFor(mod)
  local slots = copySlots(mod.save:get(SAVE_KEY))
  mod.save:set(SAVE_KEY, slots)
  return slots
end

local function persistSlots(mod, slots)
  mod.save:set(SAVE_KEY, copySlots(slots))
end

local function fastSlotFor(mod, slots)
  local slot = math.floor(tonumber(mod.save:get(FAST_SAVE_KEY)) or 0)
  if slot >= 1 and slot <= SLOT_COUNT and type(slots[slot]) == "string" then
    return slot
  end
  if slot ~= 0 then mod.save:set(FAST_SAVE_KEY, 0) end
  return nil
end

local function persistFastSlot(mod, slot)
  slot = math.floor(tonumber(slot) or 0)
  if slot < 1 or slot > SLOT_COUNT then slot = 0 end
  mod.save:set(FAST_SAVE_KEY, slot)
end

local function countOf(game, id)
  local inventory = game and game.save and game.save.inventory
  local value = inventory and inventory[id]
  if value == true then return 1 end
  value = math.floor(tonumber(value) or 0)
  return math.max(0, value)
end

local function itemName(game, id)
  local def = game and game.data and game.data.items and game.data.items[id]
  return (def and def.name) or id or "EMPTY"
end

local function compact(text, limit)
  text = tostring(text or "")
  if Font and type(Font.split) == "function" then
    local spans = Font.split(text)
    if #spans <= limit then return text end
    if limit <= 1 then return "." end
    local last = spans[limit - 1] and spans[limit - 1].to
    if last then return text:sub(1, last) .. "." end
  end
  if #text <= limit then return text end
  if limit <= 1 then return text:sub(1, limit) end
  return text:sub(1, limit - 1) .. "."
end

local function showMessage(game, text)
  if TextBox and type(TextBox.new) == "function"
      and game and game.stack and type(game.stack.push) == "function" then
    game.stack:push(TextBox.new(game, text))
    return true
  end
  return false
end

local function optionBucket(game)
  if not game then return nil end
  local root = game.options
  if type(root) ~= "table" then
    root = game.save and game.save.options or {}
    game.options = root
  end
  root.modOptions = root.modOptions or {}
  root.modOptions[MOD_ID] = root.modOptions[MOD_ID] or {}
  if game.save then game.save.options = root end
  if game.mods then
    game.mods.modOptions = game.mods.modOptions or {}
    game.mods.modOptions[MOD_ID] = root.modOptions[MOD_ID]
  end
  return root.modOptions[MOD_ID]
end

local function flushOptions(game, key, value)
  if game and type(game.persistOptions) == "function" then
    game:persistOptions()
  elseif game and type(game.writeOptions) == "function" then
    game:writeOptions()
  end
  local events = game and game.mods and game.mods.events
  if events and type(events.emit) == "function" and key then
    events:emit("mod.options_changed", { mod = MOD_ID, key = key, value = value })
  end
end

local function ensureBindings(mod, game)
  local bucket = optionBucket(game)
  if not bucket then return end
  local changed = false

  -- v1.3 used R1/L1 as the built-in controller defaults. On the first v1.4
  -- boot, only those old defaults are migrated to Y/X; every other custom
  -- controller choice is preserved. Keyboard bindings are never changed.
  if not bucket[CONTROLS_MIGRATION_OPTION] then
    if bucket[KEYBOARD_OPTION] == nil then bucket[KEYBOARD_OPTION] = "i" end
    if bucket[FAST_KEYBOARD_OPTION] == nil then bucket[FAST_KEYBOARD_OPTION] = "k" end
    if bucket[GAMEPAD_OPTION] == nil or bucket[GAMEPAD_OPTION] == "rightshoulder" then
      bucket[GAMEPAD_OPTION] = "y"
    end
    if bucket[FAST_GAMEPAD_OPTION] == nil
        or bucket[FAST_GAMEPAD_OPTION] == "leftshoulder" then
      bucket[FAST_GAMEPAD_OPTION] = "x"
    end
    bucket[CONTROLS_MIGRATION_OPTION] = true
    changed = true
  end

  for key, value in pairs(DEFAULT_BINDINGS) do
    if type(bucket[key]) ~= "string" or bucket[key] == "" then
      bucket[key] = value
      changed = true
    end
    RUNTIME_BINDINGS[key] = bucket[key]
  end
  if changed then flushOptions(game) end
end

local function bindingValue(mod, key)
  local value = RUNTIME_BINDINGS[key]
  if type(value) == "string" and value ~= "" then return value end
  value = mod and mod.options and mod.options:get(key)
  if type(value) == "string" and value ~= "" then return value end
  return DEFAULT_BINDINGS[key]
end

local function persistBinding(mod, game, key, value)
  if type(value) ~= "string" or value == "" then return false end
  local bucket = optionBucket(game)
  if not bucket then return false end
  bucket[key] = value
  RUNTIME_BINDINGS[key] = value
  flushOptions(game, key, value)
  return true
end

local function keyboardBinding(mod)
  return bindingValue(mod, KEYBOARD_OPTION)
end

local function gamepadBinding(mod)
  return bindingValue(mod, GAMEPAD_OPTION)
end

local function fastKeyboardBinding(mod)
  return bindingValue(mod, FAST_KEYBOARD_OPTION)
end

local function fastGamepadBinding(mod)
  return bindingValue(mod, FAST_GAMEPAD_OPTION)
end

local function bindingLabel(kind, value)
  value = tostring(value or "")
  if kind == "gamepad" then
    return GAMEPAD_LABELS[value] or value:upper()
  end
  return KEYBOARD_LABELS[value] or value:upper()
end

local function shortcutFooter(mod)
  return ("%s/%s CLOSE"):format(bindingLabel("keyboard", keyboardBinding(mod)),
    bindingLabel("gamepad", gamepadBinding(mod)))
end

local function buildSlotRows(game, slots, fastSlot)
  local rows = {}
  for i = 1, SLOT_COUNT do
    local id = slots[i]
    local count = id and countOf(game, id) or 0
    local isFast = i == fastSlot
    local right = isFast and "FAST" or (count > 1 and ("x" .. tostring(count)) or nil)
    local maxName = right and 9 or 14
    local name
    if not id then
      name = "EMPTY"
    elseif count <= 0 then
      name = "MISSING"
    else
      name = compact(itemName(game, id), maxName)
    end
    rows[i] = {
      label = tostring(i) .. ". " .. name,
      right = right,
      value = i,
    }
  end
  rows[#rows + 1] = {
    label = "CONTROL MAPPING",
    right = "SET",
    value = CONTROL_ROW,
  }
  return rows
end

-- IMPORTANT: ListMenu.rows is a numeric visible-row count in the engine.
-- Never alias it to .items for semantic UI discovery; Modern UI can inspect
-- .items directly. Overwriting .rows with a table crashes ListMenu:syncScroll.
local function refreshShortcutList(mod, list, game, slots, index)
  if not list then return end
  list.items = buildSlotRows(game, slots, fastSlotFor(mod, slots))
  list.index = math.max(1, math.min(index or list.index or 1, #list.items))
  list.scroll = 0
end

local function removeShortcutStates(game)
  local removed = false
  local stack = game and game.stack
  if not stack or type(stack.top) ~= "function" or type(stack.pop) ~= "function" then
    return false
  end
  while true do
    local top = stack:top()
    if type(top) ~= "table" or not top[STATE_MARK] then break end
    stack:pop()
    removed = true
  end
  return removed
end

local function localized(text)
  if Strings and type(Strings) == "table" and getmetatable(Strings)
      and getmetatable(Strings).__call then
    local ok, value = pcall(Strings, text)
    if ok then return value end
  elseif type(Strings) == "function" then
    local ok, value = pcall(Strings, text)
    if ok then return value end
  end
  return text
end

local function say(game, text)
  text = localized(text)
  if game and type(game.say) == "function" then
    game:say(text)
    return true
  end
  return showMessage(game, text)
end

-- The Gen 2 PACK has two dispatchers: World handles field/key items, then
-- Game2 handles party-target items and TM/HM teaching.  This is the same order
-- PackMenu:useSelected follows, without opening a hidden PACK screen.
local function useThroughGen2Pack(mod, game, id)
  if not id or countOf(game, id) <= 0 then
    say(game, "That item is no longer\nin the PACK.")
    return false
  end
  local world = game and game.world
  local def = game and game.data and game.data.items and game.data.items[id]
  if not (world and type(world.useFieldItem) == "function") then
    mod.log:warn("Item Shortcut Gen 2 has no field-item dispatcher for %s", tostring(id))
    say(game, "That item cannot be\nused from this shortcut.")
    return false
  end

  local ok, result, extra = pcall(world.useFieldItem, world, id)
  if not ok then
    mod.log:warn("Item Shortcut Gen 2 field use failed for %s: %s",
      tostring(id), tostring(result))
    say(game, "The item could not\nbe used.")
    return false
  end

  if result then
    if result == "nowhere" then
      say(game, "OAK: {PLAYER}!\nThis isn't the\vtime to use that!")
    elseif result == "coin_case" then
      say(game, ("Coins:\n%d"):format(tonumber(extra) or 0))
    elseif result == "blue_card" then
      say(game, ("You now have\n%d points."):format(tonumber(extra) or 0))
    elseif result == "repel_used" then
      say(game, ("{PLAYER} used the\n%s."):format(itemName(game, id)))
    elseif result == "repel_active" then
      say(game, "The REPEL used\nearlier is still\vin effect.")
    elseif result == "trophy_sent" then
      say(game, "There was a trophy\ninside!\f{PLAYER} sent the\ntrophy home.")
    end
    return true
  end

  -- No world effect: TM/HM and party-target items continue through Game2,
  -- exactly like PackMenu's tail after World:useFieldItem returns nil.
  if def and def.fieldMenu == "ITEMMENU_NOUSE" and not def.teaches then
    say(game, "OAK: {PLAYER}!\nThis isn't the\vtime to use that!")
    return false
  end
  if game and type(game.useFieldItem) == "function" then
    local used, err = pcall(game.useFieldItem, game, id)
    if not used then
      mod.log:warn("Item Shortcut Gen 2 party/TM use failed for %s: %s",
        tostring(id), tostring(err))
      say(game, "The item could not\nbe used.")
      return false
    end
    return true
  end
  say(game, "That item cannot be\nused from this shortcut.")
  return false
end

local function assignItem(mod, slots, slotIndex, itemId)
  -- A single Bag item owns at most one shortcut slot. Reassigning it moves
  -- the item instead of creating duplicate entries in the quick menu.
  local fastSlot = fastSlotFor(mod, slots)
  local previousSlot
  for i = 1, SLOT_COUNT do
    if slots[i] == itemId then
      previousSlot = i
      slots[i] = nil
    end
  end
  slots[slotIndex] = itemId
  persistSlots(mod, slots)

  -- FAST normally belongs to the slot, but follows an item when that same
  -- item is explicitly moved to a different shortcut slot.
  if fastSlot and previousSlot == fastSlot and slotIndex ~= previousSlot then
    persistFastSlot(mod, slotIndex)
  end
end

local function buildAssignmentRows(game, slots, itemId)
  local rows = {}
  for i = 1, SLOT_COUNT do
    local assigned = slots[i]
    local name = assigned and compact(itemName(game, assigned), 13) or "EMPTY"
    rows[i] = {
      label = tostring(i) .. ". " .. name,
      right = assigned == itemId and "SET" or nil,
      value = i,
    }
  end
  return rows
end

local function openBagAssignment(mod, game, itemId)
  if not (ListMenu and game and game.stack and itemId) then return false end
  if countOf(game, itemId) <= 0 then
    showMessage(game, "That item is no longer\nin the PACK.")
    return false
  end

  local slots = slotsFor(mod)
  local picker
  picker = mark(ListMenu.new(game, "CHOOSE SLOT", buildAssignmentRows(game, slots, itemId), {
    onChoose = function(row, list)
      assignItem(mod, slots, row.value, itemId)
      list:close()
      showMessage(game, ("Assigned %s\nto shortcut %d.")
        :format(itemName(game, itemId), row.value))
    end,
  }))
  picker.screenId = "Gen2ItemShortcutAssign"
  game.stack:push(picker)
  return true
end

local PACK_ASSIGN_ROW = "ASSIGN SHORTCUT"

local function addPackAssignmentRow(pack)
  if not (pack and pack.submenu and type(pack.submenu.rows) == "table") then
    return false
  end
  if pack.battle or pack.give or pack.tutorial then return false end
  local row = pack.submenu.row
  if not (row and type(row.id) == "string") then return false end
  for _, id in ipairs(pack.submenu.rows) do
    if id == PACK_ASSIGN_ROW then return true end
  end
  local insertAt = #pack.submenu.rows + 1
  for i, id in ipairs(pack.submenu.rows) do
    if id == "quit" then insertAt = i break end
  end
  table.insert(pack.submenu.rows, insertAt, PACK_ASSIGN_ROW)
  return true
end

local function drawPackSubmenuWithAssignment(pack, baseDraw)
  local menu = pack and pack.submenu
  if not menu then return baseDraw(pack) end
  local has = false
  for _, id in ipairs(menu.rows or {}) do
    if id == PACK_ASSIGN_ROW then has = true break end
  end
  if not has or not Chrome then return baseDraw(pack) end

  -- The stock Gen 2 submenu is seven tiles wide and can have only five rows.
  -- ASSIGN SHORTCUT makes both limits too small, so only this decorated menu
  -- gets a wider/taller box; the normal PACK stays byte-for-byte visual.
  local count = #menu.rows
  local width = 18
  local height = count * 2 + 1
  local x = 1
  local top = math.max(0, 18 - height)
  Chrome.box(x, top, width, height)
  for i, id in ipairs(menu.rows) do
    local ty = top + 1 + (i - 1) * 2
    if i == menu.index then
      if Chrome.cursorThrough then Chrome.cursorThrough(x + 1, ty, Chrome.DEFAULT_BOX_PALETTE)
      elseif Chrome.cursor then Chrome.cursor(x + 1, ty) end
    end
    local label = id == PACK_ASSIGN_ROW and PACK_ASSIGN_ROW or tostring(id):upper()
    if Chrome.printThrough then
      Chrome.printThrough(localized(label), x + 2, ty, Chrome.DEFAULT_BOX_PALETTE)
    else
      Chrome.print(localized(label), x + 2, ty)
    end
  end
end

local function installPackAssignment(mod, game)
  if type(PackMenu) ~= "table" or type(PackMenu.openSubmenu) ~= "function"
      or type(PackMenu.chooseSubmenu) ~= "function" then
    mod.log:warn("Item Shortcut Gen 2 could not add ASSIGN SHORTCUT to PACK")
    return false
  end

  local dispatch = rawget(_G, PACK_MENU_PATCH_KEY)
  if type(dispatch) ~= "table" then
    dispatch = {
      baseOpen = PackMenu.openSubmenu,
      baseChoose = PackMenu.chooseSubmenu,
      baseDraw = PackMenu.drawSubmenu,
      assign = nil,
    }
    dispatch.open = function(self, ...)
      local result = dispatch.baseOpen(self, ...)
      addPackAssignmentRow(self)
      return result
    end
    dispatch.choose = function(self, ...)
      local menu = self.submenu
      local id = menu and menu.rows and menu.rows[menu.index]
      if id == PACK_ASSIGN_ROW then
        local itemId = menu.row and menu.row.id
        self:closeSubmenu()
        if dispatch.assign and itemId then dispatch.assign(self.game, itemId) end
        return
      end
      return dispatch.baseChoose(self, ...)
    end
    dispatch.draw = function(self, ...)
      return drawPackSubmenuWithAssignment(self, dispatch.baseDraw)
    end
    rawset(_G, PACK_MENU_PATCH_KEY, dispatch)
    PackMenu.openSubmenu = dispatch.open
    PackMenu.chooseSubmenu = dispatch.choose
    if type(PackMenu.drawSubmenu) == "function" then PackMenu.drawSubmenu = dispatch.draw end
  else
    if PackMenu.openSubmenu ~= dispatch.open then
      dispatch.baseOpen = PackMenu.openSubmenu
      PackMenu.openSubmenu = dispatch.open
    end
    if PackMenu.chooseSubmenu ~= dispatch.choose then
      dispatch.baseChoose = PackMenu.chooseSubmenu
      PackMenu.chooseSubmenu = dispatch.choose
    end
    if dispatch.draw and PackMenu.drawSubmenu ~= dispatch.draw then
      dispatch.baseDraw = PackMenu.drawSubmenu
      PackMenu.drawSubmenu = dispatch.draw
    end
  end
  dispatch.assign = function(currentGame, itemId)
    return openBagAssignment(mod, currentGame, itemId)
  end
  return true
end

local function openSlotContext(mod, game, quickList, slots, slotIndex)
  local id = slots[slotIndex]
  if not id then
    showMessage(game, "Open the PACK and choose\nASSIGN SHORTCUT.")
    return
  end

  local isFast = fastSlotFor(mod, slots) == slotIndex
  local entries = {
    {
      label = "USE",
      onSelect = function()
        quickList:close()
        useThroughGen2Pack(mod, game, id)
      end,
    },
    {
      label = isFast and "REMOVE FAST" or "SET FAST",
      onSelect = function()
        if isFast then
          persistFastSlot(mod, nil)
        else
          persistFastSlot(mod, slotIndex)
        end
        refreshShortcutList(mod, quickList, game, slots, slotIndex)
      end,
    },
    {
      label = "CLEAR",
      onSelect = function()
        slots[slotIndex] = nil
        persistSlots(mod, slots)
        if isFast then persistFastSlot(mod, nil) end
        refreshShortcutList(mod, quickList, game, slots, slotIndex)
      end,
    },
  }

  local context = mark(Menu.new(game, entries, {
    tx = 6, ty = 3, tw = 14,
  }))
  context.screenId = "Gen2ItemShortcutActions"
  game.stack:push(context)
end

local function resetBindings(mod, game)
  local bucket = optionBucket(game)
  if not bucket then return false end
  for key, value in pairs(DEFAULT_BINDINGS) do
    bucket[key] = value
    RUNTIME_BINDINGS[key] = value
  end
  bucket[CONTROLS_MIGRATION_OPTION] = true
  flushOptions(game)
  return true
end

local function controlRows(mod)
  return {
    {
      label = "MENU KEY",
      right = compact(bindingLabel("keyboard", keyboardBinding(mod)), 8),
      value = { kind = "keyboard", key = KEYBOARD_OPTION,
                label = "MENU KEYBOARD" },
    },
    {
      label = "MENU PAD",
      right = compact(bindingLabel("gamepad", gamepadBinding(mod)), 8),
      value = { kind = "gamepad", key = GAMEPAD_OPTION,
                label = "MENU CONTROLLER" },
    },
    {
      label = "FAST KEY",
      right = compact(bindingLabel("keyboard", fastKeyboardBinding(mod)), 8),
      value = { kind = "keyboard", key = FAST_KEYBOARD_OPTION,
                label = "FAST KEYBOARD" },
    },
    {
      label = "FAST PAD",
      right = compact(bindingLabel("gamepad", fastGamepadBinding(mod)), 8),
      value = { kind = "gamepad", key = FAST_GAMEPAD_OPTION,
                label = "FAST CONTROLLER" },
    },
    { label = "RESET DEFAULTS", right = "I/Y K/X", value = "reset" },
  }
end

local function finishCapture(game, value, cancelled)
  local dispatch = rawget(_G, PATCH_KEY)
  local capture = type(dispatch) == "table" and dispatch.capture or nil
  if not capture then return false end
  dispatch.capture = nil
  local stack = game and game.stack
  if stack and type(stack.top) == "function" and stack:top() == capture.state then
    stack:pop()
  end
  if capture.onComplete then
    local ok, err = pcall(capture.onComplete, value, cancelled)
    if not ok and dispatch.log and dispatch.log.warn then
      dispatch.log:warn("Item Shortcut remap completion failed: %s", tostring(err))
    end
  end
  return true
end

local function beginCapture(mod, game, spec, onComplete)
  local dispatch = rawget(_G, PATCH_KEY)
  if type(dispatch) ~= "table" then
    showMessage(game, "Control capture is\nunavailable.")
    return false
  end

  local state = mark({
    isOpaque = true, screenId = "Gen2ItemShortcutCapture",
    title = "REMAP CONTROL",
    message = spec.kind == "gamepad"
      and (spec.label .. "\nPRESS ANY BUTTON\nL2/R2 SUPPORTED\nESC: CANCEL")
      or (spec.label .. "\nPRESS ANY KEY\nESC: CANCEL"),
  })
  function state:update() end
  function state:draw()
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.rectangle("fill", 0, 0, 160, 144)
    love.graphics.setColor(0, 0, 0, 1)
    if Font and Font.draw then
      Font.draw("REMAP CONTROL", 16, 16)
      Font.draw(compact(spec.label, 16), 16, 48)
      if spec.kind == "gamepad" then
        Font.draw("PRESS ANY BUTTON", 16, 72)
        Font.draw("L2/R2 SUPPORTED", 16, 88)
      else
        Font.draw("PRESS ANY KEY", 16, 72)
      end
      Font.draw("ESC: CANCEL", 16, 120)
    end
    love.graphics.setColor(1, 1, 1, 1)
  end

  dispatch.capture = {
    kind = spec.kind,
    state = state,
    onComplete = function(value, cancelled)
      if not cancelled and value then persistBinding(mod, game, spec.key, value) end
      if onComplete then onComplete(value, cancelled) end
    end,
  }
  game.stack:push(state)
  return true
end

local function openControlMapping(mod, game)
  local controls
  local function refresh(index)
    controls.items = controlRows(mod)
    controls.index = math.max(1, math.min(index or controls.index or 1, #controls.items))
    controls.scroll = 0
  end

  controls = mark(ListMenu.new(game, "CONTROL MAPPING", controlRows(mod), {
    footer = "A: REMAP  B: BACK",
    onChoose = function(row)
      if row.value == "reset" then
        resetBindings(mod, game)
        refresh(5)
        showMessage(game, "Controls restored.\nMENU I/Y  FAST K/X")
        return
      end
      local spec = row.value
      if type(spec) ~= "table" then return end
      local selected = controls.index
      beginCapture(mod, game, spec, function()
        refresh(selected)
      end)
    end,
  }))
  controls.screenId = "Gen2ItemShortcutControls"
  game.stack:push(controls)
end

local function openShortcutMenu(mod, game)
  if not (ListMenu and Menu and game and game.stack and game.save) then
    mod.log:warn("Item Shortcut could not open: required UI services are unavailable")
    return false
  end

  local slots = slotsFor(mod)
  local quick
  quick = mark(ListMenu.new(game, "ITEM SHORTCUT",
    buildSlotRows(game, slots, fastSlotFor(mod, slots)), {
    footer = shortcutFooter(mod),
    onChoose = function(row)
      if row.value == CONTROL_ROW then
        openControlMapping(mod, game)
      else
        openSlotContext(mod, game, quick, slots, row.value)
      end
    end,
  }))
  quick.screenId = "Gen2ItemShortcutMenu"
  game.stack:push(quick)
  return true
end

local function canOpen(game)
  local stack = game and game.stack
  local world = game and game.world
  if not stack or not world or type(stack.top) ~= "function" then return false end
  -- Gold/Silver/Crystal's overworld is NOT a stack state. Free roam is an
  -- empty stack, and World:acceptsMenuInput is the same gate START/SELECT use.
  if stack:top() ~= nil then return false end
  if not world.map or not (game.save and game.save.inventory) then return false end
  if type(world.acceptsMenuInput) == "function" then
    local ok, accepted = pcall(world.acceptsMenuInput, world)
    if not ok or not accepted then return false end
  elseif type(world.busy) == "function" then
    local ok, busy = pcall(world.busy, world)
    if ok and busy then return false end
  end
  return true
end

local function noteGamepad(game)
  local touch = game and game.touchControls
  if touch and type(touch.noteGamepad) == "function" then
    pcall(touch.noteGamepad, touch)
  end
end

local function playOpenSound(game)
  local ok, Sound = pcall(require, "src.core.Sound")
  if ok and Sound and type(Sound.play) == "function" and game and game.data then
    pcall(Sound.play, game.data, "Sfx_Menu")
  end
end

local function useFastShortcut(mod, game, slots, fastSlot)
  slots = slots or slotsFor(mod)
  fastSlot = fastSlot or fastSlotFor(mod, slots)
  if not fastSlot then
    showMessage(game, "No FAST item is set.\nUse SET FAST in menu.")
    return false
  end
  return useThroughGen2Pack(mod, game, slots[fastSlot])
end

local function handleShortcutInput(mod, game, kind, value)
  local menuMatch, fastMatch
  if kind == "keyboard" then
    menuMatch = value == keyboardBinding(mod)
    fastMatch = value == fastKeyboardBinding(mod)
  elseif kind == "gamepad" then
    menuMatch = value == gamepadBinding(mod)
    fastMatch = value == fastGamepadBinding(mod)
    if menuMatch or fastMatch then noteGamepad(game) end
  else
    return false
  end

  if not menuMatch and not fastMatch then return false end

  -- The menu binding keeps its existing close behavior. This also makes a
  -- shared menu/FAST binding close an open shortcut screen predictably.
  if menuMatch and removeShortcutStates(game) then return true end
  if not canOpen(game) then return false end

  local fastSlots, fastSlot
  if fastMatch then
    fastSlots = slotsFor(mod)
    fastSlot = fastSlotFor(mod, fastSlots)
  end

  -- FAST takes priority when both commands are mapped to the same input.
  if fastMatch and fastSlot then
    useFastShortcut(mod, game, fastSlots, fastSlot)
    return true
  end

  if menuMatch then
    playOpenSound(game)
    return openShortcutMenu(mod, game)
  end

  useFastShortcut(mod, game, fastSlots, fastSlot)
  return true
end

local function installInputHandlers(mod, game)
  if not game or type(game.keypressed) ~= "function"
      or type(game.gamepadpressed) ~= "function"
      or type(game.gamepadaxis) ~= "function" then
    mod.log:warn("Item Shortcut could not install input handlers; restart on a compatible game build")
    return false
  end

  -- Disable dispatchers from earlier releases during a development hot reload.
  for _, oldKey in ipairs({ "__item_shortcut_r1_dispatch_v1",
                             "__item_shortcut_input_dispatch_v2",
                             "__item_shortcut_input_dispatch_v3" }) do
    local oldDispatch = rawget(_G, oldKey)
    if type(oldDispatch) == "table" then
      oldDispatch.handler = nil
      oldDispatch.keyHandler = nil
      oldDispatch.padHandler = nil
      oldDispatch.axisHandler = nil
      oldDispatch.capture = nil
    end
  end

  local dispatch = rawget(_G, PATCH_KEY)
  if type(dispatch) ~= "table" then
    dispatch = {
      baseKey = game.keypressed,
      basePad = game.gamepadpressed,
      baseAxis = game.gamepadaxis,
      keyHandler = nil,
      padHandler = nil,
      axisHandler = nil,
      capture = nil,
      axisHeld = setmetatable({}, { __mode = "k" }),
      log = nil,
    }

    dispatch.keyWrapper = function(self, key, ...)
      local capture = dispatch.capture
      if capture then
        if key == "escape" then
          finishCapture(self, nil, true)
        elseif capture.kind == "keyboard" then
          finishCapture(self, key, false)
        end
        return
      end
      local handler = dispatch.keyHandler
      if handler then
        local ok, consumed = pcall(handler, self, key)
        if not ok then
          if dispatch.log and dispatch.log.warn then
            dispatch.log:warn("Item Shortcut keyboard handler failed: %s", tostring(consumed))
          end
        elseif consumed then
          return
        end
      end
      if dispatch.baseKey then return dispatch.baseKey(self, key, ...) end
    end

    dispatch.padWrapper = function(self, joystick, button, ...)
      local capture = dispatch.capture
      if capture then
        if capture.kind == "gamepad" then
          finishCapture(self, button, false)
        end
        return
      end
      local handler = dispatch.padHandler
      if handler then
        local ok, consumed = pcall(handler, self, joystick, button)
        if not ok then
          if dispatch.log and dispatch.log.warn then
            dispatch.log:warn("Item Shortcut controller handler failed: %s", tostring(consumed))
          end
        elseif consumed then
          return
        end
      end
      if dispatch.basePad then
        return dispatch.basePad(self, joystick, button, ...)
      end
    end

    dispatch.axisWrapper = function(self, joystick, axis, value, ...)
      local consumed = false
      if axis == "triggerleft" or axis == "triggerright" then
        local axisOwner = joystick or dispatch
        local held = dispatch.axisHeld[axisOwner]
        if not held then
          held = {}
          dispatch.axisHeld[axisOwner] = held
        end
        local active = value > 0.6
        if active and not held[axis] then
          held[axis] = true
          local capture = dispatch.capture
          if capture then
            if capture.kind == "gamepad" then
              finishCapture(self, axis, false)
            end
            consumed = true
          elseif dispatch.axisHandler then
            local ok, result = pcall(dispatch.axisHandler, self, joystick, axis, value)
            if not ok then
              if dispatch.log and dispatch.log.warn then
                dispatch.log:warn("Item Shortcut trigger handler failed: %s", tostring(result))
              end
            else
              consumed = result and true or false
            end
          end
        elseif not active and value < 0.35 then
          held[axis] = nil
        end
      elseif dispatch.capture then
        -- Ignore stick movement while waiting for a controller button.
        consumed = true
      end
      if consumed then return end
      if dispatch.baseAxis then
        return dispatch.baseAxis(self, joystick, axis, value, ...)
      end
    end

    rawset(_G, PATCH_KEY, dispatch)
    game.keypressed = dispatch.keyWrapper
    game.gamepadpressed = dispatch.padWrapper
    game.gamepadaxis = dispatch.axisWrapper
  else
    dispatch.axisHeld = dispatch.axisHeld or setmetatable({}, { __mode = "k" })
    if game.keypressed ~= dispatch.keyWrapper then
      dispatch.baseKey = game.keypressed
      game.keypressed = dispatch.keyWrapper
    end
    if game.gamepadpressed ~= dispatch.padWrapper then
      dispatch.basePad = game.gamepadpressed
      game.gamepadpressed = dispatch.padWrapper
    end
    if game.gamepadaxis ~= dispatch.axisWrapper then
      dispatch.baseAxis = game.gamepadaxis
      game.gamepadaxis = dispatch.axisWrapper
    end
  end

  dispatch.log = mod.log
  dispatch.keyHandler = function(currentGame, key)
    return handleShortcutInput(mod, currentGame, "keyboard", key)
  end
  dispatch.padHandler = function(currentGame, _, button)
    return handleShortcutInput(mod, currentGame, "gamepad", button)
  end
  dispatch.axisHandler = function(currentGame, _, axis)
    return handleShortcutInput(mod, currentGame, "gamepad", axis)
  end
  return true
end

return function(mod)
  -- Coexistence guard: this standalone package has its own manifest ID, save,
  -- and options bucket, so it can be installed beside older Item Shortcut
  -- packages. If an equivalent package is actually active, defer runtime
  -- ownership to it instead of installing a second keyboard/gamepad and PACK
  -- dispatcher. optional_dependencies orders known equivalents before us.
  local deferredTo
  if type(mod.find) == "function" then
    for _, otherId in ipairs(EQUIVALENT_MOD_IDS) do
      local ok, other = pcall(mod.find, otherId)
      if ok and other then
        deferredTo = other.id or otherId
        break
      end
    end
  end

  if not deferredTo then
    mod.events:on("game.ready", function(event)
      local game = event and event.game
      ensureBindings(mod, game)
      local inputOk = installInputHandlers(mod, game)
      local bagOk = installPackAssignment(mod, game)
      if inputOk and bagOk then
        mod.log:info("Item Shortcut Gen 2 installed [%s]: menu %s/%s, FAST %s/%s",
          MOD_ID,
          bindingLabel("keyboard", keyboardBinding(mod)),
          bindingLabel("gamepad", gamepadBinding(mod)),
          bindingLabel("keyboard", fastKeyboardBinding(mod)),
          bindingLabel("gamepad", fastGamepadBinding(mod)))
      end
    end)
  else
    mod.log:warn("Item Shortcut runtime deferred to active equivalent mod '%s'", tostring(deferredTo))
  end

  mod.exports.active = deferredTo == nil
  mod.exports.deferredTo = deferredTo

  mod.exports.open = function(game)
    if not canOpen(game) then return false end
    return openShortcutMenu(mod, game)
  end
  mod.exports.getSlots = function()
    return copySlots(slotsFor(mod))
  end
  mod.exports.assign = function(slot, itemId)
    slot = math.floor(tonumber(slot) or 0)
    if slot < 1 or slot > SLOT_COUNT then return false end
    local slots = slotsFor(mod)
    if type(itemId) == "string" and itemId ~= "" then
      assignItem(mod, slots, slot, itemId)
    else
      local wasFast = fastSlotFor(mod, slots) == slot
      slots[slot] = nil
      persistSlots(mod, slots)
      if wasFast then persistFastSlot(mod, nil) end
    end
    return true
  end
  mod.exports.clear = function(slot)
    return mod.exports.assign(slot, nil)
  end
  mod.exports.getFastSlot = function()
    local slots = slotsFor(mod)
    return fastSlotFor(mod, slots)
  end
  mod.exports.setFastSlot = function(slot)
    local slots = slotsFor(mod)
    slot = math.floor(tonumber(slot) or 0)
    if slot == 0 then
      persistFastSlot(mod, nil)
      return true
    end
    if slot < 1 or slot > SLOT_COUNT or not slots[slot] then return false end
    persistFastSlot(mod, slot)
    return true
  end
  mod.exports.getBindings = function()
    return {
      menuKeyboard = keyboardBinding(mod),
      menuGamepad = gamepadBinding(mod),
      fastKeyboard = fastKeyboardBinding(mod),
      fastGamepad = fastGamepadBinding(mod),
    }
  end
  mod.exports.resetBindings = function(game)
    return resetBindings(mod, game)
  end
end
