local root = assert(os.getenv("ITEM_SHORTCUT_ROOT"), "ITEM_SHORTCUT_ROOT missing")

local function spans(text)
  local out = {}
  for i = 1, #tostring(text or "") do out[#out + 1] = { from = i, to = i } end
  return out
end

package.preload["src.render.Font"] = function()
  return { split = spans, draw = function() end }
end
package.preload["src.render.TextBox"] = function()
  return { new = function(game, text) return { game = game, text = text, isOpaque = true } end }
end
package.preload["src.core.Strings"] = function()
  return setmetatable({}, { __call = function(_, s) return s end })
end
package.preload["src.ui.gen2.Chrome"] = function()
  return {
    DEFAULT_BOX_PALETTE = {}, box = function() end, cursorThrough = function() end,
    printThrough = function() end, cursor = function() end, print = function() end,
  }
end
package.preload["src.core.Sound"] = function()
  return { play = function() end }
end

local stack = { values = {} }
function stack:push(v) self.values[#self.values + 1] = v; return v end
function stack:pop() local v=self.values[#self.values]; self.values[#self.values]=nil; return v end
function stack:top() return self.values[#self.values] end
function stack:clear() self.values = {} end

package.preload["src.ui.ListMenu"] = function()
  local M = {}
  function M.new(game, title, items, opts)
    opts = opts or {}
    local self = {
      game=game, title=title, items=items, rows=7, index=1, scroll=0,
      onChoose=opts.onChoose, onCancel=opts.onCancel, footer=opts.footer,
    }
    function self:update()
      assert(type(self.rows) == "number", "ListMenu.rows must stay numeric")
      local maxRow = self.rows
      if self.index - self.scroll > maxRow then self.scroll = self.index - maxRow end
    end
    function self:close()
      if game.stack:top() == self then game.stack:pop() end
    end
    return self
  end
  return M
end
package.preload["src.ui.Menu"] = function()
  local M = {}
  function M.new(game, items, opts)
    local self = { game=game, items=items, rows=items, opts=opts or {}, index=1 }
    function self:close()
      if game.stack:top() == self then game.stack:pop() end
    end
    return self
  end
  return M
end

local PackMenu = { POCKETS = { {id="ITEM"}, {id="KEY_ITEM"}, {id="BALL"}, {id="TM_HM"} } }
function PackMenu:openSubmenu()
  self.submenu = { row = self.rows[self.index], rows = {"use", "give", "toss", "quit"}, index = 1 }
end
function PackMenu:closeSubmenu() self.submenu = nil end
function PackMenu:chooseSubmenu() self.baseChoose = (self.baseChoose or 0) + 1 end
function PackMenu:drawSubmenu() self.baseDraw = (self.baseDraw or 0) + 1 end
package.preload["src.ui.gen2.PackMenu"] = function() return PackMenu end

local optionBucket = {
  keyboard_key = "i", gamepad_button = "rightshoulder",
  fast_keyboard_key = "k", fast_gamepad_button = "leftshoulder",
}
local world = {
  map = { id = "NEW_BARK_TOWN" },
  accepted = true,
  calls = {},
}
function world:acceptsMenuInput() return self.accepted end
function world:useFieldItem(id)
  self.calls[#self.calls + 1] = id
  if id == "BICYCLE" then return "bicycle" end
  return nil
end

local game = {
  stack = stack,
  world = world,
  data = { items = {
    BICYCLE = { name="BICYCLE", fieldMenu="ITEMMENU_USE" },
    POTION = { name="POTION", fieldMenu="ITEMMENU_USE" },
    TM_DYNAMICPUNCH = { name="TM01", teaches="DYNAMICPUNCH" },
  } },
  save = {
    inventory = { BICYCLE=1, POTION=3, TM_DYNAMICPUNCH=1 },
    options = { modOptions = { item_shortcut_gen2 = optionBucket } },
  },
  options = { modOptions = { item_shortcut_gen2 = optionBucket } },
  mods = { modOptions = { item_shortcut_gen2 = optionBucket }, events = { emit=function() end } },
  touchControls = { noteGamepad = function() end },
  persistCount = 0,
  partyUses = {},
}
function game:persistOptions() self.persistCount = self.persistCount + 1 end
function game:keypressed(key) self.baseKeys = (self.baseKeys or 0) + 1 end
function game:gamepadpressed(js, button) self.basePads = (self.basePads or 0) + 1 end
function game:gamepadaxis(js, axis, value) self.baseAxes = (self.baseAxes or 0) + 1 end
function game:useFieldItem(id) self.partyUses[#self.partyUses + 1] = id end
function game:say(text) self.stack:push({ text=text, isOpaque=true }) end

local saved = {}
local callbacks = {}
local mod = {
  save = {
    get = function(_, k) return saved[k] end,
    set = function(_, k, v) saved[k] = v end,
  },
  options = { get = function(_, k) return game.options.modOptions.item_shortcut_gen2[k] end },
  events = { on = function(_, name, fn) callbacks[name] = fn end },
  exports = {},
  log = { warn=function() end, info=function() end },
}

local init = assert(loadfile(root .. "/main.lua"))()
init(mod)
assert(callbacks["game.ready"], "game.ready missing")
callbacks["game.ready"]({ game=game })

-- old v1.3 controller defaults migrate to v1.4/v2 defaults.
local b = mod.exports.getBindings()
assert(b.menuKeyboard == "i" and b.fastKeyboard == "k", "keyboard defaults changed")
assert(b.menuGamepad == "y" and b.fastGamepad == "x", "controller defaults did not migrate")
assert(optionBucket.controls_capture_v200 == true, "Gen2 migration marker missing")
assert(game.persistCount > 0, "Gen2 global options were not persisted")

-- PACK submenu is decorated only in field mode, before QUIT.
local pack = setmetatable({ game=game, rows={{id="POTION"}}, index=1 }, {__index=PackMenu})
pack:openSubmenu()
assert(pack.submenu.rows[#pack.submenu.rows-1] == "ASSIGN SHORTCUT", "PACK assignment row missing")
assert(pack.submenu.rows[#pack.submenu.rows] == "quit", "QUIT no longer last")
local battlePack = setmetatable({ game=game, rows={{id="POTION"}}, index=1, battle=true }, {__index=PackMenu})
battlePack:openSubmenu()
for _, id in ipairs(battlePack.submenu.rows) do assert(id ~= "ASSIGN SHORTCUT", "battle PACK was modified") end

-- Choosing the row opens the Gen2 semantic assignment screen.
pack.submenu.index = #pack.submenu.rows - 1
pack:chooseSubmenu()
local assign = stack:top()
assert(assign and assign.screenId == "Gen2ItemShortcutAssign", "Gen2 assignment picker did not open")
assert(type(assign.rows) == "number", "assignment picker overwrote ListMenu.rows")
assign:update()
stack:clear()

-- Export assignment and the quick screen are persistent and Modern-UI discoverable.
assert(mod.exports.assign(1, "BICYCLE"))
assert(mod.exports.assign(2, "POTION"))
assert(mod.exports.setFastSlot(1))
assert(mod.exports.open(game), "shortcut menu did not open on empty Gen2 stack")
local quick = stack:top()
assert(quick.screenId == "Gen2ItemShortcutMenu", "shortcut screen id is not Gen2 semantic")
assert(type(quick.rows) == "number", "shortcut overwrote ListMenu.rows")
assert(quick.items[1].right == "FAST", "FAST row not exposed through items")
quick:update() -- regression: mirrors ListMenu:syncScroll numeric comparison
-- Same menu key closes shortcut screens rather than opening another.
game:keypressed("i")
assert(stack:top() == nil, "menu shortcut did not close its own screens")

-- FAST field item takes the native World route and never falls into party use.
game:keypressed("k")
assert(world.calls[#world.calls] == "BICYCLE", "FAST BICYCLE did not call World:useFieldItem")
assert(#game.partyUses == 0, "field item incorrectly used Game2 party path")

-- FAST party item falls through World then uses Game2's native party-item route.
assert(mod.exports.setFastSlot(2))
game:keypressed("k")
assert(world.calls[#world.calls] == "POTION", "POTION did not probe World first")
assert(game.partyUses[#game.partyUses] == "POTION", "POTION did not use Game2 party path")

-- A TM follows the same native Game2 path after World declines it.
assert(mod.exports.assign(3, "TM_DYNAMICPUNCH"))
assert(mod.exports.setFastSlot(3))
game:keypressed("k")
assert(game.partyUses[#game.partyUses] == "TM_DYNAMICPUNCH", "TM did not use native Gen2 teaching path")

-- Control mapping remains press-to-bind on Gen 2.
assert(mod.exports.open(game), "shortcut menu did not reopen for controls")
quick = stack:top()
quick.onChoose(quick.items[6])
local controls = stack:top()
assert(controls and controls.screenId == "Gen2ItemShortcutControls", "control screen is not Gen2 semantic")
assert(type(controls.rows) == "number", "controls overwrote ListMenu.rows")
controls:update()
controls.index = 2
controls.onChoose(controls.items[2])
assert(stack:top().screenId == "Gen2ItemShortcutCapture", "controller capture did not open")
game:gamepadpressed(nil, "rightstick")
assert(mod.exports.getBindings().menuGamepad == "rightstick", "R3 capture failed on Gen2")
assert(controls.items[2].right == "R3", "control label did not refresh")
-- RESET DEFAULTS restores I/Y and K/X.
controls.index = 5
controls.onChoose(controls.items[5])
b = mod.exports.getBindings()
assert(b.menuKeyboard == "i" and b.menuGamepad == "y", "menu defaults did not reset")
assert(b.fastKeyboard == "k" and b.fastGamepad == "x", "FAST defaults did not reset")
stack:clear()

-- Busy/menu states block new shortcut openings.
stack:push({ screenId="Gen2StartMenu" })
assert(mod.exports.open(game) == false, "shortcut opened over another Gen2 screen")
stack:clear()
world.accepted = false
assert(mod.exports.open(game) == false, "shortcut bypassed World:acceptsMenuInput")
world.accepted = true

print("item_shortcut_gen2_test: ok")
