# Standalone identity regression

Expected invariants:
- manifest id = pokemonmod_gen2_item_shortcut
- games = [gen2]
- conflicts = []
- runtime MOD_ID = pokemonmod_gen2_item_shortcut
- equivalent active mods cause deferred runtime ownership
- existing shared dispatcher keys remain intact as duplicate-wrapper mutex
- Gen2ItemShortcut* screen IDs remain unchanged for Modern UI compatibility
