# Changelog

## 1.0.0

- Repackaged as a distinct Pokemon MOD Gen 2-only build.
- Changed manifest ID to `pokemonmod_gen2_modern_bag`.
- Restricted the manifest explicitly to `games: ["gen2"]`.
- Removed the hard conflict with `modern_bag`.
- Added optional dependency ordering for equivalent Modern Bag variants.
- Added an active-equivalent defer guard to prevent duplicate Pack/input/inventory patches.
- Moved the custom move-info input action and Modern UI adapter ownership into the new namespace.
- Preserved the shared low-level patch keys as a duplicate-wrapper mutex.
- Preserved all Modern Bag 2.0.0 Gen 2 behavior and Modern UI semantic screen IDs.
