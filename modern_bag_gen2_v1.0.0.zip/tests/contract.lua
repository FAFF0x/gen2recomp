package.path = "./?.lua;./?/init.lua;" .. package.path

local Bag = {}
function Bag.isBadge(id) return id:find("BADGE", 1, true) ~= nil end
function Bag.order(save) save.bagOrder = save.bagOrder or {}; return save.bagOrder end
function Bag.capacity(_, pocket) return ({ITEM=20,BALL=12,KEY_ITEM=25,TM_HM=57})[pocket or "ITEM"] or 20 end
function Bag.add(save,id,qty)
  local n=(save.inventory[id] or 0)+(qty or 1); if n>99 then return false end
  if not save.inventory[id] then table.insert(Bag.order(save),id) end
  save.inventory[id]=n; return true
end
package.preload["src.inventory.Bag"] = function() return Bag end

local MenuRepeat = { GEN2_DELAY=15, GEN2_RATE=5 }
function MenuRepeat.new(d,r,e) return {delay=d,rate=r,enabled=e~=false} end
package.preload["src.ui.MenuRepeat"] = function() return MenuRepeat end

local PackMenu = {}
PackMenu.__index=PackMenu
function PackMenu.new(game,opts)
  local self=setmetatable({},PackMenu); opts=opts or {}; self.game=game; self.save=game.save
  self.items=game.data.items; self.world=opts.world or game.world; self.battle=opts.battle; self.give=opts.give; self.tutorial=opts.tutorial
  self.rows={}; self.index=1; self.scroll=0; self.hold={}; return self
end
function PackMenu:update() end
function PackMenu:submenuRows() return {"quit"} end
function PackMenu:inBattle() return self.battle==true end
function PackMenu:isCancel() return self.index>#self.rows end
function PackMenu:ensureVisible() end
function PackMenu:playSfx() end
function PackMenu:drawDescription() end
function PackMenu:drawOverlays() end
package.preload["src.ui.gen2.PackMenu"] = function() return PackMenu end

package.preload["src.ui.ListMenu"] = function()
  local L={}; function L.new(game,title,rows,opts) return {game=game,title=title,items=rows,index=1,close=function() end} end; return L
end

local saved={}
local event_cb
local mod={
  save={get=function(_,k,d) local v=saved[k]; if v==nil then return d end; return v end, set=function(_,k,v) saved[k]=v end},
  options={define=function() end,get=function(_,k) return ({opening_pocket="medicine",hold_scroll_speed="fast"})[k] end},
  events={on=function(_,name,cb) if name=="game.ready" then event_cb=cb end end},
  exports={}, log={warn=function() end,info=function() end}, find=function() return nil end,
}

local install=assert(loadfile("main.lua")); install()(mod)
assert(type(event_cb)=="function")

local inventory={POTION=3,POKE_BALL=5,BICYCLE=1,X_ATTACK=2,FIRE_STONE=1,HM_SURF=1,TM_IRON_TAIL=1,TM_BITE=1}
local order={"POTION","POKE_BALL","BICYCLE","X_ATTACK","FIRE_STONE","HM_SURF","TM_IRON_TAIL","TM_BITE"}
local game={save={inventory=inventory,bagOrder=order,money=5000}, world={}, stack={push=function() end}, input={keypressed=function() end,keyreleased=function() end,gamepadpressed=function() end,gamepadreleased=function() end}, data={constants={},items={
 POTION={name="POTION",pocket="ITEM"}, POKE_BALL={name="POKé BALL",pocket="BALL"}, BICYCLE={name="BICYCLE",pocket="KEY_ITEM",canToss=false},
 X_ATTACK={name="X ATTACK",pocket="ITEM"}, FIRE_STONE={name="FIRE STONE",pocket="ITEM"},
 HM_SURF={name="HM03",tmLabel="HM03",tmNumber=53,pocket="TM_HM",teaches="SURF",canToss=false},
 TM_IRON_TAIL={name="TM23",tmLabel="TM23",tmNumber=23,pocket="TM_HM",teaches="IRON_TAIL"},
 TM_BITE={name="TM99",tmLabel="TM99",tmNumber=99,pocket="TM_HM",teaches="BITE"},
},moves={SURF={name="SURF",type="WATER",power=95,pp=15},IRON_TAIL={name="IRON TAIL",type="STEEL",power=100,pp=15},BITE={name="BITE",type="DARK",power=60,pp=25},GROWL={name="GROWL",type="NORMAL",power=0,pp=40}},types={}}}

event_cb({game=game})
assert(Bag.capacity(game.data,"ITEM")==math.huge)
assert(Bag.capacity(game.data,"BALL")==math.huge)
assert(Bag.add(game.save,"POTION",150,game.data)==true and game.save.inventory.POTION==153)

local pack=PackMenu.new(game,{world=game.world})
assert(pack.modernBag and pack:pocket().id=="medicine")
assert(pack.items==game.data.items, "item registry must stay intact")
assert(#pack.rows>=1 and pack.rows[1].id=="POTION")
pack:switchPocket(1)
assert(pack:pocket().id=="balls" and pack.rows[1].id=="POKE_BALL")

assert(mod.exports.pocketFor("BICYCLE",game.data.items.BICYCLE)=="key")
assert(mod.exports.pocketFor("HM_SURF",game.data.items.HM_SURF)=="machines")
assert(mod.exports.pocketFor("X_ATTACK",game.data.items.X_ATTACK)=="battle")
assert(mod.exports.moveDamageClass(game.data.moves.IRON_TAIL)=="PHYSICAL")
assert(mod.exports.moveDamageClass(game.data.moves.BITE)=="SPECIAL")
assert(mod.exports.moveDamageClass(game.data.moves.GROWL)=="STATUS")
local hm=mod.exports.machineInfo(game,"HM_SURF")
assert(hm and hm.code=="HM03" and hm.name=="SURF")
print("contract-ok")
