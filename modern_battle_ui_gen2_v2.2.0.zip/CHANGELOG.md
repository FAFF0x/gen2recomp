# Changelog

## 2.2.0
- Modernized the Gen 2 level-up stats window shown during battle.
- Modernized the four-move forget-selection screen used when learning a new move.
- Kept native Gen 2 input, queue progression, HM protection, cancel/decline logic, and move replacement authoritative.
- Added contract/render coverage for level-up and move-learning phases.

## 2.1.0

- Replaced vanilla in-battle message boxes with a modern high-resolution dialogue card.
- Added modern YES/NO prompts driven by the native Gen 2 selection state.
- Modernized `Use next POKéMON?` and trainer SHIFT/change-Pokémon prompts.
- Preserved native message timing, typewriter progression, paging and input authority.
- Keeps the source forget-move list/stats overlays when they contain specialized UI.

## 2.0.0

- Native Gen 2 port for Gold, Silver and Crystal.
- Uses `battle.status_hud_visible` and `battle.bottom_ui_visible` instead of
  replacing the battle screen.
- Added floating Gen 2 player/enemy status cards.
- Added true horizontal FIGHT / BAG / POKéMON / RUN presentation.
- Added modern 2x2 move selection with Gen 2 type effectiveness.
- Added Gen 2 physical/special/status classification.
- Added modern in-battle Party presenter with BEST OPTION analysis.
- Added modern in-battle Pack presenter with item detail panel.
- Preserves source Party/Pack update and input ownership.
- Optional compatibility with `gen2_modern_ui`, `new_icons`, and
  `new_item_icons`.
