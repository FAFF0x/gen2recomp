-- Modern Battle UI - Gen 2 v2.2.0
-- High-resolution presenter for Gold / Silver / Crystal.
--
-- The Gen 2 battle engine and all source screens remain the authority for
-- input and gameplay.  This mod only changes presentation and one navigation
-- policy (the battle command strip and FIGHT grid), using the public hooks the
-- engine exposes for exactly that purpose.

local VERSION = "2.2.0"
local MOD_ID = "modern_battle_ui_gen2"

local COMMAND_ORDER = { 1, 3, 2, 4 } -- FIGHT, PACK, POKEMON, RUN
local COMMANDS = {
  [1] = { label = "FIGHT", hint = "Moves" },
  [2] = { label = "POKéMON", hint = "Party" },
  [3] = { label = "BAG", hint = "Items" },
  [4] = { label = "RUN", hint = "Escape" },
}

local STATUS_NAMES = {
  poison = "PSN", psn = "PSN", toxic = "TOX",
  burn = "BRN", brn = "BRN",
  paralysis = "PAR", paralyze = "PAR", par = "PAR",
  freeze = "FRZ", frz = "FRZ",
  sleep = "SLP", slp = "SLP",
}

local TYPE_COLORS = {
  NORMAL = { 0.64, 0.64, 0.55 }, FIRE = { 0.92, 0.31, 0.20 },
  WATER = { 0.22, 0.48, 0.91 }, ELECTRIC = { 0.95, 0.77, 0.15 },
  GRASS = { 0.31, 0.68, 0.25 }, ICE = { 0.41, 0.76, 0.79 },
  FIGHTING = { 0.72, 0.19, 0.17 }, POISON = { 0.62, 0.28, 0.65 },
  GROUND = { 0.79, 0.64, 0.30 }, FLYING = { 0.55, 0.47, 0.87 },
  PSYCHIC = { 0.91, 0.29, 0.51 }, BUG = { 0.62, 0.68, 0.12 },
  ROCK = { 0.69, 0.59, 0.23 }, GHOST = { 0.43, 0.34, 0.60 },
  DRAGON = { 0.42, 0.22, 0.88 }, DARK = { 0.38, 0.29, 0.24 },
  STEEL = { 0.63, 0.63, 0.72 },
}

local function clamp(v, lo, hi)
  v = tonumber(v) or lo
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

local function safeText(v)
  if v == nil then return "" end
  if type(v) == "table" then
    v = v.text or v.label or v.name or v.id or ""
  end
  local s = tostring(v)
  s = s:gsub("<PK><MN>", "POKéMON")
  s = s:gsub("<POKE>", "POKé")
  s = s:gsub("<LV>", "Lv")
  s = s:gsub("<ID>", "ID")
  s = s:gsub("<NEXT>", " ")
  s = s:gsub("[\1\2\3\4\5\6\7]", " ")
  s = s:gsub("[\r\f\v]", " ")
  s = s:gsub("%s+", " ")
  return s:match("^%s*(.-)%s*$") or s
end

local function upperType(v)
  local s = safeText(v):upper():gsub("_TYPE$", ""):gsub("_", " ")
  if s == "PSYCHIC TYPE" then s = "PSYCHIC" end
  return s ~= "" and s or "NORMAL"
end

local function stackStates(game)
  local stack = game and game.stack
  return stack and stack.states or nil
end

local function topState(game)
  local stack = game and game.stack
  if stack and type(stack.top) == "function" then return stack:top() end
  local states = stackStates(game)
  return type(states) == "table" and states[#states] or nil
end

local function isBattleState(state)
  return type(state) == "table"
    and (state.screenId == "Gen2BattleState"
      or (state.battle and state.queue and type(state.phase) == "string"
        and type(state.menuIndex) == "number"))
end

local function battleState(game)
  local states = stackStates(game)
  if type(states) == "table" then
    for i = #states, 1, -1 do
      if isBattleState(states[i]) then return states[i] end
    end
  end
  local top = topState(game)
  if isBattleState(top) then return top end
  return nil
end

local function directBattle(game, state)
  return state ~= nil and topState(game) == state
end

local function battleBelow(game, child)
  local states = stackStates(game)
  if type(states) ~= "table" then return nil end
  local found = false
  for i = #states, 1, -1 do
    local state = states[i]
    if state == child then
      found = true
    elseif found and isBattleState(state) then
      return state
    end
  end
  return nil
end

local function isBattleParty(state)
  return type(state) == "table"
    and state.battle == true
    and type(state.party) == "table"
    and type(state.index) == "number"
end

local function isBattlePack(state)
  if type(state) ~= "table" or state.battle ~= true
      or type(state.rows) ~= "table" or type(state.index) ~= "number" then
    return false
  end
  if state.screenId == "Gen2PackMenu" then return true end
  return type(state.pocket) == "function" and type(state.useSelected) == "function"
end

local function sourceSlotForMenuIndex(menuIndex)
  for slot, source in ipairs(COMMAND_ORDER) do
    if source == menuIndex then return slot end
  end
  return 1
end

local function monDef(game, mon)
  local data = game and game.data
  return data and data.pokemon and mon and mon.species
    and data.pokemon[mon.species] or nil
end

local function monName(game, mon)
  if not mon then return "—" end
  if mon.isEgg then return "EGG" end
  local def = monDef(game, mon)
  return safeText(mon.nickname or mon.name or (def and def.name) or mon.species or "POKéMON")
end

local function monTypes(game, mon)
  local def = monDef(game, mon)
  local source = (def and def.types) or (mon and mon.types) or {}
  local out = {}
  if type(source) == "table" then
    for _, value in ipairs(source) do out[#out + 1] = upperType(value) end
  end
  if #out == 0 and def then
    if def.type1 then out[#out + 1] = upperType(def.type1) end
    if def.type2 and upperType(def.type2) ~= out[1] then
      out[#out + 1] = upperType(def.type2)
    end
  end
  return out
end

local function maxHp(mon)
  return math.max(1, tonumber(mon and (mon.maxHp or (mon.stats and mon.stats.hp))) or 1)
end

local function shownHp(state, mon, side)
  if state and type(state.hudHp) == "function" then
    local ok, hp = pcall(state.hudHp, state, mon, side)
    if ok and tonumber(hp) then return tonumber(hp) end
  end
  return tonumber(mon and mon.hp) or 0
end

local function shownStatus(state, mon, side)
  local value = mon and mon.status
  if state and type(state.hudStatus) == "function" then
    local ok, status = pcall(state.hudStatus, state, mon, side)
    if ok then value = status end
  end
  if not value then return nil end
  local key = tostring(value):lower()
  return STATUS_NAMES[key] or key:upper():sub(1, 3)
end

local function moveDef(game, move)
  local id = type(move) == "table" and move.id or move
  local data = game and game.data
  return id, data and data.moves and id and data.moves[id] or nil
end

local function moveCategory(game, def)
  if not def or (tonumber(def.power) or 0) <= 0 then return "STATUS" end
  local ok, Damage = pcall(require, "src.battle.gen2.Damage")
  if ok and Damage and type(Damage.isPhysical) == "function" then
    local types = game and game.data and game.data.type_chart
      and game.data.type_chart.types
    local ok2, physical = pcall(Damage.isPhysical, def.type, types)
    if ok2 then return physical and "PHYSICAL" or "SPECIAL" end
  end
  local t = upperType(def.type)
  local physical = {
    NORMAL=true, FIGHTING=true, FLYING=true, POISON=true, GROUND=true,
    ROCK=true, BUG=true, GHOST=true, STEEL=true,
  }
  return physical[t] and "PHYSICAL" or "SPECIAL"
end

local function typeMultiplier(game, battleScreen, moveType, defender)
  if not moveType or not defender then return 10 end
  local types = monTypes(game, defender)
  local matchups = game and game.data and game.data.type_chart
    and game.data.type_chart.matchups or {}
  local engine = battleScreen and battleScreen.battle
  if engine and type(engine.matchupsAgainst) == "function" then
    local ok, rows = pcall(engine.matchupsAgainst, engine, defender)
    if ok and type(rows) == "table" then matchups = rows end
  end
  local ok, Damage = pcall(require, "src.battle.gen2.Damage")
  if ok and Damage and type(Damage.typeMultiplier) == "function" then
    local ok2, value = pcall(Damage.typeMultiplier, moveType, types, matchups)
    if ok2 and tonumber(value) then return tonumber(value) end
  end
  local mult = 10
  for _, row in ipairs(matchups or {}) do
    if row.attacker == moveType then
      for _, targetType in ipairs(types) do
        if row.defender == targetType then
          mult = math.floor(mult * (tonumber(row.multiplier) or 10) / 10)
          break
        end
      end
    end
  end
  return mult
end

local function effectiveness(mult)
  mult = tonumber(mult) or 10
  if mult <= 0 then return "NO EFFECT", { 0.58, 0.60, 0.66 } end
  if mult >= 40 then return "SUPER x4", { 0.31, 0.84, 0.48 } end
  if mult >= 20 then return "SUPER x2", { 0.31, 0.84, 0.48 } end
  if mult == 10 then return "NORMAL x1", { 0.62, 0.69, 0.78 } end
  if mult <= 2 then return "RESIST x0.25", { 0.95, 0.46, 0.37 } end
  return "RESIST x0.5", { 0.95, 0.58, 0.31 }
end

return function(mod)
  local Assets = nil
  pcall(function() Assets = require("src.render.Assets") end)
  local fontCache = {}
  local imageCache = {}

  local function option(key, default)
    if mod.options and type(mod.options.get) == "function" then
      local ok, value = pcall(mod.options.get, mod.options, key)
      if ok and value ~= nil then return value end
    end
    return default
  end

  if mod.options and type(mod.options.define) == "function" then
    mod.options:define({
      { key = "enabled", label = "MODERN BATTLE UI GEN 2", type = "toggle",
        default = true,
        description = "Enable the high-resolution Gold/Silver/Crystal battle interface." },
      { key = "hide_native", label = "HIDE NATIVE BATTLE UI", type = "toggle",
        default = true,
        description = "Hide source HUD/menu layers only where this mod provides a complete replacement." },
      { key = "enemy_hp", label = "ENEMY HP NUMBERS", type = "toggle",
        default = false,
        description = "Show exact enemy HP values next to the modern HP bar." },
      { key = "move_details", label = "MOVE DETAILS", type = "toggle",
        default = true,
        description = "Show type, Gen 2 physical/special class, power, accuracy, PP and effectiveness." },
      { key = "battle_children", label = "MODERN PARTY / BAG", type = "toggle",
        default = true,
        description = "Replace in-battle Party and Pack presentation while keeping their native update/input logic." },
    })
  end

  local function font(size)
    local g = love and love.graphics
    if not g then return nil end
    size = math.max(9, math.floor(size + 0.5))
    if not fontCache[size] then
      local ok, f = pcall(g.newFont, size)
      fontCache[size] = ok and f or g.getFont()
    end
    return fontCache[size]
  end

  local function setFont(size)
    local f = font(size)
    if f and love and love.graphics then love.graphics.setFont(f) end
    return f
  end

  local function panel(x, y, w, h, selected, radius)
    local g = love.graphics
    radius = radius or 14
    if selected then
      g.setColor(0.10, 0.20, 0.31, 0.97)
      g.rectangle("fill", x, y, w, h, radius, radius)
      g.setColor(0.26, 0.77, 0.94, 1)
      g.setLineWidth(2)
      g.rectangle("line", x, y, w, h, radius, radius)
    else
      g.setColor(0.055, 0.075, 0.105, 0.94)
      g.rectangle("fill", x, y, w, h, radius, radius)
      g.setColor(0.19, 0.25, 0.32, 0.95)
      g.setLineWidth(1)
      g.rectangle("line", x, y, w, h, radius, radius)
    end
  end

  local function text(s, x, y, size, r, g, b, a)
    local G = love.graphics
    setFont(size)
    G.setColor(r or 0.93, g or 0.96, b or 1, a or 1)
    G.print(safeText(s), x, y)
  end

  local function rightText(s, x2, y, size, r, g, b, a)
    local f = setFont(size)
    local value = safeText(s)
    local w = f and f:getWidth(value) or #value * size * 0.5
    text(value, x2 - w, y, size, r, g, b, a)
  end

  local function fitText(s, maxW, size)
    local value = safeText(s)
    local f = font(size)
    if not f or f:getWidth(value) <= maxW then return value end
    while #value > 2 and f:getWidth(value .. "…") > maxW do
      value = value:sub(1, -2)
    end
    return value .. "…"
  end

  local function bar(x, y, w, h, value, maxValue)
    local G = love.graphics
    local ratio = clamp((tonumber(value) or 0) / math.max(1, tonumber(maxValue) or 1), 0, 1)
    G.setColor(0.12, 0.16, 0.20, 1)
    G.rectangle("fill", x, y, w, h, h/2, h/2)
    if ratio > 0.5 then G.setColor(0.30, 0.82, 0.43, 1)
    elseif ratio > 0.2 then G.setColor(0.94, 0.70, 0.20, 1)
    else G.setColor(0.93, 0.31, 0.29, 1) end
    G.rectangle("fill", x, y, math.max(0, w * ratio), h, h/2, h/2)
  end

  local function typePill(typeName, x, y, size)
    local G = love.graphics
    local t = upperType(typeName)
    local c = TYPE_COLORS[t] or TYPE_COLORS.NORMAL
    local f = font(size)
    local w = (f and f:getWidth(t) or #t * size * 0.5) + 16
    local h = size + 10
    G.setColor(c[1], c[2], c[3], 0.95)
    G.rectangle("fill", x, y, w, h, h/2, h/2)
    text(t, x + 8, y + 4, size, 1, 1, 1, 1)
    return w
  end

  local function viewportRect(viewport)
    local g = love.graphics
    local ww, wh = g.getDimensions()
    local x = tonumber(viewport and viewport.gameX) or 0
    local y = tonumber(viewport and viewport.gameY) or 0
    local w = tonumber(viewport and viewport.gameWidth) or ww
    local h = tonumber(viewport and viewport.gameHeight) or wh
    -- High-resolution layouts should use the useful window area when the game
    -- is letterboxed; keep a modest inset so host controls can still sit above.
    if ww > w * 1.25 then x, w = 16, ww - 32 end
    if wh > h * 1.20 then y, h = 12, wh - 24 end
    return x, y, w, h
  end

  local function drawMonCard(game, battleScreen, mon, side, x, y, w, h)
    if not mon then return end
    panel(x, y, w, h, false)
    local name = monName(game, mon)
    local level = tonumber(mon.level) or 1
    text(fitText(name, w * 0.58, h * 0.25), x + 18, y + 13, h * 0.17)
    rightText("Lv " .. level, x + w - 18, y + 14, h * 0.14, 0.66, 0.76, 0.87)

    local status = shownStatus(battleScreen, mon, side)
    local tx = x + 18
    for _, t in ipairs(monTypes(game, mon)) do
      tx = tx + typePill(t, tx, y + h * 0.34, h * 0.09) + 6
    end
    if status then
      text(status, x + w - 56, y + h * 0.36, h * 0.11, 1, 0.72, 0.35)
    end

    local hp = shownHp(battleScreen, mon, side)
    local mhp = maxHp(mon)
    bar(x + 18, y + h * 0.68, w - 36, math.max(8, h * 0.09), hp, mhp)
    if side == "player" or option("enemy_hp", false) then
      rightText(math.max(0, math.floor(hp)) .. " / " .. mhp,
        x + w - 18, y + h * 0.79, h * 0.105, 0.75, 0.82, 0.88)
    end

    if side == "enemy" and option("caught_marker", true) ~= false then
      local caught = game and game.save and game.save.pokedex
        and game.save.pokedex.caught
      if caught and mon.species and caught[mon.species] then
        text("CAUGHT", x + 18, y + h * 0.80, h * 0.095, 0.40, 0.88, 0.70)
      end
    end
  end

  local function moveInfo(game, battleScreen, move, defender)
    local id, def = moveDef(game, move)
    local name = safeText((def and def.name) or id or "—")
    local moveType = upperType(def and def.type)
    local power = tonumber(def and def.power) or 0
    local accuracy = def and def.accuracy
    local pp = type(move) == "table" and move.pp or nil
    local maxPp = type(move) == "table" and (move.maxPp or move.maxPP) or nil
    local mult = typeMultiplier(game, battleScreen, def and def.type, defender)
    return {
      id=id, def=def, name=name, type=moveType, power=power,
      accuracy=accuracy, pp=pp, maxPp=maxPp,
      category=moveCategory(game, def), mult=mult,
    }
  end

  local function drawCommandMenu(game, state, x, y, w, h)
    local gap = 10
    local cellW = (w - gap * 3) / 4
    local selectedSource = clamp(math.floor(tonumber(state.menuIndex) or 1), 1, 4)
    for slot, source in ipairs(COMMAND_ORDER) do
      local cx = x + (slot - 1) * (cellW + gap)
      local selected = source == selectedSource
      panel(cx, y, cellW, h, selected, 13)
      local row = COMMANDS[source]
      local label = row.label
      if state.contest and source == 3 then label = "PARK BALL" end
      text(label, cx + 16, y + 15, h * 0.20,
        selected and 0.95 or 0.82, selected and 0.99 or 0.87, 1)
      text(row.hint, cx + 16, y + h - 28, h * 0.12, 0.48, 0.59, 0.70)
    end
  end

  local function drawFightMenu(game, state, x, y, w, h)
    local battle = state.battle
    local player = battle and battle.player
    local enemy = battle and battle.enemy
    local moves = (player and player.moves) or {}
    local gap = 10
    local detailH = math.min(92, h * 0.30)
    local gridH = h - detailH - 10
    local cellW = (w - gap) / 2
    local cellH = (gridH - gap) / 2
    for i = 1, 4 do
      local move = moves[i]
      local col = (i - 1) % 2
      local row = math.floor((i - 1) / 2)
      local bx = x + col * (cellW + gap)
      local by = y + row * (cellH + gap)
      local selected = i == (state.moveIndex or 1)
      panel(bx, by, cellW, cellH, selected, 12)
      if move then
        local info = moveInfo(game, state, move, enemy)
        text(fitText(info.name, cellW - 30, cellH * 0.19),
          bx + 14, by + 12, cellH * 0.16)
        local pillW = typePill(info.type, bx + 14, by + cellH * 0.43, cellH * 0.09)
        local eff, color = effectiveness(info.mult)
        rightText(eff, bx + cellW - 14, by + cellH * 0.45,
          cellH * 0.105, color[1], color[2], color[3])
        local pp = info.pp ~= nil and tostring(info.pp) or "—"
        if info.maxPp then pp = pp .. "/" .. tostring(info.maxPp) end
        text("PP " .. pp, bx + 14, by + cellH - 26,
          cellH * 0.105, 0.63, 0.72, 0.82)
        if state.moveSwapIndex == i then
          rightText("MOVE", bx + cellW - 14, by + cellH - 26,
            cellH * 0.105, 0.98, 0.75, 0.27)
        end
      else
        text("—", bx + 14, by + 14, cellH * 0.16, 0.45, 0.51, 0.58)
      end
    end

    local selected = moves[state.moveIndex or 1]
    panel(x, y + gridH + 10, w, detailH, false, 12)
    if selected then
      local info = moveInfo(game, state, selected, enemy)
      text(info.category, x + 16, y + gridH + 22, detailH * 0.16,
        0.45, 0.78, 0.96)
      local power = info.power > 0 and tostring(info.power) or "—"
      local acc = info.accuracy ~= nil and tostring(info.accuracy) or "—"
      text("POWER " .. power .. "   ACC " .. acc,
        x + 16, y + gridH + 48, detailH * 0.13, 0.75, 0.82, 0.88)
      local desc = safeText(info.def and (info.def.description or info.def.effectText
        or info.def.effect) or "")
      if desc ~= "" then
        text(fitText(desc, w * 0.50, detailH * 0.12),
          x + w * 0.47, y + gridH + 27, detailH * 0.12, 0.72, 0.78, 0.85)
      end
      local eff, color = effectiveness(info.mult)
      rightText(eff, x + w - 16, y + gridH + detailH - 27,
        detailH * 0.14, color[1], color[2], color[3])
    end
  end

  local YES_NO_PHASES = {
    ["ask-nickname"] = true,
    ["ask-forget"] = true,
    ["stop-learning"] = true,
    ["ask-shift"] = true,
    ["ask-next-mon"] = true,
  }

  local function forgetSelectionActive(state)
    return state and state.phase == "choose-forget"
      and (tonumber(state.messageTimer) or 0) <= 0
      and state.pendingLearn ~= nil
  end

  local function statsBoxActive(state)
    return state and state.phase == "stats-box" and state.statsBoxMon ~= nil
  end

  local function modernMessageOwned(state)
    if not state then return false end
    if state.phase == "menu" or state.phase == "moves" then return true end
    -- v2.2 owns the complete in-battle level-up / move-learning presentation.
    -- Input, queue progression and move replacement still belong to the native
    -- Gen 2 BattleState; only its bottom panel / stats window are replaced.
    if statsBoxActive(state) or forgetSelectionActive(state) then return true end
    return state.message ~= nil and tostring(state.message) ~= ""
  end

  local function battleMessageLines(state)
    if not state then return {} end
    if type(state.messageLines) == "function" then
      local ok, lines = pcall(state.messageLines, state)
      if ok and type(lines) == "table" and #lines > 0 then return lines end
    end
    local raw = tostring(state.message or "")
    local lines = {}
    raw = raw:gsub("[\f\v]", "\n")
    for line in (raw .. "\n"):gmatch("([^\n]*)\n") do
      if line ~= "" or #lines > 0 then lines[#lines + 1] = line end
    end
    if #lines == 0 and raw ~= "" then lines[1] = raw end
    return lines
  end

  local function yesNoIndex(state)
    if not (state and YES_NO_PHASES[state.phase]) then return nil end
    if (tonumber(state.messageTimer) or 0) > 0 then return nil end
    if state.phase == "ask-nickname" then return tonumber(state.nicknameIndex) or 1 end
    if state.phase == "ask-shift" then return tonumber(state.shiftIndex) or 1 end
    if state.phase == "ask-next-mon" then return tonumber(state.nextMonIndex) or 1 end
    return tonumber(state.forgetChoice) or 1
  end

  local function drawLevelStats(game, state, x, y, w, h)
    local mon = state and state.statsBoxMon
    if not mon then return end
    local G = love.graphics
    panel(x, y, w, h, false, 14)
    G.setColor(0.24, 0.75, 0.95, 0.95)
    G.rectangle("fill", x, y + 12, 4, h - 24, 2, 2)

    text("LEVEL UP", x + 20, y + 14, math.max(11, h * 0.075),
      0.42, 0.78, 0.98)
    text(fitText(monName(game, mon), w * 0.48, math.max(18, h * 0.14)),
      x + 20, y + h * 0.25, math.max(18, h * 0.14))
    rightText("Lv " .. tostring(mon.level or 1), x + w - 20,
      y + h * 0.27, math.max(15, h * 0.11), 0.72, 0.82, 0.92)

    local stats = mon.stats or {}
    local rows = {
      { "ATTACK", stats.attack },
      { "DEFENSE", stats.defense },
      { "SP. ATK", stats.specialAttack or stats.special },
      { "SP. DEF", stats.specialDefense or stats.special },
      { "SPEED", stats.speed },
    }
    local gap = 8
    local cellY = y + h * 0.53
    local cellH = h - (cellY - y) - 42
    local cellW = (w - 40 - gap * 4) / 5
    for i, row in ipairs(rows) do
      local cx = x + 20 + (i - 1) * (cellW + gap)
      panel(cx, cellY, cellW, cellH, false, 9)
      text(row[1], cx + 10, cellY + 10, math.max(9, cellH * 0.16),
        0.54, 0.66, 0.78)
      rightText(tostring(row[2] or "—"), cx + cellW - 10,
        cellY + cellH * 0.42, math.max(15, cellH * 0.30), 0.95, 0.98, 1)
    end
    rightText("A / B  CONTINUE", x + w - 18, y + h - 25,
      math.max(9, h * 0.065), 0.48, 0.67, 0.80)
  end

  local function drawForgetSelection(game, state, x, y, w, h)
    local learn = state and state.pendingLearn
    local party = state and state.battle and state.battle.party or {}
    local mon = learn and party and party[learn.index]
    if not (learn and mon) then return end
    local G = love.graphics
    panel(x, y, w, h, false, 14)
    G.setColor(0.24, 0.75, 0.95, 0.95)
    G.rectangle("fill", x, y + 12, 4, h - 24, 2, 2)

    text("LEARN MOVE", x + 20, y + 13, math.max(10, h * 0.055),
      0.42, 0.78, 0.98)
    text(fitText(state.message or "Which move should be forgotten?",
      w * 0.54, math.max(15, h * 0.085)), x + 20, y + 40,
      math.max(15, h * 0.085))
    local newName = safeText(learn.moveName)
    if newName == "" then
      local _, def = moveDef(game, learn.move)
      newName = safeText((def and def.name) or learn.move or "NEW MOVE")
    end
    rightText("NEW  " .. newName, x + w - 20, y + 42,
      math.max(12, h * 0.068), 0.54, 0.88, 0.68)

    local moves = mon.moves or {}
    local gap = 10
    local gridY = y + math.max(78, h * 0.25)
    local gridH = h - (gridY - y) - 38
    local cellW = (w - 40 - gap) / 2
    local cellH = (gridH - gap) / 2
    for i = 1, 4 do
      local move = moves[i]
      local col = (i - 1) % 2
      local row = math.floor((i - 1) / 2)
      local cx = x + 20 + col * (cellW + gap)
      local cy = gridY + row * (cellH + gap)
      local selected = i == (tonumber(state.forgetIndex) or 1)
      panel(cx, cy, cellW, cellH, selected, 10)
      if move then
        local info = moveInfo(game, state, move, nil)
        text(fitText(info.name, cellW - 110, math.max(13, cellH * 0.20)),
          cx + 12, cy + 10, math.max(13, cellH * 0.20))
        local pillY = cy + cellH * 0.47
        typePill(info.type, cx + 12, pillY, math.max(8, cellH * 0.11))
        local pp = info.pp ~= nil and tostring(info.pp) or "—"
        if info.maxPp then pp = pp .. "/" .. tostring(info.maxPp) end
        rightText("PP " .. pp, cx + cellW - 12, pillY + 4,
          math.max(10, cellH * 0.13), 0.64, 0.73, 0.82)
        if selected then
          rightText("FORGET", cx + cellW - 12, cy + 12,
            math.max(10, cellH * 0.13), 0.98, 0.76, 0.28)
        end
      else
        text("—", cx + 12, cy + 12, math.max(13, cellH * 0.20),
          0.45, 0.51, 0.58)
      end
    end
    text("A  FORGET", x + 20, y + h - 26, math.max(10, h * 0.055),
      0.56, 0.76, 0.90)
    rightText("B  CANCEL", x + w - 20, y + h - 26,
      math.max(10, h * 0.055), 0.56, 0.76, 0.90)
  end

  local function drawBattleMessage(state, x, y, w, h)
    local G = love.graphics
    panel(x, y, w, h, false, 14)

    -- Modern accent rail + compact semantic label.
    G.setColor(0.24, 0.75, 0.95, 0.95)
    G.rectangle("fill", x, y + 12, 4, h - 24, 2, 2)
    text("BATTLE", x + 20, y + 14, math.max(10, h * 0.095),
      0.42, 0.78, 0.98)

    local choice = yesNoIndex(state)
    local choiceW = choice and math.min(250, w * 0.30) or 0
    local textW = w - 40 - (choiceW > 0 and choiceW + 18 or 0)
    local lines = battleMessageLines(state)
    local fontSize = math.max(15, math.min(22, h * 0.17))
    local lineY = y + h * 0.38
    local lineGap = fontSize * 1.35

    if #lines == 0 then
      text("…", x + 20, lineY, fontSize, 0.78, 0.84, 0.90)
    else
      for i = 1, math.min(2, #lines) do
        text(fitText(lines[i], textW, fontSize), x + 20,
          lineY + (i - 1) * lineGap, fontSize)
      end
    end

    if choice then
      local gap = 8
      local bx = x + w - choiceW
      local by = y + 16
      local bh = (h - 32 - gap) / 2
      local bw = choiceW - 16
      local labels = { "YES", "NO" }
      for i = 1, 2 do
        panel(bx, by + (i - 1) * (bh + gap), bw, bh, choice == i, 10)
        text(labels[i], bx + 16, by + (i - 1) * (bh + gap) + bh * 0.28,
          math.max(13, bh * 0.26),
          choice == i and 0.96 or 0.75,
          choice == i and 0.99 or 0.82,
          1)
      end
    elseif (tonumber(state.messageTimer) or 0) > 0 then
      rightText("A  CONTINUE", x + w - 18, y + h - 27,
        math.max(10, h * 0.09), 0.48, 0.67, 0.80)
    end
  end

  local function drawBattle(game, viewport, state)
    if not state or option("enabled", true) == false then return false end
    local G = love.graphics
    if not G then return false end
    local x, y, w, h = viewportRect(viewport)
    local scale = clamp(math.min(w / 960, h / 600), 0.65, 1.7)
    local cardW = math.min(w * 0.36, 350 * scale)
    local cardH = math.min(h * 0.18, 112 * scale)
    local margin = 18 * scale
    local statsPhase = statsBoxActive(state)
    local forgetPhase = forgetSelectionActive(state)
    local hasMessage = modernMessageOwned(state)
      and state.phase ~= "menu" and state.phase ~= "moves"
      and not statsPhase and not forgetPhase
    local bottomH
    if state.phase == "moves" then
      bottomH = math.min(h * 0.43, 278 * scale)
    elseif forgetPhase then
      bottomH = math.min(h * 0.48, 310 * scale)
    elseif statsPhase then
      bottomH = math.min(h * 0.34, 210 * scale)
    elseif hasMessage then
      bottomH = math.min(h * 0.24, 148 * scale)
    else
      bottomH = math.min(h * 0.17, 100 * scale)
    end

    G.push("all")
    drawMonCard(game, state, state.battle and state.battle.enemy, "enemy",
      x + margin, y + margin, cardW, cardH)
    drawMonCard(game, state, state.battle and state.battle.player, "player",
      x + w - cardW - margin,
      y + h - bottomH - cardH - margin * 1.4, cardW, cardH)

    if state.phase == "menu" then
      drawCommandMenu(game, state, x + margin,
        y + h - bottomH - margin, w - margin * 2, bottomH)
    elseif state.phase == "moves" then
      drawFightMenu(game, state, x + margin,
        y + h - bottomH - margin, w - margin * 2, bottomH)
    elseif forgetPhase then
      drawForgetSelection(game, state, x + margin,
        y + h - bottomH - margin, w - margin * 2, bottomH)
    elseif statsPhase then
      drawLevelStats(game, state, x + margin,
        y + h - bottomH - margin, w - margin * 2, bottomH)
    elseif hasMessage then
      drawBattleMessage(state, x + margin,
        y + h - bottomH - margin, w - margin * 2, bottomH)
    end
    G.pop()
    return true
  end

  local function drawPartyIcon(state, mon, x, y, size)
    if not (state and type(state.iconFor) == "function" and mon) then return false end
    local ok, image, frame = pcall(state.iconFor, state, mon)
    if not ok or not image then return false end
    local G = love.graphics
    local iw, ih = image:getDimensions()
    frame = tonumber(frame) or 0
    local okq, quad = pcall(G.newQuad, 0, frame * 16, 16, 16, iw, ih)
    if not okq then return false end
    local s = size / 16
    G.setColor(1, 1, 1, 1)
    G.draw(image, quad, x, y, 0, s, s)
    return true
  end

  local function bestMoveFor(game, battleScreen, mon, enemy)
    local bestIndex, bestScore, bestInfo
    for i, move in ipairs((mon and mon.moves) or {}) do
      local info = moveInfo(game, battleScreen, move, enemy)
      local usable = (tonumber(move.pp) or 0) > 0 and info.power > 0
      local score = usable and (info.mult * 1000 + info.power) or -1
      if not bestScore or score > bestScore then
        bestIndex, bestScore, bestInfo = i, score, info
      end
    end
    return bestIndex, bestInfo
  end

  local function drawParty(game, viewport, state, battleScreen)
    local G = love.graphics
    local x, y, w, h = viewportRect(viewport)
    local margin = 16
    G.push("all")
    G.setColor(0.025, 0.035, 0.052, 0.985)
    G.rectangle("fill", x, y, w, h)
    text("BATTLE PARTY", x + margin, y + 14, 24, 0.92, 0.97, 1)
    text(safeText(state.prompt or "Choose a POKéMON."),
      x + margin, y + 48, 13, 0.51, 0.61, 0.72)

    local leftW = math.min(w * 0.39, 390)
    local listY = y + 78
    local rowH = math.max(54, (h - 100) / 7)
    panel(x + margin, listY, leftW - margin, h - 94, false, 14)
    for i, mon in ipairs(state.party or {}) do
      local ry = listY + 10 + (i - 1) * rowH
      local selected = i == state.index
      if selected then
        G.setColor(0.10, 0.22, 0.33, 0.95)
        G.rectangle("fill", x + margin + 8, ry, leftW - margin - 16,
          rowH - 6, 10, 10)
      end
      drawPartyIcon(state, mon, x + margin + 16, ry + 8, rowH - 22)
      text(fitText(monName(game, mon), leftW * 0.44, 15),
        x + margin + rowH, ry + 7, 15)
      text("Lv " .. tostring(mon.level or 1), x + margin + rowH, ry + 29,
        11, 0.55, 0.65, 0.75)
      if not mon.isEgg then
        local hp, mhp = tonumber(mon.hp) or 0, maxHp(mon)
        bar(x + margin + rowH + 72, ry + 31,
          math.max(54, leftW - rowH - 116), 7, hp, mhp)
        local st = shownStatus(nil, mon)
        if st then rightText(st, x + leftW - 16, ry + 7, 11, 1, 0.67, 0.35) end
      end
    end
    local cancelY = listY + 10 + #(state.party or {}) * rowH
    if state.index > #(state.party or {}) then
      G.setColor(0.10, 0.22, 0.33, 0.95)
      G.rectangle("fill", x + margin + 8, cancelY,
        leftW - margin - 16, rowH - 6, 10, 10)
    end
    text("CANCEL", x + margin + 18, cancelY + 14, 14, 0.66, 0.72, 0.79)

    local mon = state.party and state.party[state.index]
    local dx = x + leftW + 14
    local dw = w - leftW - margin - 14
    panel(dx, listY, dw, h - 94, false, 14)
    if mon then
      drawPartyIcon(state, mon, dx + 20, listY + 22, 62)
      text(monName(game, mon), dx + 96, listY + 20, 25)
      text("Lv " .. tostring(mon.level or 1), dx + 98, listY + 53,
        13, 0.55, 0.66, 0.77)
      local tx = dx + 20
      for _, t in ipairs(monTypes(game, mon)) do
        tx = tx + typePill(t, tx, listY + 96, 11) + 7
      end
      if not mon.isEgg then
        local hp, mhp = tonumber(mon.hp) or 0, maxHp(mon)
        text("HP", dx + 20, listY + 143, 12, 0.58, 0.68, 0.78)
        bar(dx + 58, listY + 148, dw - 150, 10, hp, mhp)
        rightText(hp .. "/" .. mhp, dx + dw - 20, listY + 139, 12)

        local stats = mon.stats or {}
        local sy = listY + 188
        local statRows = {
          {"ATK", stats.attack}, {"DEF", stats.defense},
          {"SP.ATK", stats.specialAttack or stats.special},
          {"SP.DEF", stats.specialDefense or stats.special},
          {"SPEED", stats.speed},
        }
        for i, row in ipairs(statRows) do
          local col = (i - 1) % 2
          local rr = math.floor((i - 1) / 2)
          local sx = dx + 20 + col * (dw * 0.45)
          local yy = sy + rr * 28
          text(row[1], sx, yy, 11, 0.52, 0.62, 0.72)
          rightText(tostring(row[2] or "—"), sx + dw * 0.34, yy, 12)
        end

        local enemy = battleScreen and battleScreen.battle and battleScreen.battle.enemy
        local best = bestMoveFor(game, battleScreen, mon, enemy)
        local my = sy + 94
        text("MOVES", dx + 20, my, 12, 0.47, 0.78, 0.96)
        for i, move in ipairs(mon.moves or {}) do
          local info = moveInfo(game, battleScreen, move, enemy)
          local yy = my + 26 + (i - 1) * 30
          if i == best then
            G.setColor(0.12, 0.35, 0.24, 0.88)
            G.rectangle("fill", dx + 14, yy - 4, dw - 28, 26, 8, 8)
          end
          text(info.name, dx + 22, yy, 12)
          local eff, ec = effectiveness(info.mult)
          rightText(i == best and ("BEST OPTION  " .. eff) or eff,
            dx + dw - 20, yy, 10, ec[1], ec[2], ec[3])
        end
      end
    end

    if state.submenu and type(state.submenu.items) == "table" then
      local items = state.submenu.items
      local sw = math.min(230, w * 0.28)
      local sh = #items * 36 + 24
      local sx = x + w - sw - 28
      local sy = y + h - sh - 22
      panel(sx, sy, sw, sh, false, 12)
      for i, item in ipairs(items) do
        if i == state.submenu.index then
          G.setColor(0.10, 0.28, 0.42, 0.95)
          G.rectangle("fill", sx + 8, sy + 8 + (i - 1) * 36,
            sw - 16, 31, 8, 8)
        end
        text(item.label or item.id or "?", sx + 18,
          sy + 14 + (i - 1) * 36, 13)
      end
    end
    G.pop()
    return true
  end

  local function itemImage(game, itemId, def)
    if not Assets or not def then return nil end
    local path = def.icon or def.image or def.sprite or def.menuIcon
    if type(path) ~= "string" or path == "" then return nil end
    if imageCache[path] == nil then
      local ok, img = pcall(Assets.image, path)
      imageCache[path] = ok and img or false
    end
    return imageCache[path] or nil
  end

  local function drawItemIcon(game, id, def, x, y, size)
    local img = itemImage(game, id, def)
    if img then
      local iw, ih = img:getDimensions()
      local s = math.min(size / iw, size / ih)
      love.graphics.setColor(1,1,1,1)
      love.graphics.draw(img, x + (size - iw*s)/2, y + (size - ih*s)/2, 0, s, s)
      return
    end
    love.graphics.setColor(0.11, 0.25, 0.36, 1)
    love.graphics.circle("fill", x + size/2, y + size/2, size * 0.42)
    text((safeText(def and def.name or id or "?"):sub(1,1)):upper(),
      x + size*0.34, y + size*0.20, size*0.42)
  end

  local PACK_LABELS = {
    use="USE", give="GIVE", toss="TOSS", sel="SELECT", quit="QUIT",
    assign_shortcut="ASSIGN SHORTCUT", shortcut="ASSIGN SHORTCUT",
  }

  local function drawPack(game, viewport, state)
    local G = love.graphics
    local x, y, w, h = viewportRect(viewport)
    local margin = 16
    G.push("all")
    G.setColor(0.025, 0.035, 0.052, 0.985)
    G.rectangle("fill", x, y, w, h)
    local pocket = type(state.pocket) == "function" and state:pocket() or nil
    local pocketLabel = safeText(pocket and (pocket.label or pocket.id) or "PACK")
    text("BATTLE BAG", x + margin, y + 14, 24)
    text(pocketLabel, x + margin, y + 48, 13, 0.49, 0.72, 0.91)

    local leftW = math.min(w * 0.42, 430)
    local listY = y + 78
    panel(x + margin, listY, leftW - margin, h - 94, false, 14)
    local rowH = math.max(48, math.min(66, (h - 110) / 7))
    local rows = state.rows or {}
    local first = math.max(1, (state.scroll or 0) + 1)
    local visible = math.max(1, math.floor((h - 116) / rowH))
    for visual = 1, visible do
      local i = first + visual - 1
      local entry = rows[i]
      local ry = listY + 10 + (visual - 1) * rowH
      if entry then
        if i == state.index then
          G.setColor(0.10, 0.22, 0.33, 0.95)
          G.rectangle("fill", x + margin + 8, ry,
            leftW - margin - 16, rowH - 6, 10, 10)
        end
        text(fitText((entry.tmhmLabel and entry.teaches) or entry.name or entry.id,
          leftW - 130, 14), x + margin + 18, ry + 9, 14)
        if entry.tmhmLabel then
          text(entry.tmhmLabel, x + margin + 18, ry + 29, 10, 0.48, 0.66, 0.80)
        end
        if entry.count and entry.showCount ~= false then
          rightText("×" .. tostring(entry.count), x + leftW - 18,
            ry + 14, 12, 0.65, 0.73, 0.81)
        end
      elseif i == #rows + 1 then
        if state.index > #rows then
          G.setColor(0.10, 0.22, 0.33, 0.95)
          G.rectangle("fill", x + margin + 8, ry,
            leftW - margin - 16, rowH - 6, 10, 10)
        end
        text("CANCEL", x + margin + 18, ry + 13, 14, 0.66, 0.72, 0.79)
      end
    end

    local dx = x + leftW + 14
    local dw = w - leftW - margin - 14
    panel(dx, listY, dw, h - 94, false, 14)
    local entry = rows[state.index]
    if entry then
      local def = game and game.data and game.data.items and game.data.items[entry.id]
      drawItemIcon(game, entry.id, def, dx + 24, listY + 24, 72)
      text(fitText(entry.name or (def and def.name) or entry.id, dw - 130, 25),
        dx + 116, listY + 25, 25)
      text("CATEGORY", dx + 118, listY + 62, 10, 0.48, 0.60, 0.71)
      text(pocketLabel, dx + 190, listY + 60, 12, 0.73, 0.82, 0.90)
      if entry.count then
        rightText("×" .. tostring(entry.count), dx + dw - 24,
          listY + 29, 17, 0.52, 0.82, 0.98)
      end

      local desc = safeText(def and def.description or "")
      text("DESCRIPTION", dx + 24, listY + 128, 11, 0.48, 0.77, 0.96)
      if desc == "" then desc = "No description available." end
      local words, line, lines = {}, "", {}
      for word in desc:gmatch("%S+") do words[#words+1]=word end
      local f = font(13)
      local maxW = dw - 48
      for _, word in ipairs(words) do
        local candidate = line == "" and word or (line .. " " .. word)
        if f and f:getWidth(candidate) > maxW and line ~= "" then
          lines[#lines+1] = line; line = word
        else line = candidate end
      end
      if line ~= "" then lines[#lines+1] = line end
      for i=1, math.min(6,#lines) do
        text(lines[i], dx + 24, listY + 154 + (i-1)*22, 13, 0.77,0.82,0.88)
      end

      if def and def.teaches then
        local _, mdef = moveDef(game, def.teaches)
        if mdef then
          text("TEACHES", dx + 24, listY + 302, 11, 0.48, 0.77, 0.96)
          text(safeText(mdef.name or def.teaches), dx + 24, listY + 327, 16)
          local tx = dx + 160
          typePill(mdef.type, tx, listY + 325, 10)
          text(moveCategory(game, mdef), dx + 24, listY + 360,
            11, 0.60,0.69,0.78)
        end
      end
    end

    if state.submenu and type(state.submenu.rows) == "table" then
      local menu = state.submenu
      local sw = math.min(260, w * 0.30)
      local sh = #menu.rows * 36 + 24
      local sx = x + w - sw - 28
      local sy = y + h - sh - 22
      panel(sx, sy, sw, sh, false, 12)
      for i, id in ipairs(menu.rows) do
        if i == menu.index then
          G.setColor(0.10, 0.28, 0.42, 0.95)
          G.rectangle("fill", sx + 8, sy + 8 + (i-1)*36,
            sw - 16, 31, 8, 8)
        end
        local label = PACK_LABELS[id] or safeText(id):upper():gsub("_", " ")
        text(label, sx + 18, sy + 14 + (i-1)*36, 13)
      end
    end
    if state.message then
      panel(x + w*0.20, y + h - 102, w*0.60, 76, false, 12)
      local page = type(state.pagesFor) == "function"
        and state:pagesFor(state.message)[state.messagePage or 1] or nil
      local line = type(page)=="table" and table.concat(page," ") or safeText(state.message)
      text(fitText(line, w*0.54, 14), x + w*0.23, y + h - 78, 14)
    end
    G.pop()
    return true
  end

  local function drawBattleChild(game, viewport)
    if option("battle_children", true) == false then return false end
    local top = topState(game)
    local battle = battleBelow(game, top)
    if not battle then return false end
    if isBattleParty(top) then return drawParty(game, viewport, top, battle) end
    if isBattlePack(top) then return drawPack(game, viewport, top) end
    return false
  end

  local function safeWrap(name, handler, priority)
    if not (mod.hooks and type(mod.hooks.wrap) == "function") then return false end
    local ok, err = pcall(mod.hooks.wrap, mod.hooks, name, handler, priority or 990)
    if not ok and mod.log and type(mod.log.warn) == "function" then
      mod.log:warn("%s: hook %s unavailable: %s", MOD_ID, name, tostring(err))
    end
    return ok
  end

  -- Turn the source 2x2 command grid into the horizontal order rendered here.
  -- A still calls BattleState:chooseMenu; only directional presses are consumed.
  safeWrap("input.step", function(next, game, dt)
    if option("enabled", true) ~= false then
      local state = battleState(game)
      if state and directBattle(game, state) and state.phase == "menu" then
        local input = game and game.input
        local queue = input and input.pressQueue
        if type(queue) == "table" then
          local slot = sourceSlotForMenuIndex(clamp(state.menuIndex or 1, 1, 4))
          local changed = false
          for i = #queue, 1, -1 do
            local key = queue[i]
            local delta
            if key == "left" or key == "up" then delta = -1
            elseif key == "right" or key == "down" then delta = 1 end
            if delta then
              table.remove(queue, i)
              slot = ((slot - 1 + delta) % 4) + 1
              changed = true
            end
          end
          if changed then state.menuIndex = COMMAND_ORDER[slot] end
        end
      end
    end
    return next(game, dt)
  end, 995)

  safeWrap("battle.move_grid_navigation", function(next, state)
    local upstream = next(state)
    if option("enabled", true) ~= false and state and state.phase == "moves" then
      return true
    end
    return upstream
  end, 990)

  safeWrap("battle.status_hud_visible", function(next, state)
    local upstream = next(state)
    if option("enabled", true) ~= false and option("hide_native", true) ~= false
        and state and state.battle then return false end
    return upstream
  end, 990)

  safeWrap("battle.bottom_ui_visible", function(next, state)
    local upstream = next(state)
    if option("enabled", true) ~= false and option("hide_native", true) ~= false
        and modernMessageOwned(state) then
      return false
    end
    return upstream
  end, 990)

  -- Party and Pack are source-owned screens. Hide only their draw pass while
  -- this mod is actually able to render a battle child; update/input stays native.
  safeWrap("screen.render_visible", function(next, state)
    if option("enabled", true) ~= false and option("hide_native", true) ~= false
        and option("battle_children", true) ~= false and state and state.game
        and (isBattleParty(state) or isBattlePack(state))
        and battleBelow(state.game, state) then
      return false
    end
    return next(state)
  end, 995)

  safeWrap("render.hud", function(next, game, viewport)
    next(game, viewport)
    if option("enabled", true) == false or not (love and love.graphics) then return end
    local ok, err = xpcall(function()
      if drawBattleChild(game, viewport) then return end
      local state = battleState(game)
      if state and directBattle(game, state) then drawBattle(game, viewport, state) end
    end, function(e)
      if debug and type(debug.traceback) == "function" then
        return debug.traceback(e, 2)
      end
      return tostring(e)
    end)
    if not ok and mod.log and type(mod.log.warn) == "function" then
      mod.log:warn("MODERN BATTLE UI GEN 2 draw failed: %s", tostring(err))
    end
  end, 990)

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.modernBattleUiGen2 = {
    version = VERSION,
    id = MOD_ID,
    nativeBattleAuthority = true,
    horizontalCommands = true,
    moveEffectiveness = true,
    partyOverlay = true,
    bagOverlay = true,
    modernBattleDialogue = true,
    modernYesNoPrompts = true,
    modernLevelUpStats = true,
    modernMoveLearning = true,
    gen2PhysicalSpecial = true,
  }
end
