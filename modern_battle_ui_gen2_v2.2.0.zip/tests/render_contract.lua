local root = assert(os.getenv('MODROOT'))
package.path = root .. '/?.lua;' .. package.path

local printed = {}
local font = {}
function font:getWidth(s) return #tostring(s or '') * 7 end
function font:getHeight() return 14 end

_G.love = {
  graphics = {
    getDimensions = function() return 1280, 720 end,
    newFont = function() return font end,
    getFont = function() return font end,
    setFont = function() end,
    setColor = function() end,
    rectangle = function() end,
    setLineWidth = function() end,
    print = function(value) printed[#printed+1] = tostring(value) end,
    push = function() end,
    pop = function() end,
    circle = function() end,
    draw = function() end,
    newQuad = function() return {} end,
  }
}

local hooks = {}
local mod = {
  hooks = { wrap = function(_, name, fn) hooks[name] = fn end },
  options = { define=function() end, get=function(_, key) return nil end },
  log = { warn = function(_, ...) error(string.format(...)) end },
}
assert(loadfile(root .. '/main.lua'))()(mod)

local data = {
  pokemon = {
    TYPHLOSION={name='TYPHLOSION',types={'FIRE'}},
    FERALIGATR={name='FERALIGATR',types={'WATER'}},
    AMPHAROS={name='AMPHAROS',types={'ELECTRIC'}},
    CHIKORITA={name='CHIKORITA',types={'GRASS'}},
  },
  moves = {
    FLAMETHROWER={name='FLAMETHROWER',type='FIRE',power=95,accuracy=100,description='A strong fire attack.'},
    THUNDERPUNCH={name='THUNDERPUNCH',type='ELECTRIC',power=75,accuracy=100,description='An electrified punch.'},
    SMOKESCREEN={name='SMOKESCREEN',type='NORMAL',power=0,accuracy=100,description='Lowers accuracy.'},
    CUT={name='CUT',type='NORMAL',power=50,accuracy=95,description='Cuts the target.'},
    RAZOR_LEAF={name='RAZOR LEAF',type='GRASS',power=55,accuracy=95,description='A sharp leaf attack.'},
  },
  items = {
    POTION={name='POTION',description='Restores HP.',pocket='ITEM'},
  },
  type_chart = {
    types={'NORMAL','FIRE','WATER','ELECTRIC'},
    matchups={
      {attacker='FIRE',defender='WATER',multiplier=5},
      {attacker='ELECTRIC',defender='WATER',multiplier=20},
    },
  },
}
local player={species='TYPHLOSION',level=36,hp=101,maxHp=120,status=nil,stats={attack=84,defense=78,specialAttack=109,specialDefense=85,speed=100},moves={
  {id='FLAMETHROWER',pp=15,maxPp=15},{id='THUNDERPUNCH',pp=15,maxPp=15},
  {id='SMOKESCREEN',pp=20,maxPp=20},{id='CUT',pp=30,maxPp=30},
}}
local enemy={species='FERALIGATR',level=35,hp=105,maxHp=110,stats={}}
local model={player=player,enemy=enemy,party={player,{species='AMPHAROS',level=34,hp=90,maxHp=100,stats={attack=60,defense=70,specialAttack=100,specialDefense=80,speed=55},moves={{id='THUNDERPUNCH',pp=15}}}}}
local battle={screenId='Gen2BattleState',phase='menu',menuIndex=1,moveIndex=1,queue={},battle=model}
local stack={states={battle}}
function stack:top() return self.states[#self.states] end
local game={stack=stack,data=data,save={pokedex={caught={FERALIGATR=true}}}}
local viewport={width=1280,height=720,gameX=240,gameY=0,gameWidth=800,gameHeight=720}

hooks['render.hud'](function() end, game, viewport)
battle.phase='moves'
hooks['render.hud'](function() end, game, viewport)

battle.phase='resolving'
battle.message='TYPHLOSION used FLAMETHROWER!'
battle.messageTimer=48
hooks['render.hud'](function() end, game, viewport)

battle.phase='ask-shift'
battle.message='Will GOLD change POKéMON?'
battle.messageTimer=0
battle.shiftIndex=1
hooks['render.hud'](function() end, game, viewport)
local joined=table.concat(printed, '\n')
assert(joined:find('Will GOLD change POKéMON?', 1, true), 'modern shift prompt text was not rendered')
assert(joined:find('YES', 1, true) and joined:find('NO', 1, true), 'modern YES/NO choices were not rendered')


-- Level-up stat window is owned by the modern presenter.
stack.states={battle}
battle.phase='stats-box'
battle.message=nil
battle.messageTimer=0
battle.statsBoxMon={species='TYPHLOSION',level=37,hp=104,maxHp=124,stats={attack=86,defense=80,specialAttack=112,specialDefense=88,speed=103}}
hooks['render.hud'](function() end, game, viewport)

-- Four-move learn/forget selection is also modern; native input fields remain authoritative.
battle.phase='choose-forget'
battle.statsBoxMon=nil
battle.message='Which move should be forgotten?'
battle.messageTimer=0
battle.forgetIndex=2
battle.pendingLearn={index=1,move='RAZOR_LEAF',moveName='RAZOR LEAF'}
model.party[1].moves={
  {id='FLAMETHROWER',pp=15,maxPp=15},{id='THUNDERPUNCH',pp=14,maxPp=15},
  {id='SMOKESCREEN',pp=20,maxPp=20},{id='CUT',pp=30,maxPp=30},
}
hooks['render.hud'](function() end, game, viewport)

local party={screenId='Gen2PartyMenu',game=game,battle=true,party=model.party,index=1,prompt='Choose a POKéMON.'}
function party:iconFor() return nil end
stack.states={battle,party}
hooks['render.hud'](function() end, game, viewport)

local pack={screenId='Gen2PackMenu',game=game,battle=true,rows={{id='POTION',name='POTION',count=3,showCount=true}},index=1,scroll=0}
function pack:pocket() return {id='ITEM',label='ITEMS'} end
function pack:useSelected() end
stack.states={battle,pack}
hooks['render.hud'](function() end, game, viewport)

local finalJoined=table.concat(printed, '\n')
assert(finalJoined:find('LEVEL UP', 1, true), 'modern level-up stats panel was not rendered')
assert(finalJoined:find('ATTACK', 1, true) and finalJoined:find('SP. ATK', 1, true), 'modern Gen2 stat labels were not rendered')
assert(finalJoined:find('LEARN MOVE', 1, true), 'modern move-learning panel was not rendered')
assert(finalJoined:find('RAZOR LEAF', 1, true), 'new move name was not rendered')
assert(finalJoined:find('FORGET', 1, true), 'modern forget selection affordance was not rendered')
print('render-contract-ok')
