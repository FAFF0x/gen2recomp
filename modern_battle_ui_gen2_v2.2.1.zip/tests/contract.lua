local root = assert(os.getenv('MODROOT'))
local hooks = {}
local options = {}
local mod = {
  hooks = {
    wrap = function(_, name, fn, priority)
      hooks[name] = { fn = fn, priority = priority }
    end,
  },
  options = {
    define = function() end,
    get = function(_, key) return options[key] end,
  },
  log = { warn = function() end },
}

local entry = assert(loadfile(root .. '/main.lua'))()
assert(type(entry) == 'function')
entry(mod)

assert(hooks['input.step'], 'input.step hook missing')
assert(hooks['battle.move_grid_navigation'], 'move grid hook missing')
assert(hooks['battle.status_hud_visible'], 'status visibility hook missing')
assert(hooks['battle.bottom_ui_visible'], 'bottom visibility hook missing')
assert(hooks['screen.render_visible'], 'screen visibility hook missing')
assert(hooks['render.hud'], 'render hook missing')

local battle = {
  screenId = 'Gen2BattleState', phase = 'menu', menuIndex = 1,
  queue = {}, battle = { player = { moves = {} }, enemy = {} },
}
local stack = { states = { battle } }
function stack:top() return self.states[#self.states] end
local game = { stack = stack, input = { pressQueue = { 'right' } } }

hooks['input.step'].fn(function(g, dt) return 'next-ok' end, game, 0)
assert(battle.menuIndex == 3, 'right from FIGHT must select BAG')
assert(#game.input.pressQueue == 0, 'horizontal direction must be consumed')

game.input.pressQueue = { 'right' }
hooks['input.step'].fn(function() end, game, 0)
assert(battle.menuIndex == 2, 'right from BAG must select POKEMON')

game.input.pressQueue = { 'left' }
hooks['input.step'].fn(function() end, game, 0)
assert(battle.menuIndex == 3, 'left from POKEMON must select BAG')

local grid = hooks['battle.move_grid_navigation'].fn(function() return false end,
  { phase = 'moves' })
assert(grid == true, 'Gen2 FIGHT must use modern 2x2 navigation')

local hidden = hooks['battle.status_hud_visible'].fn(function() return true end,
  battle)
assert(hidden == false, 'source status HUD must hide while modern HUD is active')

local bottom = hooks['battle.bottom_ui_visible'].fn(function() return true end,
  battle)
assert(bottom == false, 'source command UI must hide in menu phase')
battle.phase = 'resolving'
bottom = hooks['battle.bottom_ui_visible'].fn(function() return true end, battle)
assert(bottom == true, 'empty resolving phase should leave source bottom UI available')

battle.message = 'TYPHLOSION used FLAMETHROWER!'
bottom = hooks['battle.bottom_ui_visible'].fn(function() return true end, battle)
assert(bottom == false, 'source battle message UI must hide when modern dialogue owns it')

battle.phase = 'ask-shift'
battle.message = 'Will GOLD change POKéMON?'
battle.messageTimer = 0
battle.shiftIndex = 1
bottom = hooks['battle.bottom_ui_visible'].fn(function() return true end, battle)
assert(bottom == false, 'source shift YES/NO prompt must hide for modern prompt')

battle.phase = 'stats-box'
battle.statsBoxMon = { species='CHIKORITA', level=17, stats={ attack=30 } }
battle.message = nil
battle.messageTimer = 0
bottom = hooks['battle.bottom_ui_visible'].fn(function() return true end, battle)
assert(bottom == false, 'source Gen2 level-up stats box must hide for modern stats panel')

battle.phase = 'choose-forget'
battle.pendingLearn = { index=1, move='RAZOR_LEAF', moveName='RAZOR LEAF' }
battle.battle.party = {{species='CHIKORITA', moves={{id='TACKLE'}}}}
battle.message = 'Which move should be forgotten?'
battle.messageTimer = 0
bottom = hooks['battle.bottom_ui_visible'].fn(function() return true end, battle)
assert(bottom == false, 'source forget-move list must hide for modern move-learning panel')
battle.messageTimer = 48
bottom = hooks['battle.bottom_ui_visible'].fn(function() return true end, battle)
assert(bottom == false, 'transient forget-move refusal message should be modern')

battle.phase = 'submenu'
local party = { screenId='Gen2PartyMenu', game=game, battle=true,
  party={{species='CHIKORITA', hp=20}}, index=1 }
stack.states = { battle, party }
local vis = hooks['screen.render_visible'].fn(function() return true end, party)
assert(vis == false, 'battle Party source draw must hide for modern child presenter')

local pack = { screenId='Gen2PackMenu', game=game, battle=true,
  rows={{id='POTION',name='POTION',count=1}}, index=1,
  pocket=function() return {id='ITEM',label='ITEMS'} end,
  useSelected=function() end }
stack.states = { battle, pack }
vis = hooks['screen.render_visible'].fn(function() return true end, pack)
assert(vis == false, 'battle Pack source draw must hide for modern child presenter')

assert(mod.exports and mod.exports.modernBattleUiGen2)
assert(mod.exports.modernBattleUiGen2.nativeBattleAuthority == true)
assert(mod.exports.modernBattleUiGen2.version == '2.2.1')
assert(mod.exports.modernBattleUiGen2.moveLearningComparison == true)
print('contract-ok')
