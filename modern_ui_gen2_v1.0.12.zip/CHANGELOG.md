# Changelog

## 1.0.12

- Fixed Advanced Box System Gen 2 WITHDRAW / DEPOSIT / SWAP browsers falling back to the vanilla renderer.
- The `gen2_box` readiness gate now accepts Advanced Box's public `getPokemonList()` semantic API instead of requiring the native `Gen2BoxMenu:list()` method.
- Added compatibility fallback for Advanced Box builds that expose Pokémon rows through `state.items`.
- Advanced Box's `absAdvancedBox` marker is now recognized in addition to `absAdvancedBoxGen2`, `semanticKind = "gen2_box"`, and `AdvancedBoxBrowserGen2`.
- Rich Pokémon row icons, selected-Pokémon sprite/details preview, and modern box chrome now remain active across WITHDRAW, DEPOSIT, SWAP BOX, SWAP PARTY, and swap-target modes.
- Source-owned storage actions, MAIL restrictions, L/R box switching, STATS and confirmations remain unchanged.

## 1.0.11

- Added first-class routing for `AdvancedBoxBrowserGen2` from Advanced Box System Gen 2.
- Advanced Box is no longer treated as a generic `ListMenu`; it now uses the rich Gen 2 box presenter.
- Added compatibility with Advanced Box v1.0.1 `getPokemonList()` / `getSelectedPokemon()` semantics and a fallback for v1.0.0 `item.mon` rows.
- Advanced Box rows now render Pokémon icons, and the selected Pokémon gets the same front-sprite/details preview used by native `Gen2BoxMenu`.
- Preview includes nickname/species, level, types, HP/status, ATK, DEF, SPEED, SP.ATK, SP.DEF, and moves/PP.
- Advanced Box's own WITHDRAW/DEPOSIT/RELEASE/SWAP actions, L/R box switching, MAIL guards and modal action menus remain source-owned.
- Native Bill's PC rich box presenter, Pokégear bypass, Pokédex Plus integration, and Modern Battle UI defer behavior are preserved.


## 1.0.10

- Added a dedicated rich presenter for the native Gen 2 `Gen2BoxMenu` used by Bill's PC / the Pokémon Center PC.
- Box and party rows inside Bill's PC now request large Pokémon icons explicitly instead of relying on the generic Chrome list renderer.
- Added a live selected-Pokémon preview card with front sprite, a second small Pokémon icon, nickname/species, level, types, HP/status, ATK, DEF, SPEED, SP.ATK, SP.DEF, and moves/PP.
- The rich box presenter supports WITHDRAW, DEPOSIT, MOVE and INSERT browsing without replacing the source `BoxMenu` update/action logic.
- MOVE / STATS / RELEASE / CANCEL remains source-owned and is rendered as a modern modal over the box browser.
- Empty slot, CANCEL, box switching, messages and other native Bill's PC states remain compatible.
- Preserved the complete Pokégear bypass and Modern Battle UI Gen 2 defer behavior introduced in earlier releases.

## 1.0.9

- Improved Pokédex Plus integration for the corrected v1.0.3 START/GO search flow.
- Increased Pokédex row height and Pokémon icon target size so species icons are clearly visible instead of collapsing into ordinary ListMenu rows.
- The selected-Pokémon preview now resolves species from public `species` metadata first, with `value` as a compatibility fallback.
- Added a dedicated icon inside the selected-Pokémon preview alongside the front sprite.
- Expanded the preview card with Pokédex number, types, SEEN/OWNED state, all six Gen 2 base stats (HP/ATK/DEF/SP.ATK/SP.DEF/SPEED), and BST.
- Preserved the v1.0.8 complete Pokégear bypass and Modern Battle UI Gen 2 authority/defer behavior.

## 1.0.8

- Disabled Modern UI presentation for the entire Pokégear stack. `Gen2Pokegear` and any nested dialogue/choice states remain 100% source-rendered to avoid renderer/state conflicts and crashes.
- Added first-class Pokédex Plus - Gen 2 list routing to the dedicated Modern UI Pokédex presenter, including authored Pokémon row icons and a large selected-species preview card.
- Added seen/unknown guarding so a hidden Pokédex Plus entry cannot leak its sprite through the Modern UI preview.
- Added coexistence detection for `modern_battle_ui_gen2`: when that mod publishes native battle authority, Gen2 Modern UI does not claim the BattleState or its child screens.
- Preserved source ownership for all third-party callbacks and retained fail-open behavior for unknown/custom screens.

## 1.0.7

- Fixed `Gen2PackMenu` contextual item actions being functional but invisible under Modern UI. The live `state.submenu.rows` / `state.submenu.index` model is now rendered as a modern modal with USE / GIVE / TOSS / SEL / QUIT and any third-party actions.
- Added dynamic Pack submenu-label handling so extensions such as **ASSIGN SHORTCUT** from Item Shortcut Gen 2 appear automatically without hardcoding their row into Modern UI.
- Added Modern UI presentation for the Pack's embedded TOSS quantity selector, yes/no confirmations and Pack-owned messages.
- Added a visible MOVE ITEM state and corrected Pack footer hints for action, quantity, confirmation, message and move modes.
- Added pointer-mode isolation for Pack overlays so clicks/taps cannot activate an item row underneath an open contextual menu or confirmation.
- Preserved the native `Gen2PackMenu` update/action methods; Modern UI only replaces presentation, so item effects, TM/HM teaching and other mods keep ownership of behavior.

## 1.0.6

- Fixed the Gen 2 PARTY submenu renderer to use the live `state.submenu.items` / `state.submenu.index` model. Hook-injected actions such as **DV/EV** and **INSTANT HATCH** are now visible, selectable, and pointer-safe.
- Added a semantic future-proofing route for new `Gen2*` interactive screens that expose rows/items/entries/choices/options, submenus, messages, or confirmations; source-art/cinematic screens remain explicitly excluded from the generic catch-all.
- Added full Modern UI presentation for Gen 2 Pokédex ENTRY, AREA, OPTION, SEARCH and UNOWN views instead of falling back to the source renderer outside the list.
- Added semantic presenters for Bank of Mom, Battle Tower, Buena, Bug Contest prompts, Day Care, Decoration, Elevator, Gender Select, Held Item, Init Clock, Mail/Mailbox, Map Radio, Move Deleter/Tutor, Name Pick, Photo Studio, Pokégear, Trade and Unown Printer.
- Added Modern UI rendering for Gen 2 Mail Compose using the live mail keyboard rows and text buffer.
- Pokégear phone/radio/clock are presented as Modern UI; the real town/fly map remains the content layer inside a Modern UI map card so cursor/cartography functionality is preserved.
- Added source-art bridge coverage for Gen 2 cinematics, minigames, puzzles and ceremonial screens. Their animation/game board remains source-owned while Modern UI can keep prompts/hints in the same presentation stack.
- Removed the old whole-stack New Game bypass. Oak artwork/animation remains source-owned while its TextBox, clock, gender, name-pick and naming children can now use Modern UI.
- Battle UI is now enabled by default under the new `battleUi` option; the existing safety fallback and 3D-battle bypass remain enabled.
- Expanded Gen 2 text-macro normalization at the Modern UI boundary without mutating source strings.
- Preserved all v1.0.1-v1.0.5 black-frame, Options, Save/Trainer Card, PC/Mart and Summary fixes.

## 1.0.5

- Normalized Gen 2 font macros in Modern UI text (`<PK><MN>` -> `POKéMON`, plus common level/ID markers).
- Added Modern UI presenters for the custom `all_tm_shop_gen2` chooser/catalogue and its SELECT move-info view.
- Extended `Gen2SummaryMenu` suppression/presentation to all three native Gen 2 pages instead of page 1 only.
- Added a dedicated modern Gen 2 Summary renderer for STATUS, MOVES, TRAINER / STATS, eggs, and MoveScreen/SELECT details.
- Preserved native Gen 2 Summary input semantics for page turning, party cycling, move swapping, and exit behavior.

## 1.0.4

- Added Modern UI presenters for Gen2 Main Menu, Pokémon Center PC, Bill's PC, Item PC, Pokémon Box, PokéMart and ScriptMenu.
- Pokémon storage now stays modern through box selection, withdraw/deposit/move/release submenus and embedded prompts.
- PokéMart now stays modern through BUY, SELL, quantity selection, confirmations, clerk dialogue and transaction/refusal messages.
- Added embedded Gen 2 Typer rendering so Chrome-owned text is presented by the same modern dialogue cards as ordinary TextBox states.
- Added nested Pack cursor routing for Mart SELL and Item PC DEPOSIT.
- Boxed Gen 2 Pokémon now derive display-only stats with `src.battle.gen2.Mon.stats` when their box record has no calculated stat block.
- Preserved v1.0.1 combined-scene black-frame protection, v1.0.2 Options synchronization and v1.0.3 Save/Trainer Card fixes.

## 1.0.3

- Added a dedicated Modern UI presenter for `Gen2SaveMenu`; save/overwrite/write timing remains owned by the native Gen 2 state.
- Fixed Trainer Card crash caused by treating Gen 2 `save.playTime` (a table) as a numeric seconds counter.
- Fixed Johto badge mapping to use Gen 2 `save.player.badges`; retained `save.player.kantoBadges` for Kanto.
- Added class/generation detection for Gen 2 Trainer Card instances without a stamped `screenId`.
- Preserved the v1.0.1 black-frame fix and v1.0.2 Options synchronization fix.

## 1.0.2

- Fixed Gen 2 Options navigation: Modern UI now renders `OptionsMenu:visible()` instead of the flat source `rows` table, keeping the highlighted row synchronized with native input.
- Fixed SPEED group / GAME SPEED subpage activation.
- Added Gen 2 option value rendering for `text(options)`, `values`/`display`, and FRAME descriptors.
- Preserved the v1.0.1 combined-scene black-frame fix unchanged.

## 1.0.1

- Fixed intermittent black frames on Gen 2. `Game2:compose` exposes `worldCanvas`, `uiCanvas`, and `sceneCanvas` as the same combined scene texture, so the Gen 1 canvas-clear suppression path was unsafe.
- Gen 2 compose now preserves the combined scene and relies on `screen.render_visible` / narrow screen decorators for native UI suppression.
- Added fail-open behavior: an unsupported or transient frame may remain native, but the mod no longer erases the whole scene.

## 1.0.0

- Initial Gen 2 release, based on Gen1 Modern UI Enhanced 0.10.0.
- New `gen2_modern_ui` identity and Gen 2-only manifest target.
- Added direct `Gen2*` screen-class detection for Gold/Silver/Crystal.
- Added adapters for Start Menu, PACK, Pokédex, Options, Party, Summary and Trainer Card.
- Added Gen 2 PARTY submenu and four-pocket PACK presentation support.
- Added Gen 2 Pokédex seen/caught row conversion.
- Added live Game2 world/data aliases required by the Gen1-based renderer.
- Added Gen 2 icon-catalog mapping and Trainer Card money/Johto/Kanto badge handling.
- Added a safe native fallback for Gen 2 Summary pages whose semantics differ from Gen 1.
- Preserved native rendering for specialised Gen 2 pages when suppression would be unsafe.
- Renamed public Modern UI compatibility namespace to `gen2ModernUi`.
