# Changelog

## 1.0.0

- Created a Gen 2-only Pokemon MOD build.
- Changed manifest ID to `pokemonmod_gen2_move_learn_stats`.
- Kept `games: ["gen2"]`.
- Removed hard conflicts from the manifest.
- Added optional ordering against older Move Learn Stats variants.
- Added runtime defer protection so only one equivalent implementation owns the Gen 2 wrappers.
- Updated the Modern UI adapter owner/screen namespace to the new mod ID.
- Preserved all original Gen 2 move-learning behavior.
