-- Move Learn Stats - Gen 2 (Pokemon MOD) v1.0.0
--
-- Adds a SELECTED vs LEARNING comparison to Gen 2's learn-four-moves flow.
-- The source engine remains authoritative for input, HM protection, replacing
-- the move, PP, messages, level-up sequencing and TM/HM consumption.

local Font = require("src.render.Font")
local Chrome = require("src.ui.gen2.Chrome")
local Game2 = require("src.core.Game2")
local MoveDeleter = require("src.ui.gen2.MoveDeleter")

local MOD_ID = "pokemonmod_gen2_move_learn_stats"
local VERSION = "1.0.0"
local EQUIVALENT_MOD_IDS = { "move_learn_stats_gen2", "move_learn_stats" }

local function shortName(name, limit)
  name = tostring(name or "---")
  limit = limit or 8
  if not (Font and type(Font.split) == "function") then
    return #name <= limit and name or name:sub(1, limit)
  end
  local spans = Font.split(name)
  if #spans <= limit then return name end
  local out = {}
  for i = 1, math.min(limit, #spans) do
    local span = spans[i]
    out[#out + 1] = name:sub(span.from, span.to)
  end
  return table.concat(out)
end

local function maxPpFor(def, entry)
  if type(entry) == "table" and tonumber(entry.maxPp) then
    return math.max(0, math.floor(tonumber(entry.maxPp)))
  end
  local base = tonumber(def and def.pp) or 0
  local ups = type(entry) == "table" and tonumber(entry.ppUps) or 0
  ups = math.max(0, math.min(3, math.floor(ups or 0)))
  -- Gen 2 RestoreBonusPP / PP Up model used by ItemEffects.lua.  The per-use
  -- bonus is floor(base/5), capped at 7, and can be applied three times.
  local bonus = math.min(math.floor(base / 5), 7)
  return base + ups * bonus
end

local function moveStats(data, moveId, entry)
  local def = data and data.moves and moveId and data.moves[moveId]
  if not def then
    return { name = "---", power = "---", pp = "---" }
  end
  local power = tonumber(def.power) or 0
  return {
    name = def.name or moveId,
    power = power > 0 and tostring(math.floor(power)) or "---",
    pp = tostring(maxPpFor(def, entry)),
  }
end

local function learningContext(game, mon)
  local ctx = game and game._moveLearnStatsGen2
  if type(ctx) ~= "table" then return nil end
  if mon ~= nil and ctx.mon ~= mon then return nil end
  if type(ctx.moveId) ~= "string" or ctx.moveId == "" then return nil end
  return ctx
end

local function comparisonForMoveDeleter(state)
  if type(state) ~= "table" or state.forget ~= true then return nil end
  local ctx = learningContext(state.game, state.mon)
  if not ctx then return nil end
  local selected = state.list and state.list[state.row or 1]
  local selectedId = selected and selected.id
  local data = state.game and state.game.data or {}
  return moveStats(data, selectedId, selected), moveStats(data, ctx.moveId), ctx.moveId
end

local function comparisonForBattle(state)
  if type(state) ~= "table" or state.phase ~= "choose-forget"
      or (tonumber(state.messageTimer) or 0) > 0 then return nil end
  local learn = state.pendingLearn
  local battle = state.battle
  local party = battle and battle.party
  local mon = learn and party and party[learn.index]
  if not (learn and mon) then return nil end
  local selected = mon.moves and mon.moves[state.forgetIndex or 1]
  local selectedId = selected and selected.id
  local data = state.game and state.game.data or {}
  return moveStats(data, selectedId, selected), moveStats(data, learn.move), learn.move
end

local function printAt(text, tx, ty)
  if type(Chrome.printThrough) == "function" then
    Chrome.printThrough(tostring(text or ""), tx, ty, Chrome.DEFAULT_BOX_PALETTE)
  else
    Chrome.print(tostring(text or ""), tx, ty)
  end
end

local function drawColumn(x, heading, stats)
  printAt(heading, x, 13)
  printAt(shortName(stats.name, 8), x, 14)
  printAt("PWR " .. tostring(stats.power), x, 15)
  printAt("PP  " .. tostring(stats.pp), x, 16)
end

local function drawComparisonPanel(selected, learning)
  if not (selected and learning) then return end
  Chrome.box(0, 12, 20, 6)
  drawColumn(1, "SELECTED", selected)
  drawColumn(11, "LEARNING", learning)
end

local function modernModel(state)
  local selected, learning = comparisonForMoveDeleter(state)
  if not (selected and learning) then return nil end
  local rows = {}
  local data = state.game and state.game.data or {}
  for _, entry in ipairs(state.list or {}) do
    local stats = moveStats(data, entry.id, entry)
    rows[#rows + 1] = {
      label = stats.name,
      value = "PWR " .. stats.power .. "   PP " .. stats.pp,
      source = entry,
    }
  end
  return {
    title = "FORGET A MOVE",
    rows = rows,
    index = math.max(1, math.min(#rows, tonumber(state.row) or 1)),
    scroll = 0,
    footer = { "A REPLACE", "B CANCEL" },
    details = {
      custom_fields = {
        columns = 2,
        data = {
          { label = "SELECTED", value = selected.name, style = "accent" },
          { label = "LEARNING", value = learning.name, style = "accent" },
          { label = "POWER", value = selected.power },
          { label = "POWER", value = learning.power },
          { label = "MAX PP", value = selected.pp },
          { label = "MAX PP", value = learning.pp },
        },
      },
    },
    layoutOptions = { overflow = "shrink_to_fit", max_content_height = "100%" },
  }
end

local function moveCursor(state, delta)
  local n = #(state and state.list or {})
  if n < 1 then return false end
  local row = math.max(1, math.min(n, math.floor(tonumber(state.row) or 1)))
  row = ((row - 1 + delta) % n) + 1
  state.row = row
  return true
end

local function findBattleState(game)
  local stack = game and game.stack
  if not stack then return nil end
  local top = type(stack.top) == "function" and stack:top() or nil
  if comparisonForBattle(top) then return top end
  local states = stack.states
  if type(states) == "table" then
    for i = #states, 1, -1 do
      if comparisonForBattle(states[i]) then return states[i] end
    end
  end
  return nil
end

return function(mod)
  -- Coexistence guard: this build may be imported alongside older variants,
  -- but only one equivalent Move Learn Stats implementation should own the
  -- Game2 / MoveDeleter / render.hud wrappers at runtime.
  local deferredTo
  if type(mod.find) == "function" then
    for _, id in ipairs(EQUIVALENT_MOD_IDS) do
      local ok, handle = pcall(mod.find, id)
      if ok and type(handle) == "table" then
        deferredTo = id
        break
      end
    end
  end

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.active = deferredTo == nil
  mod.exports.deferredTo = deferredTo
  if deferredTo then
    if mod.log and type(mod.log.info) == "function" then
      mod.log:info("Move Learn Stats deferred to active equivalent mod: %s", tostring(deferredTo))
    end
    return
  end
  -- Preserve the new move id while Game2's asynchronous LearnMove prompt is
  -- alive. Gen2MoveDeleter itself intentionally knows only the old move list,
  -- so this is the smallest bridge needed to show the LEARNING column.
  if not Game2.__moveLearnStatsGen2LearnWrapped then
    local vanillaLearnMoveOn = Game2.learnMoveOn
    Game2.learnMoveOn = function(self, mon, moveId, onDone)
      local previous = self._moveLearnStatsGen2
      local token = {}
      self._moveLearnStatsGen2 = { mon = mon, moveId = moveId, token = token }
      local function finish(...)
        local current = self._moveLearnStatsGen2
        if current and current.token == token then
          self._moveLearnStatsGen2 = previous
        end
        if onDone then return onDone(...) end
      end
      return vanillaLearnMoveOn(self, mon, moveId, finish)
    end
    Game2.__moveLearnStatsGen2LearnWrapped = true
  end

  -- Native Gen2MoveDeleter presentation: keep its list/input untouched and
  -- occupy only the otherwise-unused lower six rows with the comparison.
  if not MoveDeleter.__moveLearnStatsGen2DrawWrapped then
    local vanillaDraw = MoveDeleter.draw
    MoveDeleter.draw = function(self, ...)
      vanillaDraw(self, ...)
      local selected, learning = comparisonForMoveDeleter(self)
      if selected then drawComparisonPanel(selected, learning) end
    end
    MoveDeleter.__moveLearnStatsGen2DrawWrapped = true
  end

  -- Battle level-ups use BattleState's internal choose-forget phase rather
  -- than Gen2MoveDeleter. render.hud is after the game composite; priority 980
  -- deliberately places this after Gen2 Modern UI (1000) and Modern Battle UI
  -- (990), whose wrappers call next() before drawing their layer.
  if mod.hooks and type(mod.hooks.wrap) == "function" then
    mod.hooks:wrap("render.hud", function(next, game, viewport)
      next(game, viewport)
      local state = findBattleState(game)
      local selected, learning = comparisonForBattle(state)
      if not (selected and learning and love and love.graphics) then return end
      local G = love.graphics
      G.push("all")
      local scale = tonumber(viewport and viewport.scale) or 1
      local x = tonumber(viewport and (viewport.gameX or viewport.ox)) or 0
      local y = tonumber(viewport and (viewport.gameY or viewport.oy)) or 0
      G.translate(x, y)
      G.scale(scale, scale)
      drawComparisonPanel(selected, learning)
      G.pop()
    end, 980)
  end

  local gen2ModernUiContract = {
    apiVersion = 2,
    screens = {
      pokemonmod_gen2_move_learn_stats = {
        match = function(state)
          return comparisonForMoveDeleter(state) ~= nil
        end,
        canSuppressNative = true,
        model = function(_, state)
          return modernModel(state)
        end,
        actions = {
          hover = function(_, state, index)
            index = math.floor(tonumber(index) or 0)
            if index < 1 or index > #(state.list or {}) then return false end
            state.row = index
            return true
          end,
          select = function(_, state, index)
            index = math.floor(tonumber(index) or state.row or 0)
            if index < 1 or index > #(state.list or {}) then return false end
            state.row = index
            if type(state.finish) ~= "function" then return false end
            state:finish(index)
            return true
          end,
          up = function(_, state) return moveCursor(state, -1) end,
          down = function(_, state) return moveCursor(state, 1) end,
          back = function(_, state)
            if type(state.finish) ~= "function" then return false end
            state:finish(nil)
            return true
          end,
        },
      },
    },
  }

  local modernUiExports
  local modernUiRegistered = false
  local function ensureModernUiAdapter()
    if type(mod.find) ~= "function" then return false end
    local okFind, handle = pcall(mod.find, "gen2_modern_ui")
    if not okFind or type(handle) ~= "table" or type(handle.exports) ~= "table" then
      modernUiExports, modernUiRegistered = nil, false
      return false
    end
    local ex = handle.exports
    if type(ex.registerAdapter) ~= "function" then return false end
    if modernUiRegistered and modernUiExports == ex then return true end
    local ok, registered, reason = pcall(ex.registerAdapter, {
      owner = MOD_ID, version = VERSION, contract = gen2ModernUiContract,
    })
    modernUiExports = ex
    modernUiRegistered = ok and registered ~= false
    if not modernUiRegistered and mod.log and type(mod.log.warn) == "function" then
      mod.log:warn("Gen2 Modern UI adapter unavailable: %s",
        tostring(ok and reason or registered))
    end
    return modernUiRegistered
  end

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.moveStats = moveStats
  mod.exports.maxPpFor = maxPpFor
  mod.exports.shortName = shortName
  mod.exports.comparisonForMoveDeleter = comparisonForMoveDeleter
  mod.exports.comparisonForBattle = comparisonForBattle
  mod.exports.modernModel = modernModel
  mod.exports.gen2ModernUi = gen2ModernUiContract
  mod.exports.ensureModernUiAdapter = ensureModernUiAdapter

  if mod.events and type(mod.events.on) == "function" then
    mod.events:on("game.ready", ensureModernUiAdapter)
  end
  ensureModernUiAdapter()
end
