local root = os.getenv("MOD_ROOT") or "."

local draws = { boxes = {}, text = {} }
_G.love = { graphics = {
  push = function() end, pop = function() end,
  translate = function() end, scale = function() end,
  setColor = function() end,
} }

package.preload["src.render.Font"] = function()
  return {
    split = function(s)
      local t = {}
      for i = 1, #tostring(s or "") do t[#t + 1] = { from = i, to = i } end
      return t
    end,
  }
end
package.preload["src.ui.gen2.Chrome"] = function()
  return {
    DEFAULT_BOX_PALETTE = {},
    box = function(...) draws.boxes[#draws.boxes + 1] = { ... } end,
    printThrough = function(text, x, y)
      draws.text[#draws.text + 1] = { text = text, x = x, y = y }
    end,
    print = function(text, x, y)
      draws.text[#draws.text + 1] = { text = text, x = x, y = y }
    end,
  }
end

local Game2 = {}
Game2.learnMoveOn = function(self, mon, moveId, done)
  self._testLearnDone = done
  self._testLearnArgs = { mon = mon, moveId = moveId }
  return "started"
end
package.preload["src.core.Game2"] = function() return Game2 end

local MoveDeleter = {}
MoveDeleter.draw = function(self) self._vanillaDrawn = true end
package.preload["src.ui.gen2.MoveDeleter"] = function() return MoveDeleter end

local hookFns = {}
local adapterSpec
local readyCb
local mod = {
  exports = {},
  hooks = {
    wrap = function(_, name, fn, priority)
      hookFns[name] = { fn = fn, priority = priority }
    end,
  },
  events = {
    on = function(_, name, cb) if name == "game.ready" then readyCb = cb end end,
  },
  find = function(id)
    if id ~= "gen2_modern_ui" then return nil end
    return { exports = {
      compatibilityApiVersion = 2,
      registerAdapter = function(spec) adapterSpec = spec; return true end,
    } }
  end,
  log = { warn = function() end },
}

local entry = assert(loadfile(root .. "/main.lua"))
entry()(mod)

assert(mod.exports.version == "1.0.0")
assert(mod.exports.active == true)
assert(mod.exports.deferredTo == nil)
assert(adapterSpec and adapterSpec.owner == "pokemonmod_gen2_move_learn_stats")
assert(adapterSpec.contract == mod.exports.gen2ModernUi)
assert(adapterSpec.contract.apiVersion == 2)
assert(type(readyCb) == "function")

local data = { moves = {
  TACKLE = { name = "TACKLE", power = 40, pp = 35 },
  GROWL = { name = "GROWL", power = 0, pp = 40 },
  BITE = { name = "BITE", power = 60, pp = 25 },
  SURF = { name = "SURF", power = 95, pp = 15 },
} }
local mon = { moves = {
  { id = "TACKLE", pp = 10, maxPp = 42, ppUps = 1 },
  { id = "GROWL", pp = 20, maxPp = 48, ppUps = 1 },
  { id = "SURF", pp = 15, maxPp = 15 },
  { id = "BITE", pp = 25, maxPp = 25 },
} }
local game = setmetatable({ data = data }, { __index = Game2 })
local doneResult
assert(game:learnMoveOn(mon, "BITE", function(v) doneResult = v end) == "started")
assert(game._moveLearnStatsGen2 and game._moveLearnStatsGen2.moveId == "BITE")

local state = {
  game = game, mon = mon, list = mon.moves, row = 1, forget = true,
  finish = function(self, index) self.finished = index or false end,
}
MoveDeleter.draw(state)
assert(state._vanillaDrawn == true)
local sawSelected, sawLearning, saw42, saw25 = false, false, false, false
for _, row in ipairs(draws.text) do
  if row.text == "SELECTED" then sawSelected = true end
  if row.text == "LEARNING" then sawLearning = true end
  if row.text == "PP  42" then saw42 = true end
  if row.text == "PP  25" then saw25 = true end
end
assert(sawSelected and sawLearning and saw42 and saw25,
  "native Gen2MoveDeleter comparison not drawn")

local cmp = adapterSpec.contract.screens.pokemonmod_gen2_move_learn_stats
assert(cmp.match(state) == true)
local model = cmp.model(game, state)
assert(model.title == "FORGET A MOVE")
assert(model.rows[1].label == "TACKLE")
assert(model.rows[1].value == "PWR 40   PP 42")
local fields = model.details.custom_fields.data
assert(fields[1].label == "SELECTED" and fields[1].value == "TACKLE")
assert(fields[2].label == "LEARNING" and fields[2].value == "BITE")
assert(fields[3].value == "40" and fields[4].value == "60")
assert(fields[5].value == "42" and fields[6].value == "25")

assert(cmp.actions.down(game, state) == true and state.row == 2)
assert(cmp.actions.up(game, state) == true and state.row == 1)
assert(cmp.actions.up(game, state) == true and state.row == 4, "forget list wraps")
assert(cmp.actions.hover(game, state, 2) == true and state.row == 2)
assert(cmp.actions.select(game, state, 3) == true and state.finished == 3)
state.finished = nil
assert(cmp.actions.back(game, state) == true and state.finished == false)

-- The wrapper context survives until the source learn-flow completion callback.
assert(game._moveLearnStatsGen2 ~= nil)
game._testLearnDone(true)
assert(doneResult == true)
assert(game._moveLearnStatsGen2 == nil)

-- Battle level-up path has its own pendingLearn and does not depend on Game2 context.
draws.boxes, draws.text = {}, {}
local battleState = {
  game = game,
  phase = "choose-forget", messageTimer = 0, forgetIndex = 2,
  pendingLearn = { index = 1, move = "BITE", moveName = "BITE" },
  battle = { party = { mon } },
}
game.stack = { top = function() return battleState end, states = { battleState } }
assert(hookFns["render.hud"] and hookFns["render.hud"].priority == 980)
hookFns["render.hud"].fn(function() end, game,
  { gameX = 0, gameY = 0, scale = 1 })
local battleSelected, battleLearning, statusPower = false, false, false
for _, row in ipairs(draws.text) do
  if row.text == "SELECTED" then battleSelected = true end
  if row.text == "LEARNING" then battleLearning = true end
  if row.text == "PWR ---" then statusPower = true end
end
assert(battleSelected and battleLearning and statusPower,
  "battle choose-forget comparison not drawn")

-- PP Up fallback follows Gen 2's +min(floor(base/5),7) per PP Up.
local pp = mod.exports.maxPpFor({ pp = 40 }, { ppUps = 3 })
assert(pp == 61, "Gen 2 max PP fallback should cap each PP Up bonus at 7")
assert(mod.exports.moveStats(data, "GROWL", mon.moves[2]).power == "---")
assert(mod.exports.shortName("DOUBLE-EDGE", 8) == "DOUBLE-E")

print("pokemonmod_gen2_move_learn_stats contract: ok")
