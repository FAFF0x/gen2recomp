# Changelog

## 2.0.0

- New standalone Generation 2 port for Gold / Silver / Crystal.
- New unique mod id `moves_manager_gen2` and screen id `Gen2MovesManager`.
- Restricted manifest to `games: ["gen2"]`.
- Rebuilt move memory from Gen 2 `levelMoves` across the evolutionary line.
- Added WATERFALL and WHIRLPOOL to HM deletion protection.
- Added exact Generation 2 type-based Physical/Special classification.
- Corrected Gen 2 PP Up maximum PP calculation and honours live `maxPp`.
- New replacement move slots initialise `maxPp` correctly.
- Added `gen2_modern_ui` compatibility adapter/export.
- Submenu injection replaces an existing exact `MOVES` row instead of duplicating it.
- Eggs and battle party submenus are left unchanged.
