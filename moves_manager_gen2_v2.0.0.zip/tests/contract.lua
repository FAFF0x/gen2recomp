package.path = './?.lua;./?/init.lua;' .. package.path

local root = os.getenv('MOD_ROOT') or '.'
local captured = { screens = {}, hooks = {}, events = {} }

local Font = {
  draw = function() end, drawCode = function() end,
}
local Theme = { cursor = '>', cursorHollow = 'o' }
local TextBox = { new = function(game, text) return { game = game, text = text } end }

local TYPE = {
  NORMAL = { name = 'NORMAL', category = 'physical' },
  STEEL = { name = 'STEEL', category = 'physical' },
  DARK = { name = 'DARK', category = 'special' },
  FIRE = { name = 'FIRE', category = 'special' },
}
local EFFECTS = { HIT = { kind = 'primary' } }

local mod = {
  ui = {
    Font = Font, Theme = Theme, TextBox = TextBox,
    push = function(game, id, mon) captured.push = { game=game, id=id, mon=mon } end,
  },
  content = {
    type_chart = { get = function(_, id) return TYPE[id] end },
    move_effects = { get = function(_, id) return EFFECTS[id] end },
    screens = { register = function(_, id, spec) captured.screens[id] = spec end },
  },
  hooks = { wrap = function(_, name, fn, priority) captured.hooks[name] = { fn=fn, priority=priority } end },
  events = { on = function(_, name, fn) captured.events[name] = fn end },
  exports = {},
  find = function() return nil end,
  log = { warn = function() end },
}

local init = assert(loadfile(root .. '/main.lua'))()
assert(type(init) == 'function')
init(mod)

assert(captured.screens.Gen2MovesManager, 'Gen2 screen id not registered')
assert(captured.hooks['ui.party.submenu'], 'party submenu hook missing')
assert(mod.exports.gen2ModernUi, 'gen2ModernUi export missing')
assert(not mod.exports.gen1ModernUi, 'Gen1 compatibility export must not exist')

local hook = captured.hooks['ui.party.submenu'].fn
local game = { data = { pokemon = {}, moves = {} }, stack = { push=function()end, pop=function()end } }
local mon = { species='BAYLEEF', level=20, moves={} }
local base = { {id='STATS',label='STATS'}, {id='SWITCH',label='SWITCH'} }
local out = hook(function(_, items) return items end, game, base, mon, {battle=false})
assert(#out == 3 and out[2].label == 'MOVES' and out[2].id == 'MOVES_MANAGER_GEN2', 'MOVES must be inserted after STATS')

local old = { {id='STATS',label='STATS'}, {id='OLD_MANAGER',label='MOVES'}, {id='SWITCH',label='SWITCH'} }
local replaced = hook(function(_, items) return items end, game, old, mon, {battle=false})
local count=0
for _,it in ipairs(replaced) do if it.label == 'MOVES' then count=count+1 end end
assert(count == 1 and replaced[2].id == 'MOVES_MANAGER_GEN2', 'legacy MOVES row must be replaced, not duplicated')

local battle = { {id='SWITCH',label='SWITCH'}, {id='STATS',label='STATS'}, {id='CANCEL',label='CANCEL'} }
hook(function(_, items) return items end, game, battle, mon, {battle=true})
for _,it in ipairs(battle) do assert(it.label ~= 'MOVES', 'MOVES must not enter battle submenu') end
local egg = { {id='STATS',label='STATS'}, {id='SWITCH',label='SWITCH'} }
hook(function(_, items) return items end, game, egg, {isEgg=true}, {battle=false})
for _,it in ipairs(egg) do assert(it.label ~= 'MOVES', 'MOVES must not enter egg submenu') end

local moves = {
  TACKLE={name='TACKLE',type='NORMAL',power=35,accuracy=95,pp=35,effect='HIT'},
  RAZOR_LEAF={name='RAZOR LEAF',type='NORMAL',power=55,accuracy=95,pp=25,effect='HIT'},
  REFLECT={name='REFLECT',type='NORMAL',power=0,accuracy=100,pp=20,effect='HIT'},
  BODY_SLAM={name='BODY SLAM',type='NORMAL',power=85,accuracy=100,pp=15,effect='HIT'},
  WHIRLPOOL={name='WHIRLPOOL',type='FIRE',power=15,accuracy=70,pp=15,effect='HIT'},
  STEEL_TEST={name='STEEL TEST',type='STEEL',power=70,accuracy=100,pp=40,effect='HIT'},
  DARK_TEST={name='DARK TEST',type='DARK',power=70,accuracy=100,pp=15,effect='HIT'},
}
local pokemon = {
  CHIKORITA={levelMoves={{level=1,move='TACKLE'},{level=8,move='RAZOR_LEAF'}},evolutions={{species='BAYLEEF'}}},
  BAYLEEF={levelMoves={{level=1,move='TACKLE'},{level=12,move='REFLECT'},{level=22,move='BODY_SLAM'}},evolutions={{species='MEGANIUM'}}},
  MEGANIUM={levelMoves={{level=1,move='TACKLE'}},evolutions={}},
}
game.data.pokemon, game.data.moves = pokemon, moves
mon = { species='BAYLEEF', level=20, moves={
  {id='STEEL_TEST',pp=20,maxPp=61,ppUps=3},
  {id='WHIRLPOOL',pp=10,maxPp=15},
} }
local learned = mod.exports.learnedMoves(game, mon)
local seen={}; for _,id in ipairs(learned) do seen[id]=true end
assert(seen.TACKLE and seen.RAZOR_LEAF and seen.REFLECT, 'Gen2 evolution-line levelMoves not rebuilt')
assert(not seen.BODY_SLAM, 'move above current level must not be remembered')
assert(seen.STEEL_TEST and seen.WHIRLPOOL, 'current moves must always be remembered')

local ok, reason = mod.exports.replaceMove(game, mon, 2, 'DARK_TEST')
assert(not ok and reason == 'hm_locked', 'WHIRLPOOL must be HM-locked')
ok, reason = mod.exports.replaceMove(game, mon, 1, 'DARK_TEST')
assert(ok, 'normal move replacement failed')
assert(mon.moves[1].id == 'DARK_TEST' and mon.moves[1].pp == 15 and mon.moves[1].maxPp == 15, 'replacement slot must initialise Gen2 maxPp')

assert(mod.exports.maxPP({pp=40},{ppUps=3}) == 61, 'Gen2 PP Up cap for base-40 move must be 61')
assert(mod.exports.maxPP({pp=40},{ppUps=3,maxPp=57}) == 57, 'live maxPp must win')

-- Modern UI model must expose the Gen 2 type split.
local screen = captured.screens.Gen2MovesManager.new(game, {species='BAYLEEF',level=20,moves={{id='STEEL_TEST',pp=20,maxPp=40}}})
screen.mode='current_detail'; screen.detailPage=1; screen.slot=1
local adapter = mod.exports.gen2ModernUi.screens.moves_manager_gen2
local model = adapter.model(nil, screen)
local class
for _,row in ipairs(model.rows or {}) do if row.label == 'CLASS' then class=row.value end end
assert(class == 'PHYSICAL', 'STEEL must be PHYSICAL in Gen2')
screen.mon.moves[1]={id='DARK_TEST',pp=15,maxPp=15}
model = adapter.model(nil, screen)
for _,row in ipairs(model.rows or {}) do if row.label == 'CLASS' then class=row.value end end
assert(class == 'SPECIAL', 'DARK must be SPECIAL in Gen2')

print('contract-ok')
