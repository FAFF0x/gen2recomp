local path = assert(os.getenv('TARGET_LUA'))
local f, err = loadfile(path)
if not f then error(err) end
print('lua-syntax-ok')
