# Changelog

## 2.0.1

- Rebuilt all 251 Gen 2 icon sheets directly from the original 32×64 source artwork instead of enlarging the already-downscaled 16×32 runtime assets.
- Automatically cropped transparent margins using a shared bounding box for both animation frames.
- Rescaled each Pokémon to fill up to 15×15 pixels inside the native 16×16 Gen 2 frame while preserving aspect ratio.
- Preserved two-frame animation alignment, transparency, full colour, held-item/mail markers, and unique per-species sheet IDs.
- No manifest/import identity changes: the mod remains Gen 2-only under `new_icons_gen2` and keeps `conflicts: []`.


## 2.0.0

- New standalone **Gen 2-only** package (`new_icons_gen2`).
- Converted all 251 supplied runtime sheets from 32×64 to native Gen 2 16×32 two-frame sheets using nearest-neighbour scaling.
- Added one unique `ICON_NEW_ICONS_GEN2_*` sheet per species instead of replacing shared vanilla icon families.
- Added true-colour stock `Gen2PartyMenu` rendering while preserving held-item/mail markers.
- Added true-colour trade-animation integration.
- Added optional `gen2_modern_ui` compatibility through the native Gen 2 icon registry.
- No conflict declaration with the Gen 1 `new_icons` package or other icon packs.
