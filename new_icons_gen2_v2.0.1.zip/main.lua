-- NEW ICONS - GEN 2 v2.0.1
--
-- Gen 2-only port of NEW ICONS. v2.0.1 uses tightly cropped, larger icon art.
-- Each species gets its own dedicated ICON_*
-- sheet in the native Gold/Silver/Crystal format: 16x32, two 16x16 frames
-- stacked vertically. Species assignments are overridden individually, so we
-- never replace one of the 39 shared vanilla sheets for unrelated species.

local SPECIES = {
  "ABRA",
  "AERODACTYL",
  "AIPOM",
  "ALAKAZAM",
  "AMPHAROS",
  "ARBOK",
  "ARCANINE",
  "ARIADOS",
  "ARTICUNO",
  "AZUMARILL",
  "BAYLEEF",
  "BEEDRILL",
  "BELLOSSOM",
  "BELLSPROUT",
  "BLASTOISE",
  "BLISSEY",
  "BULBASAUR",
  "BUTTERFREE",
  "CATERPIE",
  "CELEBI",
  "CHANSEY",
  "CHARIZARD",
  "CHARMANDER",
  "CHARMELEON",
  "CHIKORITA",
  "CHINCHOU",
  "CLEFABLE",
  "CLEFAIRY",
  "CLEFFA",
  "CLOYSTER",
  "CORSOLA",
  "CROBAT",
  "CROCONAW",
  "CUBONE",
  "CYNDAQUIL",
  "DELIBIRD",
  "DEWGONG",
  "DIGLETT",
  "DITTO",
  "DODRIO",
  "DODUO",
  "DONPHAN",
  "DRAGONAIR",
  "DRAGONITE",
  "DRATINI",
  "DROWZEE",
  "DUGTRIO",
  "DUNSPARCE",
  "EEVEE",
  "EKANS",
  "ELECTABUZZ",
  "ELECTRODE",
  "ELEKID",
  "ENTEI",
  "ESPEON",
  "EXEGGCUTE",
  "EXEGGUTOR",
  "FARFETCHD",
  "FEAROW",
  "FERALIGATR",
  "FLAAFFY",
  "FLAREON",
  "FORRETRESS",
  "FURRET",
  "GASTLY",
  "GENGAR",
  "GEODUDE",
  "GIRAFARIG",
  "GLIGAR",
  "GLOOM",
  "GOLBAT",
  "GOLDEEN",
  "GOLDUCK",
  "GOLEM",
  "GRANBULL",
  "GRAVELER",
  "GRIMER",
  "GROWLITHE",
  "GYARADOS",
  "HAUNTER",
  "HERACROSS",
  "HITMONCHAN",
  "HITMONLEE",
  "HITMONTOP",
  "HOOTHOOT",
  "HOPPIP",
  "HORSEA",
  "HOUNDOOM",
  "HOUNDOUR",
  "HO_OH",
  "HYPNO",
  "IGGLYBUFF",
  "IVYSAUR",
  "JIGGLYPUFF",
  "JOLTEON",
  "JUMPLUFF",
  "JYNX",
  "KABUTO",
  "KABUTOPS",
  "KADABRA",
  "KAKUNA",
  "KANGASKHAN",
  "KINGDRA",
  "KINGLER",
  "KOFFING",
  "KRABBY",
  "LANTURN",
  "LAPRAS",
  "LARVITAR",
  "LEDIAN",
  "LEDYBA",
  "LICKITUNG",
  "LUGIA",
  "MACHAMP",
  "MACHOKE",
  "MACHOP",
  "MAGBY",
  "MAGCARGO",
  "MAGIKARP",
  "MAGMAR",
  "MAGNEMITE",
  "MAGNETON",
  "MANKEY",
  "MANTINE",
  "MAREEP",
  "MARILL",
  "MAROWAK",
  "MEGANIUM",
  "MEOWTH",
  "METAPOD",
  "MEW",
  "MEWTWO",
  "MILTANK",
  "MISDREAVUS",
  "MOLTRES",
  "MR_MIME",
  "MUK",
  "MURKROW",
  "NATU",
  "NIDOKING",
  "NIDOQUEEN",
  "NIDORAN_F",
  "NIDORAN_M",
  "NIDORINA",
  "NIDORINO",
  "NINETALES",
  "NOCTOWL",
  "OCTILLERY",
  "ODDISH",
  "OMANYTE",
  "OMASTAR",
  "ONIX",
  "PARAS",
  "PARASECT",
  "PERSIAN",
  "PHANPY",
  "PICHU",
  "PIDGEOT",
  "PIDGEOTTO",
  "PIDGEY",
  "PIKACHU",
  "PILOSWINE",
  "PINECO",
  "PINSIR",
  "POLITOED",
  "POLIWAG",
  "POLIWHIRL",
  "POLIWRATH",
  "PONYTA",
  "PORYGON",
  "PORYGON2",
  "PRIMEAPE",
  "PSYDUCK",
  "PUPITAR",
  "QUAGSIRE",
  "QUILAVA",
  "QWILFISH",
  "RAICHU",
  "RAIKOU",
  "RAPIDASH",
  "RATICATE",
  "RATTATA",
  "REMORAID",
  "RHYDON",
  "RHYHORN",
  "SANDSHREW",
  "SANDSLASH",
  "SCIZOR",
  "SCYTHER",
  "SEADRA",
  "SEAKING",
  "SEEL",
  "SENTRET",
  "SHELLDER",
  "SHUCKLE",
  "SKARMORY",
  "SKIPLOOM",
  "SLOWBRO",
  "SLOWKING",
  "SLOWPOKE",
  "SLUGMA",
  "SMEARGLE",
  "SMOOCHUM",
  "SNEASEL",
  "SNORLAX",
  "SNUBBULL",
  "SPEAROW",
  "SPINARAK",
  "SQUIRTLE",
  "STANTLER",
  "STARMIE",
  "STARYU",
  "STEELIX",
  "SUDOWOODO",
  "SUICUNE",
  "SUNFLORA",
  "SUNKERN",
  "SWINUB",
  "TANGELA",
  "TAUROS",
  "TEDDIURSA",
  "TENTACOOL",
  "TENTACRUEL",
  "TOGEPI",
  "TOGETIC",
  "TOTODILE",
  "TYPHLOSION",
  "TYRANITAR",
  "TYROGUE",
  "UMBREON",
  "UNOWN",
  "URSARING",
  "VAPOREON",
  "VENOMOTH",
  "VENONAT",
  "VENUSAUR",
  "VICTREEBEL",
  "VILEPLUME",
  "VOLTORB",
  "VULPIX",
  "WARTORTLE",
  "WEEDLE",
  "WEEPINBELL",
  "WEEZING",
  "WIGGLYTUFF",
  "WOBBUFFET",
  "WOOPER",
  "XATU",
  "YANMA",
  "ZAPDOS",
  "ZUBAT",
}

local PREFIX = "ICON_NEW_ICONS_GEN2_"

return function(mod)
  local sheetIds = {}
  local registered, assigned, missing = 0, 0, 0

  -- Gen 2's icons registry has two id forms:
  --   ICON_*  -> a concrete sheet descriptor
  --   species -> the ICON_* id assigned to that species
  -- Use unique sheet ids owned by this mod, then only override the species
  -- assignment. This leaves vanilla shared sheets and other species untouched.
  for _, species in ipairs(SPECIES) do
    local rel = "assets/icons_gen2/" .. species .. ".png"
    if mod:read(rel) then
      local sheetId = PREFIX .. species
      local path = mod.assets:path(rel)
      sheetIds[species] = sheetId
      local descriptor = {
        id = sheetId,
        image = path,
        width = 16,
        height = 32,
        frames = 2,
      }

      if mod.content.icons:get(sheetId) ~= nil then
        mod.content.icons:override(sheetId, descriptor)
      else
        mod.content.icons:register(sheetId, descriptor)
      end
      registered = registered + 1

      -- Every normal Gen 2 species already has an assignment, but register()
      -- remains a safe fallback for a content pack that adds a species before
      -- this art layer is merged.
      if mod.content.icons:get(species) ~= nil then
        mod.content.icons:override(species, sheetId)
      else
        mod.content.icons:register(species, sheetId)
      end
      assigned = assigned + 1
    else
      missing = missing + 1
      mod.log:warn("NEW ICONS GEN 2: missing icon for %s", species)
    end
  end

  -- The stock Gen2PartyMenu applies the Game Boy Color party palette to every
  -- menu icon. These PNGs are authored full-colour artwork, so draw only our
  -- current species assignments in true colour. If a later icon pack changes a
  -- species assignment, this wrapper automatically falls through to vanilla.
  local okParty, errParty = pcall(function()
    local PartyMenu = require("src.ui.gen2.PartyMenu")
    local GbcPalette = require("src.render.GbcPalette")

    PartyMenu.__newIconsGen2Sheets = sheetIds
    if PartyMenu.__newIconsGen2Wrapped then return end

    local original = PartyMenu.drawIcon
    PartyMenu.__newIconsGen2OriginalDrawIcon = original

    function PartyMenu:drawIcon(mon, px, py)
      local species = mon and mon.species
      local wanted = species and PartyMenu.__newIconsGen2Sheets
        and PartyMenu.__newIconsGen2Sheets[species]
      local current = wanted and self.icons and self.icons.species
        and self.icons.species[species]
      if not wanted or current ~= wanted then
        return original(self, mon, px, py)
      end

      local image, frame = self:iconFor(mon)
      if not image then return original(self, mon, px, py) end
      local iw, ih = image:getDimensions()
      if iw < 16 or ih < 32 then return original(self, mon, px, py) end

      local G = love.graphics
      local fy = ((frame or 0) % 2) * 16
      local markerRow = PartyMenu.heldMarkerRow
        and PartyMenu.heldMarkerRow(mon) or nil
      local marker = markerRow ~= nil and self.heldMarkerImage
        and self:heldMarkerImage() or nil

      G.setColor(1, 1, 1, 1)
      if marker then
        -- Preserve the Gen 2 held-item/mail marker behaviour: it REPLACES the
        -- lower-left 8x8 quadrant rather than being drawn over the icon.
        local topLeft = G.newQuad(0, fy, 8, 8, iw, ih)
        local topRight = G.newQuad(8, fy, 8, 8, iw, ih)
        local bottomRight = G.newQuad(8, fy + 8, 8, 8, iw, ih)
        G.draw(image, topLeft, px, py)
        G.draw(image, topRight, px + 8, py)
        G.draw(image, bottomRight, px + 8, py + 8)

        local mw, mh = marker:getDimensions()
        local held = G.newQuad(0, markerRow * 8, 8, 8, mw, mh)
        local function drawHeld()
          G.setColor(1, 1, 1, 1)
          G.draw(marker, held, px, py + 8)
        end
        local pals = self.palettes and self.palettes.partyMenu
        local colors = pals and pals[1] or nil
        if colors and GbcPalette.available() then
          GbcPalette.with(colors, drawHeld)
        else
          drawHeld()
        end
      else
        local quad = G.newQuad(0, fy, 16, 16, iw, ih)
        G.draw(image, quad, px, py)
      end
      G.setColor(1, 1, 1, 1)
      return true
    end

    PartyMenu.__newIconsGen2Wrapped = true
  end)
  if not okParty then
    mod.log:warn("NEW ICONS GEN 2: PartyMenu true-colour patch failed: %s",
      tostring(errParty))
  end

  -- The trade animation also consumes the same small Gen 2 icon sheets but
  -- recolours them with the species palette. Keep our authored RGB pixels there
  -- as well. This patch only activates while the species is still assigned to
  -- this mod's unique sheet id.
  local okTrade, errTrade = pcall(function()
    local TradeAnim = require("src.ui.gen2.TradeAnim")
    local Assets = require("src.render.Assets")
    TradeAnim.__newIconsGen2Sheets = sheetIds
    TradeAnim.__newIconsGen2Cache = TradeAnim.__newIconsGen2Cache or {}
    if TradeAnim.__newIconsGen2Wrapped then return end

    local original = TradeAnim.drawIcon
    TradeAnim.__newIconsGen2OriginalDrawIcon = original
    function TradeAnim:drawIcon(record, x, y)
      local species = record and record.species
      local wanted = species and TradeAnim.__newIconsGen2Sheets
        and TradeAnim.__newIconsGen2Sheets[species]
      local icons = self.data and self.data.gen2Icons
      local current = wanted and icons and icons.species
        and icons.species[species]
      if not wanted or current ~= wanted then
        return original(self, record, x, y)
      end
      local entry = icons.icons and icons.icons[current]
      if not (entry and entry.image) then return original(self, record, x, y) end
      local cache = TradeAnim.__newIconsGen2Cache
      local image = cache[entry.image]
      if image == nil then
        local ok, loaded = pcall(Assets.image, entry.image)
        image = ok and loaded or false
        cache[entry.image] = image
      end
      if not image then return original(self, record, x, y) end
      local iw, ih = image:getDimensions()
      if iw < 16 or ih < 16 then return original(self, record, x, y) end
      local quad = love.graphics.newQuad(0, 0, 16, 16, iw, ih)
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.draw(image, quad, x, y)
      love.graphics.setColor(1, 1, 1, 1)
      return true
    end
    TradeAnim.__newIconsGen2Wrapped = true
  end)
  if not okTrade then
    mod.log:warn("NEW ICONS GEN 2: TradeAnim true-colour patch failed: %s",
      tostring(errTrade))
  end

  mod.log:info(
    "NEW ICONS GEN 2: installed %d unique two-frame sheets, %d assignments, %d missing; party=%s trade=%s",
    registered, assigned, missing, tostring(okParty), tostring(okTrade))
end
