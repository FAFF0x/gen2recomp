# Changelog

## 2.0.0
- Ported NEW ITEM ICONS exclusively to Gen 2.
- Added unique `new_item_icons_gen2` package identity.
- Added native Gen2PackMenu thumbnails, including Battle PACK.
- Added Gen2MartMenu BUY thumbnails.
- Added Gen2ItemPcMenu withdraw/toss thumbnails.
- Added Gen2 Modern UI additive icon-row adapter.
- Added Gen 2 `teaches` support for TM/HM move-type artwork.
- Added custom `machine.move` fallback for modded machines.
- Removed all Gen 1 ListMenu/Bag-specific patching.
