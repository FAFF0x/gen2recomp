local MOD_ID = "new_item_icons_gen2"
local VERSION = "2.0.0"
local SOURCE = MOD_ID
local CATALOG = {
  items = {
    "antidote",
    "awakening",
    "bicycle",
    "bike-voucher",
    "burn-heal",
    "calcium",
    "carbos",
    "card-key",
    "coin-case",
    "dire-hit",
    "dome-fossil",
    "dowsing-machine",
    "elixir",
    "escape-rope",
    "ether",
    "exp-share",
    "fire-stone",
    "fresh-water",
    "full-heal",
    "full-restore",
    "gold-teeth",
    "good-rod",
    "great-ball",
    "guard-spec",
    "helix-fossil",
    "hp-up",
    "hyper-potion",
    "ice-heal",
    "iron",
    "leaf-stone",
    "lemonade",
    "lift-key",
    "master-ball",
    "max-elixir",
    "max-ether",
    "max-potion",
    "max-repel",
    "max-revive",
    "moon-stone",
    "nugget",
    "old-amber",
    "old-rod",
    "paralyze-heal",
    "parcel",
    "poke-ball",
    "poke-doll",
    "poke-flute",
    "potion",
    "pp-up",
    "protein",
    "rare-candy",
    "repel",
    "revive",
    "safari-ball",
    "secret-key",
    "silph-scope",
    "soda-pop",
    "ss-ticket",
    "super-potion",
    "super-repel",
    "super-rod",
    "thunder-stone",
    "town-map",
    "ultra-ball",
    "water-stone",
    "x-accuracy",
    "x-attack",
    "x-defense",
    "x-sp-atk",
    "x-speed",
  },
  types = {
    "bug",
    "dark",
    "dragon",
    "electric",
    "fairy",
    "fighting",
    "fire",
    "flying",
    "ghost",
    "grass",
    "ground",
    "ice",
    "normal",
    "poison",
    "psychic",
    "rock",
    "steel",
    "water",
  },
}

local ALIASES = {
  PARLYZ_HEAL = "paralyze-heal",
  PARALYZE_HEAL = "paralyze-heal",
  ITEMFINDER = "dowsing-machine",
  DOWSING_MACHINE = "dowsing-machine",
  EXP_SHARE = "exp-share",
  EXP_ALL = "exp-share",
  OAKS_PARCEL = "parcel",
  OAK_PARCEL = "parcel",
  PARCEL = "parcel",
  X_DEFEND = "x-defense",
  X_DEFENSE = "x-defense",
  X_SPECIAL = "x-sp-atk",
  X_SP_ATK = "x-sp-atk",
  S_S_TICKET = "ss-ticket",
  SS_TICKET = "ss-ticket",
  PARK_BALL = "safari-ball",
}

local function slugify(value)
  local s = tostring(value or "")
  s = s:gsub("É", "E"):gsub("é", "e")
  s = s:gsub("’", ""):gsub("'", "")
  s = s:gsub("[%.%/]", "")
  s = s:lower():gsub("[^%w]+", "-")
  return s:gsub("^%-+", ""):gsub("%-+$", "")
end

local function same(value) return value end

return function(mod)
  local itemPaths, typePaths = {}, {}
  local gameRef

  for _, slug in ipairs(CATALOG.items or {}) do
    local rel = "assets/items/" .. slug .. ".png"
    if mod:read(rel) then itemPaths[slug] = mod.assets:path(rel) end
  end
  for _, slug in ipairs(CATALOG.types or {}) do
    local rel = "assets/items/tm-hm/" .. slug .. ".png"
    if mod:read(rel) then typePaths[slug:upper()] = mod.assets:path(rel) end
  end

  local function machineMove(def)
    if type(def) ~= "table" then return nil end
    if def.teaches then return def.teaches end
    local machine = def.machine
    return type(machine) == "table" and machine.move or nil
  end

  local function spriteFor(game, itemId, def)
    if type(def) ~= "table" then return nil end
    local moveId = machineMove(def)
    if moveId and game and game.data then
      local move = game.data.moves and game.data.moves[moveId]
      local moveType = move and tostring(move.type or ""):upper()
      if moveType and typePaths[moveType] then return typePaths[moveType], moveType end
      if typePaths.NORMAL then return typePaths.NORMAL, moveType or "UNKNOWN" end
    end

    local alias = ALIASES[tostring(itemId or "")]
    if alias and itemPaths[alias] then return itemPaths[alias] end
    local byId = slugify(itemId)
    if itemPaths[byId] then return itemPaths[byId] end
    local byName = slugify(def.name)
    if itemPaths[byName] then return itemPaths[byName] end
    return nil
  end

  local function assignDefs(game)
    local items = game and game.data and game.data.items
    if type(items) ~= "table" then return 0, 0 end
    local assigned, machines = 0, 0
    for id, def in pairs(items) do
      if type(def) == "table" then
        local path, moveType = spriteFor(game, id, def)
        if path then
          def.image = path
          def.icon = path
          def.itemSprite = path
          def.itemSpriteTrueColor = true
          def.itemSpriteSource = SOURCE
          def.itemSpriteMoveType = moveType
          assigned = assigned + 1
          if moveType then machines = machines + 1 end
        end
      end
    end
    return assigned, machines
  end

  local function pathFor(game, id)
    local def = game and game.data and game.data.items and game.data.items[id]
    if type(def) ~= "table" or def.itemSpriteSource ~= SOURCE then return nil end
    return def.itemSprite or def.image or def.icon
  end

  local function decorateRows(game, rows)
    if type(rows) ~= "table" then return end
    for _, row in ipairs(rows) do
      if type(row) == "table" then
        local id = row.id or row.value or row.itemId or row.item
        local path = id and pathFor(game, id)
        if path then
          row.image = { image = path, trueColor = true }
          row.icon = row.image
          row._newItemIconGen2 = path
        end
      end
    end
  end

  local function decorateState(game, state)
    if type(state) ~= "table" then return end
    if type(state.rows) == "table" then decorateRows(game, state.rows) end
    if type(state.entries) == "table" then decorateRows(game, state.entries) end
    if type(state.items) == "table" and #state.items > 0 then
      decorateRows(game, state.items)
    end
  end

  local imageCache = {}
  local function loadImage(path)
    if not path then return nil end
    local hit = imageCache[path]
    if hit ~= nil then return hit or nil end
    local okAssets, Assets = pcall(require, "src.render.Assets")
    if not okAssets then imageCache[path] = false return nil end
    local ok, image = pcall(Assets.image, path)
    if ok and image then
      if image.setFilter then image:setFilter("nearest", "nearest") end
      imageCache[path] = image
      return image
    end
    imageCache[path] = false
    return nil
  end

  local function drawThumb(path, x, y, size)
    local image = loadImage(path)
    if not image or not love or not love.graphics then return end
    local iw, ih = image:getDimensions()
    if not iw or not ih or iw <= 0 or ih <= 0 then return end
    local scale = math.min(size / iw, size / ih)
    local G = love.graphics
    G.setColor(1, 1, 1, 1)
    G.draw(image, x + (size - iw * scale) / 2,
      y + (size - ih * scale) / 2, 0, scale, scale)
  end

  local function installNativeGen2()
    local okPack, PackMenu = pcall(require, "src.ui.gen2.PackMenu")
    if okPack and type(PackMenu) == "table" and not PackMenu._newItemIconsGen2 then
      local original = PackMenu.drawList
      PackMenu.drawList = function(self, listX, listY, ...)
        local result = original(self, listX, listY, ...)
        for rowNo = 1, 5 do
          local index = rowNo + (self.scroll or 0)
          local row = self.rows and self.rows[index]
          local path = row and pathFor(self.game, row.id)
          if path then
            local y = (listY + (rowNo - 1) * 2) * 8
            drawThumb(path, (listX - 2) * 8, y, 8)
          end
        end
        return result
      end
      PackMenu._newItemIconsGen2 = true
    end

    local okMart, MartMenu = pcall(require, "src.ui.gen2.MartMenu")
    if okMart and type(MartMenu) == "table" and not MartMenu._newItemIconsGen2 then
      local original = MartMenu.drawBuyList
      MartMenu.drawBuyList = function(self, ...)
        local result = original(self, ...)
        for rowNo = 1, 4 do
          local index = rowNo + (self.scroll or 0)
          local row = self.entries and self.entries[index]
          local path = row and pathFor(self.game, row.id)
          if path then drawThumb(path, 0, (4 + (rowNo - 1) * 2) * 8, 8) end
        end
        return result
      end
      MartMenu._newItemIconsGen2 = true
    end

    local okPc, ItemPcMenu = pcall(require, "src.ui.gen2.ItemPcMenu")
    if okPc and type(ItemPcMenu) == "table" and not ItemPcMenu._newItemIconsGen2 then
      local original = ItemPcMenu.drawList
      ItemPcMenu.drawList = function(self, ...)
        local result = original(self, ...)
        for rowNo = 1, 4 do
          local index = rowNo + (self.scroll or 0)
          local row = self.rows and self.rows[index]
          local path = row and pathFor(self.game, row.id)
          if path then drawThumb(path, 24, rowNo * 16, 8) end
        end
        return result
      end
      ItemPcMenu._newItemIconsGen2 = true
    end
  end

  local modernUiContract = {
    apiVersion = 1,
    extensions = {
      item_icons = {
        priority = 40,
        match = function(state, kind)
          if type(state) ~= "table" then return false end
          if kind == "bag" and state.screenId == "Gen2PackMenu" then return true end
          if kind == "gen2_mart" then return true end
          if kind == "gen2_item_pc" and state.screenId == "Gen2ItemPcMenu" then return true end
          return false
        end,
        model = function(game, state, kind)
          local source
          if kind == "bag" then
            source = state.rows
          elseif kind == "gen2_mart" then
            if state.screenId == "AllTmShopGen2Catalogue" then
              source = state.rows
            elseif (state.phase == "sell" or state.phase == "sellQuantity")
                and type(state.pack) == "table" then
              source = state.pack.rows
            elseif state.phase ~= "top" then
              source = state.entries
            end
          elseif kind == "gen2_item_pc" then
            if state.phase == "deposit" and type(state.pack) == "table" then
              source = state.pack.rows
            elseif state.phase == "withdraw" or state.phase == "toss" then
              source = state.rows
            end
          end
          local patches = {}
          for index, row in ipairs(source or {}) do
            local id = type(row) == "table" and (row.id or row.value)
            local path = id and pathFor(game, id)
            if path then
              patches[index] = {
                index = index,
                image = { image = path, trueColor = true },
              }
            end
          end
          return { rows = patches }
        end,
      },
    },
  }

  local modernUiRegistered = false
  local modernUiExports
  local function ensureModernUi()
    if type(mod.find) ~= "function" then return false end
    local ok, handle = pcall(mod.find, "gen2_modern_ui")
    if not ok or type(handle) ~= "table" or type(handle.exports) ~= "table" then
      return false
    end
    local ex = handle.exports
    if type(ex.registerAdapter) ~= "function" then return false end
    if modernUiRegistered and modernUiExports == ex then return true end
    local okReg, registered = pcall(ex.registerAdapter, {
      owner = MOD_ID, version = VERSION, contract = modernUiContract,
    })
    modernUiRegistered = okReg and registered ~= false
    modernUiExports = ex
    return modernUiRegistered
  end

  mod.exports.gen2ModernUi = modernUiContract
  mod.exports.spriteForItem = function(game, itemId)
    local def = game and game.data and game.data.items and game.data.items[itemId]
    return spriteFor(game, itemId, def)
  end
  mod.exports.decorateRows = decorateRows
  mod.exports.ensureModernUiAdapter = ensureModernUi

  mod.events:on("game.ready", function(ev)
    gameRef = ev and ev.game or nil
    if not gameRef then return end
    local assigned, machines = assignDefs(gameRef)
    installNativeGen2()
    ensureModernUi()
    mod.log:info(
      "NEW ITEM ICONS - Gen 2 %s: assigned %d item sprites (%d TM/HM by move type)",
      VERSION, assigned, machines)
  end, 220)

  mod.events:on("screen.pushed", function(ev)
    if gameRef and ev and ev.state then decorateState(gameRef, ev.state) end
  end, 220)

  mod.hooks:wrap("render.hud", function(next, game, viewport)
    if game and game.stack and type(game.stack.states) == "table" then
      for _, state in ipairs(game.stack.states) do decorateState(game, state) end
    end
    return next(game, viewport)
  end, 220)
end
