package.path = "./?.lua;./?/init.lua;" .. package.path

local init = assert(loadfile("main.lua"))()
assert(type(init) == "function")

local handlers = {}
local mod = {
  exports = {},
  events = {},
  hooks = {},
  assets = {},
  log = { info = function() end, warn = function() end },
}
function mod:read(rel)
  local f = io.open(rel, "rb")
  if f then f:close(); return true end
  return nil
end
function mod.assets:path(rel) return "MOD/" .. rel end
function mod.events:on(name, fn)
  handlers[name] = handlers[name] or {}
  handlers[name][#handlers[name] + 1] = fn
end
function mod.hooks:wrap(name, fn) mod._hudWrap = fn end

init(mod)
assert(type(mod.exports.spriteForItem) == "function")
assert(type(mod.exports.gen2ModernUi) == "table")
assert(type(mod._hudWrap) == "function")

local game = {
  data = {
    items = {
      POTION = { id = "POTION", name = "POTION" },
      PARLYZ_HEAL = { id = "PARLYZ_HEAL", name = "PARLYZ HEAL" },
      PARK_BALL = { id = "PARK_BALL", name = "PARK BALL" },
      TM_DYNAMICPUNCH = {
        id = "TM_DYNAMICPUNCH", name = "TM01", teaches = "DYNAMICPUNCH"
      },
      HM_WHIRLPOOL = {
        id = "HM_WHIRLPOOL", name = "HM06", teaches = "WHIRLPOOL"
      },
      GEN2_ONLY = { id = "GEN2_ONLY", name = "MYSTERY ITEM" },
    },
    moves = {
      DYNAMICPUNCH = { type = "FIGHTING" },
      WHIRLPOOL = { type = "WATER" },
    },
  },
  stack = { states = {} },
}

assert(handlers["game.ready"] and handlers["game.ready"][1])
handlers["game.ready"][1]({ game = game })

local potion = game.data.items.POTION
assert(potion.itemSpriteSource == "new_item_icons_gen2")
assert(potion.itemSprite:match("potion%.png$"))
assert(game.data.items.PARLYZ_HEAL.itemSprite:match("paralyze%-heal%.png$"))
assert(game.data.items.PARK_BALL.itemSprite:match("safari%-ball%.png$"))
assert(game.data.items.TM_DYNAMICPUNCH.itemSprite:match("tm%-hm/fighting%.png$"))
assert(game.data.items.HM_WHIRLPOOL.itemSprite:match("tm%-hm/water%.png$"))
assert(game.data.items.GEN2_ONLY.itemSprite == nil)

local rows = {
  { id = "POTION", name = "POTION" },
  { id = "GEN2_ONLY", name = "MYSTERY ITEM" },
}
mod.exports.decorateRows(game, rows)
assert(type(rows[1].image) == "table")
assert(rows[1].image.trueColor == true)
assert(rows[2].image == nil)

local ext = assert(mod.exports.gen2ModernUi.extensions.item_icons)
assert(ext.match({ screenId = "Gen2PackMenu" }, "bag") == true)
assert(ext.match({ screenId = "Gen2MartMenu" }, "gen2_mart") == true)
assert(ext.match({ screenId = "Gen2ItemPcMenu" }, "gen2_item_pc") == true)
assert(ext.match({ screenId = "BagMenu" }, "bag") == false)

local bagState = { screenId = "Gen2PackMenu", rows = rows }
local model = ext.model(game, bagState, "bag")
assert(type(model.rows[1].image) == "table")
assert(model.rows[1].image.trueColor == true)
assert(model.rows[2] == nil)

print("contract-ok")
