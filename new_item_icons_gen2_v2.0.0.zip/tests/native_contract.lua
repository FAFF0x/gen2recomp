package.path = "./?.lua;./?/init.lua;" .. package.path

local draws = 0
love = {
  graphics = {
    setColor = function() end,
    draw = function() draws = draws + 1 end,
  }
}
local fakeImage = {
  getDimensions = function() return 30, 30 end,
  setFilter = function() end,
}
package.preload["src.render.Assets"] = function()
  return { image = function() return fakeImage end }
end

local PackMenu = { drawList = function(self) self.basePack = true end }
local MartMenu = { drawBuyList = function(self) self.baseMart = true end }
local ItemPcMenu = { drawList = function(self) self.basePc = true end }
package.preload["src.ui.gen2.PackMenu"] = function() return PackMenu end
package.preload["src.ui.gen2.MartMenu"] = function() return MartMenu end
package.preload["src.ui.gen2.ItemPcMenu"] = function() return ItemPcMenu end

local init = assert(loadfile("main.lua"))()
local handlers = {}
local mod = {
  exports = {}, events = {}, hooks = {}, assets = {},
  log = { info = function() end, warn = function() end },
}
function mod:read(rel)
  local f=io.open(rel,"rb"); if f then f:close(); return true end
end
function mod.assets:path(rel) return "MOD/"..rel end
function mod.events:on(name, fn)
  handlers[name]=handlers[name] or {}; table.insert(handlers[name],fn)
end
function mod.hooks:wrap() end
init(mod)

local game = {
  data = {
    items = { POTION = { id="POTION", name="POTION" } },
    moves = {},
  },
}
handlers["game.ready"][1]({game=game})

local p = setmetatable({
  game=game, rows={{id="POTION"}}, scroll=0,
}, {__index=PackMenu})
p:drawList(8,2)
assert(p.basePack == true)

local m = setmetatable({
  game=game, entries={{id="POTION"}}, scroll=0,
}, {__index=MartMenu})
m:drawBuyList()
assert(m.baseMart == true)

local pc = setmetatable({
  game=game, rows={{id="POTION"}}, scroll=0,
}, {__index=ItemPcMenu})
pc:drawList()
assert(pc.basePc == true)

assert(draws == 3, "expected one thumbnail on each native Gen 2 list")
assert(type(p.rows) == "table", "Pack rows must remain a table")
print("native-contract-ok")
