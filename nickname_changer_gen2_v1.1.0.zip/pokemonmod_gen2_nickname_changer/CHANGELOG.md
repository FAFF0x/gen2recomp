# Changelog

## 1.1.0

- Fixed **RENAME** disappearing when a Pokémon knows enough contextual field moves such as CUT, HEADBUTT, SURF, STRENGTH, etc.
- RENAME is now always inserted in the normal Gen 2 field Pokémon submenu.
- Added an eight-row scrolling renderer for oversized Gen 2 field submenus instead of deleting or hiding actions.
- Keeps every vanilla field move, STATS, SWITCH, MOVE, ITEM/MAIL and RENAME reachable.
- Battle submenus and Egg submenus remain unchanged.
- Duplicate RENAME/NICKNAME detection remains enabled for compatibility with similar mods.

## 1.0.0

- Initial Gen 2-only release.
- Changed the install/manifest id to `pokemonmod_gen2_nickname_changer` so it does not collide with the original `nickname_changer` package.
- Added a unique submenu entry id: `POKEMONMOD_GEN2_RENAME`.
- Added duplicate-entry detection for compatibility with similar nickname mods.
- Uses the native Gen 2 naming screen and the normal 10-character nickname limit.
