-- Nickname Changer - Gen 2 v1.1.0
-- Gen 2-only port of FAFF0x's Nickname Changer.
--
-- v1.1.0 keeps RENAME available even when a Pokemon has enough field moves
-- (CUT / HEADBUTT / SURF / etc.) to fill Gold's eight-row MonSubmenu.
-- The native input code already supports arbitrary item counts; this mod only
-- adds a small scrolling renderer for field submenus that grow past 8 rows.

local VERSION = "1.1.0"
local ENTRY_ID = "POKEMONMOD_GEN2_RENAME"
local MAX_VISIBLE_SUBMENU_ROWS = 8

local function upper(value)
  return tostring(value or ""):upper()
end

local function isRenameEntry(item)
  if type(item) ~= "table" then return false end

  local id = upper(item.id)
  local label = upper(item.label)

  if id == ENTRY_ID then return true end
  if label == "RENAME" or label == "NICKNAME" then return true end

  -- Be conservative with other nickname-changer mods that use a descriptive
  -- custom id but a translated/dynamic label. Vanilla Gen 2 has no submenu
  -- ids containing these words, so matching them cannot hide a stock row.
  if id:find("RENAME", 1, true) or id:find("NICKNAME", 1, true) then
    return true
  end

  return false
end

local function speciesName(game, mon)
  local data = game and game.data
  local pokemon = data and data.pokemon
  local def = pokemon and mon and pokemon[mon.species]
  return (def and def.name) or (mon and mon.name)
    or (mon and mon.species) or "POKEMON"
end

local function iconPathFor(game, mon)
  local data = game and game.data
  local icons = data and data.gen2Icons
  if type(icons) ~= "table" or type(mon) ~= "table" then return nil end

  local iconId
  if mon.isEgg then
    iconId = "ICON_EGG"
  elseif type(icons.species) == "table" then
    iconId = icons.species[mon.species]
  end

  local entry = iconId and type(icons.icons) == "table" and icons.icons[iconId]
  return type(entry) == "table" and entry.image or nil
end

-- Gold's field MonSubmenu is visually capped at eight rows, but its update
-- routine navigates #menu.items without imposing that cap.  Once RENAME makes
-- the list nine rows, draw a moving eight-row window instead of dropping an
-- action.  This is intentionally a presentation-only patch: selection and all
-- vanilla field-move callbacks remain owned by PartyMenu.
local function installScrollableGen2Submenu(mod)
  local okParty, PartyMenu = pcall(require, "src.ui.gen2.PartyMenu")
  local okChrome, Chrome = pcall(require, "src.ui.gen2.Chrome")
  if not okParty or type(PartyMenu) ~= "table"
      or not okChrome or type(Chrome) ~= "table" then
    mod.log:warn("Scrollable Gen 2 submenu renderer unavailable; RENAME will still be inserted")
    return false
  end

  local sentinel = "__pokemonmod_gen2_nickname_scroll_v1"
  if PartyMenu[sentinel] then return true end
  if type(PartyMenu.drawSubmenu) ~= "function"
      or type(PartyMenu.submenuTop) ~= "function"
      or type(PartyMenu.submenuLabelCoord) ~= "function" then
    mod.log:warn("Gen 2 PartyMenu layout API changed; cannot install RENAME scrolling renderer")
    return false
  end

  local previousDrawSubmenu = PartyMenu.drawSubmenu

  -- Native coordinates from Gen 2 MonSubmenu.  We keep exactly the original
  -- eight-row geometry; only the source slice of menu.items changes.
  local SUBMENU_LEFT = 6
  local SUBMENU_RIGHT = 19
  local SUBMENU_BOTTOM = 17

  PartyMenu.drawSubmenu = function(self)
    local menu = self and self.submenu
    local items = menu and menu.items

    if not menu or menu.battle or type(items) ~= "table"
        or #items <= MAX_VISIBLE_SUBMENU_ROWS then
      return previousDrawSubmenu(self)
    end

    local total = #items
    local index = tonumber(menu.index) or 1
    index = math.max(1, math.min(index, total))

    local scroll = tonumber(menu._pokemonmodNicknameScroll) or 0
    if index <= scroll then
      scroll = index - 1
    elseif index > scroll + MAX_VISIBLE_SUBMENU_ROWS then
      scroll = index - MAX_VISIBLE_SUBMENU_ROWS
    end
    scroll = math.max(0, math.min(scroll, total - MAX_VISIBLE_SUBMENU_ROWS))
    menu._pokemonmodNicknameScroll = scroll

    local count = MAX_VISIBLE_SUBMENU_ROWS
    local top = PartyMenu.submenuTop(count)
    Chrome.box(
      SUBMENU_LEFT,
      top,
      SUBMENU_RIGHT - SUBMENU_LEFT + 1,
      SUBMENU_BOTTOM - top + 1
    )

    for visibleRow = 1, count do
      local item = items[scroll + visibleRow]
      if not item then break end
      local tx, ty = PartyMenu.submenuLabelCoord(count, visibleRow)
      if scroll + visibleRow == index then
        Chrome.cursor(tx - 1, ty)
      end
      Chrome.print(item.label or item.id or "?", tx, ty)
    end
  end

  PartyMenu[sentinel] = true
  return true
end

return function(mod)
  installScrollableGen2Submenu(mod)

  local function openNamingScreen(game, mon)
    if not (game and game.stack and mon) then return end
    if mon.isEgg then return end

    local shownSpecies = speciesName(game, mon)
    local oldNickname = mon.nickname

    -- Gen 2's native screen does not pop itself on END; callers own the
    -- continuation. An empty result means "keep the current name" here.
    mod.ui.push(game, "Gen2NamingScreen", {
      type = "nickname",
      monName = shownSpecies,
      maxLength = 10,
      initial = oldNickname or "",
      iconPath = iconPathFor(game, mon),
      onDone = function(name)
        if game.stack and game.stack.top and game.stack:top() then
          game.stack:pop()
        end

        if type(name) ~= "string" or #name == 0 then
          return
        end

        mon.nickname = name
        mod.log:info(
          "Renamed %s to %s",
          tostring(shownSpecies),
          tostring(name)
        )
      end,
    })
  end

  -- A very high hook priority makes this wrapper run outside ordinary submenu
  -- injectors. Because it calls next() first, it sees their finished list and
  -- can decline to add a second RENAME row when one already exists.
  mod.hooks:wrap("ui.party.submenu", function(nextFn, game, items, mon, ctx)
    items = nextFn(game, items, mon, ctx)

    if type(items) ~= "table" then
      return items
    end

    -- RENAME is a field convenience only. Gold's battle submenu is a separate
    -- SWITCH / STATS / CANCEL list marked by ctx.battle.
    if (ctx and ctx.battle) or not mon or mon.isEgg then
      return items
    end

    for _, item in ipairs(items) do
      if isRenameEntry(item) then
        return items
      end
    end

    -- Always insert RENAME.  When the resulting field menu exceeds eight rows,
    -- installScrollableGen2Submenu keeps every action reachable by scrolling.
    mod.ui.insertAfter(items, "STATS", {
      id = ENTRY_ID,
      label = "RENAME",
      onSelect = function(selectedMon, selectedGame)
        openNamingScreen(selectedGame or game, selectedMon or mon)
      end,
    })

    return items
  end, 1000000)

  mod.exports.version = VERSION
  mod.exports.rename = function(game, mon)
    openNamingScreen(game, mon)
  end
end
