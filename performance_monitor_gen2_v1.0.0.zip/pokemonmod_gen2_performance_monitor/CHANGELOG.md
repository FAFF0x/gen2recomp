# Changelog

## 1.0.0

- New Gen 2-only port.
- Added `games: ["gen2"]`.
- Changed manifest id to `pokemonmod_gen2_performance_monitor` so it is distinct from the original `performance_monitor`.
- Moved report-path hints to this mod's unique storage namespace.
- Namespaced runtime instrumentation markers to avoid colliding with the original implementation's marker fields.
- Updated diagnostic report identity to `pokemon-recomp-gen2-performance-report`.
- Kept the current sandbox-safe `mod.storage` JSON/TXT export path.
- Preserved FPS, frame-time, renderer, memory, hook/event attribution, slow-frame correlation and diagnostic capture features.
