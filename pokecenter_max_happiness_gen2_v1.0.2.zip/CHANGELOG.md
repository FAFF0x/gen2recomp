# Changelog

## 1.0.2
- FIX: manifest now uses `games: ["gen2"]`, the field the multi-generation launcher actually uses.
- FIX: removes reliance on the ignored `generation: 2` field.
- FIX: replaces the incorrect `g2_heal_party` hook with the real Gen 2 `World:healParty()` path.
- Happiness is set to 255 only for heals occurring inside Pokemon Center interiors.
- Eggs are excluded.
- Whiteout, Mom, Sacred Ash, Battle Tower and other non-Center heals remain vanilla.

## 1.0.1
- Incorrect attempt to classify the mod as Gen 2 using `generation: 2`.
- Incorrectly targeted a Gen2Recomped command path not used by this multi-generation runtime.

## 1.0.0
- Initial release.
