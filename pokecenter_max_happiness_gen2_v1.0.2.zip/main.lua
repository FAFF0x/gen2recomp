-- Pokecenter Max Happiness Gen 2 v1.0.2
--
-- Target: gen1recomp multi-generation runtime.
--
-- IMPORTANT:
-- * `games = ["gen2"]` in manifest.json is the actual launcher/loader target.
-- * Gold/Silver/Crystal use the Gen 2 HealParty special, which calls
--   src.world.gen2.World:healParty().
--
-- This mod wraps that real Gen 2 heal function, preserves the vanilla heal,
-- then sets happiness to 255 only when the heal happened inside a Pokemon
-- Center. Other HealParty uses (whiteout, Mom, Sacred Ash, Battle Tower, etc.)
-- remain vanilla.

local World = require("src.world.gen2.World")
local Breeding = require("src.core.gen2.Breeding")

local originalHealParty = World.healParty

local function isPokemonCenter(world)
  local map = world and world.map
  local def = map and map.def
  if not def then return false end

  -- Gen 2's own whiteout-spawn rule uses this same tileset test to identify
  -- Pokemon Center interiors.
  if def.environment == "INDOOR"
      and def.tileset == "TILESET_POKECENTER" then
    return true
  end

  -- Defensive fallback for custom caches / map packs that preserve the map id
  -- but alter the tileset metadata.
  local id = tostring(def.id or map.id or ""):upper()
  return id:find("POKECENTER", 1, true) ~= nil
      or id:find("POKEMON_CENTER", 1, true) ~= nil
end

local function maximizeParty(save)
  local changed = 0
  for _, mon in ipairs((save and save.party) or {}) do
    -- Eggs carry hatch data and are intentionally excluded.
    if type(mon) == "table" and not Breeding.isEgg(mon) then
      if mon.happiness ~= 255 then changed = changed + 1 end
      mon.happiness = 255
    end
  end
  return changed
end

return function(mod)
  if type(originalHealParty) ~= "function" then
    error("Gen 2 World:healParty() was not found")
  end

  -- This mod is loaded only for `games = ["gen2"]`, so patching the Gen 2
  -- World class cannot affect Red/Blue/Yellow.
  World.healParty = function(self, ...)
    -- Always preserve the engine's native Gen 2 healing first.
    local result = originalHealParty(self, ...)

    -- Only a heal performed while physically inside a Pokemon Center grants
    -- maximum happiness.
    if isPokemonCenter(self) then
      local save = self.game and self.game.save
      local changed = maximizeParty(save)
      local mapId = self.map and self.map.def and self.map.def.id
      mod.log:info(
        "Pokemon Center heal on %s: happiness set to 255 (%d changed)",
        tostring(mapId or "?"), changed
      )
    end

    return result
  end

  mod.exports.maximizePartyHappiness = function(save)
    return maximizeParty(save or (mod.game and mod.game.save))
  end

  mod.log:info("Installed Gen 2 Pokemon Center heal -> max happiness hook")
end
