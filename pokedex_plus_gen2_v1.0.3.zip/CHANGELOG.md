# Changelog

## 1.0.3

- Fixed START/GO name search results being obscured by the still-open opaque keyboard screen.
- The name-search keyboard now closes before the filtered result ListMenu is pushed; B from results returns to the SEARCH POKéMON menu.
- Added explicit species/dex/icon/caught presentation metadata to main and filtered Pokédex rows for Modern UI integrations.
- Kept all search filtering data-driven against the final merged Gen 2 `game.data.pokemon` registry.

## 1.0.2

- Added semantic screen IDs for Pokédex+ main/search lists.
- Added public species/seen/caught row metadata for UI integrations.
- Gen2 Modern UI v1.0.8 can now render row icons and the selected-Pokémon sprite preview without replacing Pokédex Plus callbacks.
- Prevented unseen-data preview leaks when reveal-unseen is disabled.

## 1.0.1

- Deduplica evoluzioni con stessa destinazione preferendo LEVEL/ITEM a TRADE.
- Mostra l'held item anche per percorsi LEVEL personalizzati.
- Compatibilità esplicita con Trade Evolution Fix - Gen 2 v1.2.0.

## 1.0.0 - Gen 2 port

- Forked the original Pokédex Plus 1.3.4 into a separate Gen 2-only mod.
- Added unique manifest ID `pokemonmod_gen2_pokedex_plus` and unique screen IDs.
- Added `games: ["gen2"]` and removed Gen 1 optional dependencies.
- Switched Pokédex ownership state from Gen 1 `owned` to Gen 2 `caught`.
- Updated base stats to six Gen 2 stats: Sp. Atk and Sp. Def are separate.
- Reworked HABITAT for Gen 2 grass/water tables and MORN/DAY/NITE rates.
- Added Gen 2 fishing-group parsing for Old, Good and Super Rod encounters.
- Updated evolution parsing for EVOLVE_LEVEL, EVOLVE_ITEM, EVOLVE_TRADE,
  EVOLVE_HAPPINESS and EVOLVE_STAT.
- Updated level-up move data to use Gen 2 `levelMoves`.
- Replaced Gen 1 DexEntry/TownMap routing with native `Gen2PokedexMenu` entry/area views.
- Removed the Gen1 Modern UI compatibility adapter and Gen 1 hard-coded special-source data.
- Added duplicate POKéDEX+ menu-row protection so parallel Pokédex replacement mods do not create two rows.
