-- Pokédex Plus - Gen 2 for Pokemon Recomp
-- Gen 2-only expanded Pokédex browser with merged-data habitat scanning,
-- six-stat base data, Gen 2 evolutions and level-up moves.

local SCREEN_ID = "PokemonModGen2PokedexPlus"
local STATS_SCREEN_ID = "PokemonModGen2PokedexPlusStats"
local HABITAT_SCREEN_ID = "PokemonModGen2PokedexPlusHabitat"
local NAME_SEARCH_SCREEN_ID = "PokemonModGen2PokedexPlusNameSearch"
local SEARCH_QUERY_LIMIT = 12

-- Gen 2 encounter slot distributions (engine/data/wild tables).
local GRASS_WEIGHTS = { 30, 30, 20, 10, 5, 4, 1 }
local WATER_WEIGHTS = { 60, 30, 10 }
local DAYTIMES = { "MORN", "DAY", "NITE" }

-- Do not carry Gen 1's hard-coded gift/static list into Gold/Silver/Crystal.
-- Wild/fishing data is read from the live merged Gen 2 registries; non-random
-- sources fall back to a neutral message instead of showing Kanto Gen 1 data.
local SPECIAL_SOURCES = {}

local function upper(value)
  return tostring(value or ""):upper()
end

local function normalizedSearch(value)
  local text = upper(value)
  text = text:gsub("é", "E"):gsub("É", "E")
  return text:gsub("[^A-Z0-9]", "")
end

local function humanize(value)
  local text = tostring(value or "UNKNOWN"):gsub("_", " ")
  text = text:gsub("POKEMON", "POKéMON")
  return text
end

local function round1(value)
  local n = math.floor((tonumber(value) or 0) * 10 + 0.5) / 10
  if n == math.floor(n) then return tostring(math.floor(n)) end
  return ("%.1f"):format(n)
end

local function scanCaught(game)
  local caught = {}
  local save = game and game.save or {}
  local dex = save.pokedex or {}

  -- Gen 2 uses `caught` (Gen 1 used `owned`). Keep the latter as a harmless
  -- fallback for imported/custom saves without making the mod Gen 1-capable.
  for species, value in pairs(dex.caught or dex.owned or {}) do
    if value then caught[species] = true end
  end

  local function visit(mon)
    if type(mon) == "table" and type(mon.species) == "string" then
      caught[mon.species] = true
    end
  end

  -- Refresh every time: Gen 2 has an active party plus multiple PC boxes.
  for _, mon in ipairs(save.party or {}) do visit(mon) end
  for _, box in ipairs(save.boxes or {}) do
    if type(box) == "table" then
      local mons = box.mons or box.pokemon or box
      if type(mons) == "table" then
        for _, mon in ipairs(mons) do visit(mon) end
      end
    end
  end

  return caught
end

local function baseStatsFor(game, species)
  local def = game and game.data and game.data.pokemon
    and game.data.pokemon[species] or {}
  local base = def.baseStats or {}
  local stats = {
    hp = tonumber(base.hp) or 0,
    attack = tonumber(base.attack) or 0,
    defense = tonumber(base.defense) or 0,
    speed = tonumber(base.speed) or 0,
    specialAttack = tonumber(base.specialAttack or base.spAttack) or 0,
    specialDefense = tonumber(base.specialDefense or base.spDefense) or 0,
  }
  stats.total = stats.hp + stats.attack + stats.defense + stats.speed
    + stats.specialAttack + stats.specialDefense

  local types = {}
  if type(def.types) == "table" then
    for _, typeId in ipairs(def.types) do
      if typeId and typeId ~= "" then types[#types + 1] = humanize(typeId) end
    end
  else
    if def.type1 then types[#types + 1] = humanize(def.type1) end
    if def.type2 and def.type2 ~= def.type1 then
      types[#types + 1] = humanize(def.type2)
    end
  end
  stats.types = #types > 0 and table.concat(types, "/") or "UNKNOWN"
  return stats
end

local function dexState(game)
  local dex = game and game.save and game.save.pokedex or {}
  return dex.seen or {}, dex.caught or dex.owned or {}
end

local function allSpecies(game)
  local rows = {}
  for id, def in pairs(game.data.pokemon or {}) do
    if type(def) == "table" and def.dex then
      -- `dex` remains the engine's unique numeric species slot. Mods may add
      -- player-facing grouping metadata without creating duplicate numeric
      -- dex ids, which stock gen1recomp cannot represent safely.
      local internalDex = tonumber(def.dex) or 9999
      local displayDex = tonumber(def.dexDisplay) or internalDex
      local variant = upper(def.dexVariant)
      local variantOrder = tonumber(def.dexVariantOrder)
      if variantOrder == nil then variantOrder = variant ~= "" and 1 or 0 end

      rows[#rows + 1] = {
        id = id,
        name = def.name or id,
        dex = displayDex,
        internalDex = internalDex,
        variant = variant,
        variantOrder = variantOrder,
        def = def,
      }
    end
  end
  table.sort(rows, function(a, b)
    if a.dex ~= b.dex then return a.dex < b.dex end
    if a.variantOrder ~= b.variantOrder then
      return a.variantOrder < b.variantOrder
    end
    if a.variant ~= b.variant then return a.variant < b.variant end
    if a.internalDex ~= b.internalDex then return a.internalDex < b.internalDex end
    return a.id < b.id
  end)
  return rows
end

local function dexNumber(row, digits)
  if row.variant and row.variant ~= "" then
    -- Regional-style sub-entries intentionally use the compact `95C` form
    -- instead of padding to `095C`, matching the variant suffix requested by
    -- content mods while keeping long species names within the list width.
    return tostring(row.dex) .. row.variant
  end
  return (("%0" .. tostring(digits or 3) .. "d"):format(row.dex))
end

local function typeIdsFor(def)
  local out, seen = {}, {}
  local function add(typeId)
    if typeId and typeId ~= "" and not seen[typeId] then
      seen[typeId] = true
      out[#out + 1] = typeId
    end
  end
  if type(def and def.types) == "table" then
    for _, typeId in ipairs(def.types) do add(typeId) end
  else
    add(def and def.type1)
    add(def and def.type2)
  end
  return out
end

local function isVisibleSpecies(mod, game, row, caught)
  if mod.options:get("reveal_unseen") ~= false then return true end
  local seen, caughtDex = dexState(game)
  return seen[row.id] or caughtDex[row.id] or caught[row.id] or false
end

local function mapName(game, mapId)
  local maps = game and game.data and game.data.maps or {}
  local map = maps and maps[mapId] or nil
  local landmarkId = type(map) == "table" and (map.landmark or map.landmarkId) or nil
  local landmarkTables = {
    game and game.data and game.data.gen2Landmarks,
    game and game.data and game.data.landmarks,
  }
  for _, root in ipairs(landmarkTables) do
    if type(root) == "table" then
      local entries = root.landmarks or root
      local lm = landmarkId and entries and (entries[landmarkId] or entries[tonumber(landmarkId)])
      if type(lm) == "table" and lm.name then
        return tostring(lm.name):gsub("\n", " ")
      end
    end
  end
  return humanize(mapId)
end

local function addHabitat(rows, game, mapId, method, time, condition, slotChance,
                          minLevel, maxLevel, overallChance)
  if not slotChance or slotChance <= 0 then return end
  rows[#rows + 1] = {
    mapId = mapId,
    map = mapName(game, mapId),
    method = method,
    time = time or "ANY TIME",
    condition = condition or "NONE",
    slotChance = slotChance,
    stepChance = overallChance,
    minLevel = minLevel,
    maxLevel = maxLevel,
  }
end

local function slotMatches(list, species, weights)
  local chance, minLevel, maxLevel = 0, nil, nil
  for i, slot in ipairs(list or {}) do
    if type(slot) == "table" and slot.species == species then
      chance = chance + (weights[i] or 0)
      local level = tonumber(slot.level)
      if level then
        minLevel = minLevel and math.min(minLevel, level) or level
        maxLevel = maxLevel and math.max(maxLevel, level) or level
      end
    end
  end
  return chance, minLevel, maxLevel
end

local function fishMatches(list, species)
  local out = {}
  local previous = 0
  for _, entry in ipairs(list or {}) do
    if type(entry) == "table" then
      local cumulative = tonumber(entry.chance) or previous
      local width = math.max(0, cumulative - previous)
      previous = cumulative
      local pct = width / 255 * 100
      if entry.timeGroup and (entry.day or entry.nite) then
        if entry.day and entry.day.species == species then
          out[#out + 1] = { chance = pct, level = tonumber(entry.day.level), time = "MORN/DAY" }
        end
        if entry.nite and entry.nite.species == species then
          out[#out + 1] = { chance = pct, level = tonumber(entry.nite.level), time = "NITE" }
        end
      elseif entry.species == species then
        out[#out + 1] = { chance = pct, level = tonumber(entry.level), time = "ANY TIME" }
      end
    end
  end
  return out
end

local function habitatsFor(game, species)
  local rows = {}
  local data = game and game.data or {}
  local encounters = data.encounters or {}

  -- Gen 2 grass tables: one 7-slot list and encounter-rate byte per time band.
  for mapId, encounter in pairs(encounters.grass or {}) do
    if type(encounter) == "table" then
      for _, time in ipairs(DAYTIMES) do
        local chance, minLevel, maxLevel = slotMatches(
          encounter.slots and encounter.slots[time], species, GRASS_WEIGHTS)
        local rate = tonumber(encounter.rates and encounter.rates[time])
        local overall = rate and (rate / 256) * (chance / 100) * 100 or nil
        addHabitat(rows, game, mapId, "TALL GRASS", time, "NONE",
          chance, minLevel, maxLevel, overall)
      end
    end
  end

  -- Gen 2 surfing tables: 60/30/10 slots and one encounter-rate byte.
  for mapId, encounter in pairs(encounters.water or {}) do
    if type(encounter) == "table" then
      local chance, minLevel, maxLevel = slotMatches(encounter.slots, species, WATER_WEIGHTS)
      local rate = tonumber(encounter.rate)
      local overall = rate and (rate / 256) * (chance / 100) * 100 or nil
      addHabitat(rows, game, mapId, "SURF", "ANY TIME", "NONE",
        chance, minLevel, maxLevel, overall)
    end
  end

  -- Fishing groups are attached to maps in Gen 2. Each rod list stores
  -- cumulative probabilities and can contain day/night time-group entries.
  local rodNames = { old = "OLD ROD", good = "GOOD ROD", super = "SUPER ROD" }
  for mapId, map in pairs(data.maps or {}) do
    if type(map) == "table" and map.fishGroup then
      local group = (encounters.fishGroups or {})[map.fishGroup]
      if type(group) == "table" then
        for rodId, method in pairs(rodNames) do
          for _, hit in ipairs(fishMatches(group[rodId], species)) do
            local bite = tonumber(group.chance)
            local overall = bite and (bite / 255) * (hit.chance / 100) * 100 or nil
            addHabitat(rows, game, mapId, method, hit.time, "FISHING",
              hit.chance, hit.level, hit.level, overall)
          end
        end
      end
    end
  end

  table.sort(rows, function(a, b)
    if a.map ~= b.map then return a.map < b.map end
    if a.method ~= b.method then return a.method < b.method end
    return tostring(a.time) < tostring(b.time)
  end)
  return rows
end

local function describeEvolution(game, evo)
  if type(evo) ~= "table" then return "UNKNOWN" end
  local method = evo.method
  if method == "EVOLVE_LEVEL" or method == "LEVEL" then
    local text = "LEVEL " .. tostring(evo.level or "?")
    if evo.item then
      local item = game.data.items and game.data.items[evo.item]
      text = text .. " + " .. ((item and item.name) or humanize(evo.item))
    end
    return text
  elseif method == "EVOLVE_ITEM" or method == "ITEM" then
    local item = game.data.items and game.data.items[evo.item]
    return (item and item.name) or humanize(evo.item or "ITEM")
  elseif method == "EVOLVE_TRADE" or method == "TRADE" then
    if evo.item then
      local item = game.data.items and game.data.items[evo.item]
      return "TRADE + " .. ((item and item.name) or humanize(evo.item))
    end
    return "TRADE"
  elseif method == "EVOLVE_HAPPINESS" then
    local time = evo.time and (" / " .. humanize(evo.time)) or ""
    return "HAPPINESS" .. time
  elseif method == "EVOLVE_STAT" then
    local cmp = tostring(evo.comparison or "STAT"):gsub("_", " ")
    return "LEVEL " .. tostring(evo.level or "?") .. " / " .. cmp
  end
  return humanize(method or "SPECIAL")
end

local function evolutionMethodRank(evo)
  local method = evo and evo.method
  -- When two rows lead to the same target (for example Trade Evolution Fix
  -- keeps the vanilla TRADE row and adds a solo LEVEL row), show the practical
  -- non-trade route in Pokédex Plus instead of listing the same evolution twice.
  if method == "EVOLVE_LEVEL" or method == "LEVEL" then return 1 end
  if method == "EVOLVE_ITEM" or method == "ITEM" then return 2 end
  if method == "EVOLVE_HAPPINESS" or method == "EVOLVE_STAT" then return 3 end
  if method == "EVOLVE_TRADE" or method == "TRADE" then return 9 end
  return 5
end

local function preferredEvolutionRows(list)
  local best = {}
  local order = {}
  for _, evo in ipairs(list or {}) do
    local target = evo.into or evo.species
    if target then
      local current = best[target]
      if not current then
        best[target] = evo
        order[#order + 1] = target
      elseif evolutionMethodRank(evo) < evolutionMethodRank(current) then
        best[target] = evo
      end
    end
  end

  local rows = {}
  for _, target in ipairs(order) do
    rows[#rows + 1] = best[target]
  end
  return rows
end

local function evolutionsFor(game, species)
  local rows = {}
  local pokemon = game.data.pokemon or {}
  local def = pokemon[species] or {}

  for _, evo in ipairs(preferredEvolutionRows(def.evolutions)) do
    local targetId = evo.into or evo.species
    if targetId then
      local target = pokemon[targetId]
      rows[#rows + 1] = {
        direction = "TO", species = targetId,
        name = target and target.name or targetId,
        method = describeEvolution(game, evo),
      }
    end
  end

  for sourceId, source in pairs(pokemon) do
    if type(source) == "table" then
      for _, evo in ipairs(preferredEvolutionRows(source.evolutions)) do
        if (evo.into or evo.species) == species then
          rows[#rows + 1] = {
            direction = "FROM", species = sourceId,
            name = source.name or sourceId,
            method = describeEvolution(game, evo),
          }
        end
      end
    end
  end

  table.sort(rows, function(a, b)
    if a.direction ~= b.direction then return a.direction < b.direction end
    return a.name < b.name
  end)
  return rows
end

local function specialSourcesFor(game, species)
  local out = {}
  for _, text in ipairs(SPECIAL_SOURCES[species] or {}) do out[#out + 1] = text end
  if #out == 0 and #habitatsFor(game, species) == 0 then
    local incoming = evolutionsFor(game, species)
    local hasIncoming = false
    for _, evo in ipairs(incoming) do
      if evo.direction == "FROM" then hasIncoming = true break end
    end
    if hasIncoming then
      out[#out + 1] = "Usually obtained through EVOLUTION."
    else
      out[#out + 1] = "No normal wild area is registered. Check gifts, trades, static encounters or enabled mods."
    end
  end
  return out
end

local function showText(game, text)
  local TextBox = require("src.render.TextBox")
  game.stack:push(TextBox.new(game, text))
end

local function pushVanilla(game, id, ...)
  local Screens = require("src.ui.Screens")
  return Screens.push(game, id, ...)
end

-- Open the native Gen 2 Pokédex directly on a species. The builtin Gen 2
-- screen owns its PAGE/AREA/CRY behavior; the callback is required because its
-- close method deliberately delegates stack ownership to the caller.
local function pushDexData(game, species, area)
  local screen
  screen = pushVanilla(game, "Gen2PokedexMenu", {
    entrySpecies = species,
    onClose = function()
      if game.stack and type(game.stack.top) == "function"
          and game.stack:top() == screen then
        game.stack:pop()
      end
    end,
  })
  if area and screen then
    screen.view = "area"
    screen.areaRegion = nil
  end
  return screen
end

local function habitatDetails(game, row)
  local levels = "VARIES"
  if row.minLevel then
    levels = row.minLevel == row.maxLevel and tostring(row.minLevel)
      or (tostring(row.minLevel) .. "-" .. tostring(row.maxLevel))
  end
  local step = row.stepChance and (round1(row.stepChance) .. "%") or "N/A"
  showText(game,
    row.map .. "\n" .. row.method
    .. "\fSLOT CHANCE\n" .. round1(row.slotChance) .. "%\nLEVEL " .. levels
    .. "\fPER STEP\n" .. step .. "\nTIME " .. row.time
    .. "\fCONDITION\n" .. row.condition)
end

local function dropLastUtf8(text)
  local i = #text
  if i == 0 then return text end
  while i > 1 do
    local b = text:byte(i)
    if not b or b < 128 or b >= 192 then break end
    i = i - 1
  end
  return text:sub(1, i - 1)
end

local function fitText(Font, text, maxWidth)
  text = tostring(text or "")
  if Font.width(text) <= maxWidth then return text end
  local suffix = ".."
  while text ~= "" and Font.width(text .. suffix) > maxWidth do
    text = dropLastUtf8(text)
  end
  return text .. suffix
end

local function pressSound(game)
  if game and game.data then
    require("src.core.Sound").play(game.data, "Press_AB")
  end
end

local HabitatScreen = {}
HabitatScreen.__index = HabitatScreen
HabitatScreen.isOpaque = true


function HabitatScreen.new(game, opts)
  opts = opts or {}
  local species = opts.species or opts[1]
  local def = game.data.pokemon[species] or { name = species }
  local entries = {}
  for _, row in ipairs(habitatsFor(game, species)) do
    entries[#entries + 1] = { kind = "habitat", row = row }
  end
  for _, source in ipairs(specialSourcesFor(game, species)) do
    entries[#entries + 1] = { kind = "special", text = source }
  end
  if #entries == 0 then
    entries[1] = { kind = "special", text = "No habitat data is available." }
  end
  return setmetatable({
    game = game,
    species = species,
    name = def.name or species,
    entries = entries,
    index = 1,
    rowsPerPage = 3,
  }, HabitatScreen)
end

function HabitatScreen:pageCount()
  return math.max(1, math.ceil(#self.entries / self.rowsPerPage))
end

function HabitatScreen:page()
  return math.floor((self.index - 1) / self.rowsPerPage) + 1
end

function HabitatScreen:move(delta)
  local n = #self.entries
  self.index = math.max(1, math.min(n, self.index + delta))
end

function HabitatScreen:jumpPage(delta)
  local target = self.index + delta * self.rowsPerPage
  self.index = math.max(1, math.min(#self.entries, target))
end

function HabitatScreen:update()
  local input = self.game.input
  if input:wasPressed("b") then
    pressSound(self.game)
    self.game.stack:pop()
  elseif input:wasPressed("up") then
    self:move(-1)
  elseif input:wasPressed("down") then
    self:move(1)
  elseif input:wasPressed("left") then
    self:jumpPage(-1)
  elseif input:wasPressed("right") then
    self:jumpPage(1)
  elseif input:wasPressed("start") then
    pressSound(self.game)
    pushDexData(self.game, self.species, true)
  elseif input:wasPressed("a") then
    pressSound(self.game)
    local entry = self.entries[self.index]
    if entry.kind == "habitat" then
      habitatDetails(self.game, entry.row)
    else
      showText(self.game, entry.text)
    end
  end
end

function HabitatScreen:draw()
  local Font = require("src.render.Font")
  local Theme = require("src.ui.Theme")
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.rectangle("fill", 0, 0, 160, 144)
  love.graphics.setColor(0, 0, 0, 1)

  local page, pages = self:page(), self:pageCount()
  local pageText = ("%d/%d"):format(page, pages)
  Font.draw(fitText(Font, self.name .. " HABITAT", 120), 8, 4)
  Font.draw(pageText, 152 - Font.width(pageText), 4)

  local first = (page - 1) * self.rowsPerPage + 1
  for rowIndex = 0, self.rowsPerPage - 1 do
    local entryIndex = first + rowIndex
    local entry = self.entries[entryIndex]
    if not entry then break end
    local y = 24 + rowIndex * 34
    if entryIndex == self.index then
      Font.drawCode(Theme.cursor, 0, y)
    end
    if entry.kind == "habitat" then
      local h = entry.row
      local levels = "VARIES"
      if h.minLevel then
        levels = h.minLevel == h.maxLevel and tostring(h.minLevel)
          or (tostring(h.minLevel) .. "-" .. tostring(h.maxLevel))
      end
      Font.draw(fitText(Font, h.map, 144), 12, y)
      Font.draw(fitText(Font, h.method, 144), 12, y + 10)
      local chance = "SLOT " .. round1(h.slotChance) .. "%  LV " .. levels
      Font.draw(fitText(Font, chance, 144), 12, y + 20)
    else
      Font.draw("SPECIAL SOURCE", 12, y)
      Font.draw("PRESS A FOR DETAILS", 12, y + 10)
      Font.draw("NOT A RANDOM ENCOUNTER", 12, y + 20)
    end
  end

  Font.draw("A DETAILS  START MAP", 8, 130)
  love.graphics.setColor(1, 1, 1, 1)
end

local function openHabitat(mod, game, species)
  mod.ui.push(game, HABITAT_SCREEN_ID, { species = species })
end

local function openEvolution(mod, game, species)
  local def = game.data.pokemon[species] or { name = species }
  local rows = evolutionsFor(game, species)
  local items = {}
  for _, evo in ipairs(rows) do
    -- Keep the method off the right column: long species names plus long
    -- methods overlapped in v1.0.0. Selecting the row opens a clean detail
    -- page instead.
    items[#items + 1] = {
      label = evo.direction .. " " .. evo.name,
      value = evo,
    }
  end
  if #items == 0 then
    items[1] = { label = "NO EVOLUTION" }
  end
  game.stack:push(mod.ui.ListMenu.new(game, def.name .. " EVO", items, {
    pageJump = true,
    keyRepeat = true,
    onChoose = function(item)
      local evo = item.value
      if not evo then return end
      showText(game,
        "EVOLUTION " .. evo.direction .. "\n" .. evo.name
        .. "\fMETHOD\n" .. evo.method)
    end,
  }))
end

local function moveDetails(game, moveId)
  local move = game.data.moves and game.data.moves[moveId] or {}
  local power = tonumber(move.power) or 0
  local accuracy = tonumber(move.accuracy)
  if accuracy and accuracy > 100 then accuracy = math.floor(accuracy * 100 / 255 + 0.5) end
  showText(game,
    (move.name or moveId) .. "\nTYPE " .. humanize(move.type or "?")
    .. "\fPOWER " .. (power > 0 and tostring(power) or "STATUS")
    .. "\nACCURACY " .. (accuracy and (tostring(accuracy) .. "%") or "--")
    .. "\fPP " .. tostring(move.pp or "--"))
end

local function openMoves(mod, game, species)
  local def = game.data.pokemon[species] or { name = species, levelMoves = {} }
  local learnset = {}
  for _, entry in ipairs(def.levelMoves or def.learnset or {}) do
    learnset[#learnset + 1] = { level = tonumber(entry.level) or 0, move = entry.move }
  end
  table.sort(learnset, function(a, b)
    if a.level ~= b.level then return a.level < b.level end
    return tostring(a.move) < tostring(b.move)
  end)
  local items = {}
  for _, entry in ipairs(learnset) do
    local move = game.data.moves and game.data.moves[entry.move]
    items[#items + 1] = {
      label = move and move.name or entry.move,
      right = entry.level <= 1 and "START" or ("Lv%02d"):format(entry.level),
      value = entry.move,
    }
  end
  if #items == 0 then items[1] = { label = "NO LEVEL MOVES", right = "--" } end
  game.stack:push(mod.ui.ListMenu.new(game, def.name .. " MOVES", items, {
    pageJump = true,
    keyRepeat = true,
    onChoose = function(item)
      if item.value then moveDetails(game, item.value) end
    end,
  }))
end

local StatsScreen = {}
StatsScreen.__index = StatsScreen
StatsScreen.isOpaque = true


function StatsScreen.new(game, opts)
  opts = opts or {}
  local species = opts.species or opts[1]
  local def = game.data.pokemon[species] or { name = species }
  return setmetatable({
    game = game,
    species = species,
    name = def.name or species,
    stats = baseStatsFor(game, species),
  }, StatsScreen)
end

function StatsScreen:update()
  local input = self.game.input
  if input:wasPressed("a") or input:wasPressed("b") then
    pressSound(self.game)
    self.game.stack:pop()
  end
end

function StatsScreen:draw()
  local Font = require("src.render.Font")
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.rectangle("fill", 0, 0, 160, 144)
  love.graphics.setColor(0, 0, 0, 1)

  Font.draw(fitText(Font, self.name, 144), 8, 4)
  Font.draw("BASE STATS", 8, 16)
  Font.draw("TYPE", 8, 30)
  Font.draw(fitText(Font, self.stats.types, 104), 48, 30)

  local labels = {
    { "HP", self.stats.hp },
    { "ATTACK", self.stats.attack },
    { "DEFENSE", self.stats.defense },
    { "SPEED", self.stats.speed },
    { "SP.ATK", self.stats.specialAttack },
    { "SP.DEF", self.stats.specialDefense },
    { "TOTAL", self.stats.total },
  }
  for i, row in ipairs(labels) do
    local y = 42 + (i - 1) * 12
    Font.draw(row[1], 16, y)
    local value = ("%03d"):format(row[2])
    Font.draw(value, 144 - Font.width(value), y)
  end

  Font.draw("A/B BACK", 8, 132)
  love.graphics.setColor(1, 1, 1, 1)
end

local function openStats(mod, game, species)
  mod.ui.push(game, STATS_SCREEN_ID, { species = species })
end

local function openDetails(mod, game, species)
  local def = game.data.pokemon[species]
  if not def then return end
  local items = {
    { label = "DATA", on = function()
        local seen, caught = dexState(game)
        local reveal = mod.options:get("reveal_unseen") ~= false
        if reveal or caught[species] or seen[species] then
          pushDexData(game, species, false)
        else
          showText(game, "Data unknown.\nSee this POKéMON first.")
        end
      end },
    { label = "STATS", on = function() openStats(mod, game, species) end },
    { label = "HABITAT", on = function() openHabitat(mod, game, species) end },
    { label = "EVOLUTION", on = function() openEvolution(mod, game, species) end },
    { label = "LEVEL MOVES", on = function() openMoves(mod, game, species) end },
    { label = "AREA MAP", on = function()
        pushDexData(game, species, true)
      end },
    { label = "CRY", on = function()
        require("src.core.Sound").playCry(game.data, species)
      end },
    { label = "BACK", back = true },
  }
  local rows = {}
  for _, item in ipairs(items) do rows[#rows + 1] = { label = item.label, value = item } end
  game.stack:push(mod.ui.ListMenu.new(game, def.name, rows, {
    onChoose = function(row, menu)
      if row.value.back then menu:close() else row.value.on() end
    end,
  }))
end

local function buildSpeciesItems(mod, game, rows)
  local caught = scanCaught(game)
  local digits = (game.data.constants and game.data.constants.dexDigits) or 3
  local items = {}
  for _, row in ipairs(rows) do
    items[#items + 1] = {
      label = dexNumber(row, digits) .. " " .. row.name,
      right = caught[row.id] and "C" or nil,
      value = row.id,
      species = row.id,
      dex = row.dex,
      icon = row.def and row.def.icon or nil,
      seen = true,
      caught = caught[row.id] or nil,
      ball = caught[row.id] or nil,
    }
  end
  return items
end

local function nameSearchRows(mod, game, query)
  local caught = scanCaught(game)
  local wanted = normalizedSearch(query)
  local rows = {}
  for _, row in ipairs(allSpecies(game)) do
    if isVisibleSpecies(mod, game, row, caught) then
      local haystack = normalizedSearch((row.name or "") .. " " .. row.id)
      if wanted == "" or haystack:find(wanted, 1, true) then
        rows[#rows + 1] = row
      end
    end
  end
  return rows
end

local function typeSearchRows(mod, game, typeId)
  local caught = scanCaught(game)
  local rows = {}
  for _, row in ipairs(allSpecies(game)) do
    if isVisibleSpecies(mod, game, row, caught) then
      for _, candidate in ipairs(typeIdsFor(row.def)) do
        if candidate == typeId then
          rows[#rows + 1] = row
          break
        end
      end
    end
  end
  return rows
end

local function availableTypes(mod, game)
  local caught = scanCaught(game)
  local found = {}
  for _, row in ipairs(allSpecies(game)) do
    if isVisibleSpecies(mod, game, row, caught) then
      for _, typeId in ipairs(typeIdsFor(row.def)) do found[typeId] = true end
    end
  end
  local out = {}
  for typeId in pairs(found) do out[#out + 1] = typeId end
  table.sort(out, function(a, b) return humanize(a) < humanize(b) end)
  return out
end

local function openSearchResults(mod, game, title, rows)
  local items = buildSpeciesItems(mod, game, rows)
  if #items == 0 then items[1] = { label = "NO MATCHES" } end
  local list = mod.ui.ListMenu.new(game, title, items, {
    footer = ("RESULTS %3d"):format(#rows),
    pageJump = true,
    keyRepeat = true,
    onChoose = function(item)
      if item.value then openDetails(mod, game, item.value) end
    end,
  })
  -- Stable semantic identity for presentation mods. Input and callbacks remain
  -- owned by this ListMenu; consumers may use the marker to add icons/preview.
  list.screenId = "PokemonModGen2PokedexPlusResults"
  list._pokemonmodGen2PokedexPlus = true
  game.stack:push(list)
end

local SEARCH_KEYS = {
  { "A", "B", "C", "D", "E", "F" },
  { "G", "H", "I", "J", "K", "L" },
  { "M", "N", "O", "P", "Q", "R" },
  { "S", "T", "U", "V", "W", "X" },
  { "Y", "Z", "0", "1", "2", "3" },
  { "4", "5", "6", "7", "8", "9" },
  { "DEL", "CLR", "GO", "EXIT" },
}

local NameSearchScreen = {}
NameSearchScreen.__index = NameSearchScreen
NameSearchScreen.isOpaque = true


function NameSearchScreen.new(mod, game)
  return setmetatable({
    mod = mod,
    game = game,
    query = "",
    row = 1,
    col = 1,
  }, NameSearchScreen)
end

function NameSearchScreen:close()
  if self.game.stack:top() == self then self.game.stack:pop() end
end

function NameSearchScreen:openResults()
  -- Close the keyboard before opening the results list. Keeping this opaque
  -- custom screen under a newly pushed ListMenu made presentation mods depend
  -- on stack-draw ordering and could leave the keyboard visually covering the
  -- filtered results after START/GO. The search menu remains underneath, so B
  -- from the results still returns to a useful screen.
  local query = self.query
  local rows = nameSearchRows(self.mod, self.game, query)
  local title = query == "" and "ALL POKéMON" or ("NAME " .. query)
  self:close()
  openSearchResults(self.mod, self.game, title, rows)
end

function NameSearchScreen:activateCurrentKey()
  local key = SEARCH_KEYS[self.row] and SEARCH_KEYS[self.row][self.col]
  if not key then return false end
  if key == "DEL" then
    self.query = self.query:sub(1, -2)
  elseif key == "CLR" then
    self.query = ""
  elseif key == "GO" then
    self:openResults()
  elseif key == "EXIT" then
    self:close()
  elseif #self.query < SEARCH_QUERY_LIMIT then
    self.query = self.query .. key
  end
  return true
end

function NameSearchScreen:update()
  local input = self.game.input
  local row = SEARCH_KEYS[self.row]
  if input:wasPressed("left") then
    self.col = ((self.col - 2) % #row) + 1
  elseif input:wasPressed("right") then
    self.col = (self.col % #row) + 1
  elseif input:wasPressed("up") then
    self.row = ((self.row - 2) % #SEARCH_KEYS) + 1
    self.col = math.min(self.col, #SEARCH_KEYS[self.row])
  elseif input:wasPressed("down") then
    self.row = (self.row % #SEARCH_KEYS) + 1
    self.col = math.min(self.col, #SEARCH_KEYS[self.row])
  elseif input:wasPressed("select") then
    self.query = ""
    pressSound(self.game)
  elseif input:wasPressed("start") then
    pressSound(self.game)
    self:openResults()
  elseif input:wasPressed("b") then
    pressSound(self.game)
    if self.query ~= "" then self.query = self.query:sub(1, -2) else self:close() end
  elseif input:wasPressed("a") then
    pressSound(self.game)
    self:activateCurrentKey()
  end
end

function NameSearchScreen:draw()
  local Font = require("src.render.Font")
  local Theme = require("src.ui.Theme")
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.rectangle("fill", 0, 0, 160, 144)
  love.graphics.setColor(0, 0, 0, 1)
  Font.draw("SEARCH BY NAME", 8, 4)
  Font.draw("NAME: " .. (self.query == "" and "ALL" or self.query), 8, 18)
  Font.draw("MATCHES: " .. tostring(#nameSearchRows(self.mod, self.game, self.query)), 8, 30)
  for r, keys in ipairs(SEARCH_KEYS) do
    for c, key in ipairs(keys) do
      local x = 13 + (c - 1) * 24
      local y = 40 + (r - 1) * 12
      if r == self.row and c == self.col then Font.drawCode(Theme.cursor, x - 8, y) end
      Font.draw(key, x, y)
    end
  end
  Font.draw("A TYPE  START GO", 8, 128)
  Font.draw("B DELETE/EXIT", 8, 136)
  love.graphics.setColor(1, 1, 1, 1)
end

local function openTypeSearch(mod, game)
  local items = {}
  for _, typeId in ipairs(availableTypes(mod, game)) do
    items[#items + 1] = { label = humanize(typeId), value = typeId }
  end
  if #items == 0 then items[1] = { label = "NO TYPES" } end
  game.stack:push(mod.ui.ListMenu.new(game, "SEARCH BY TYPE", items, {
    pageJump = true,
    keyRepeat = true,
    onChoose = function(item)
      if not item.value then return end
      openSearchResults(mod, game, humanize(item.value),
        typeSearchRows(mod, game, item.value))
    end,
  }))
end

local function openSearchMenu(mod, game)
  local rows = {
    { label = "BY NAME", value = "name" },
    { label = "BY TYPE", value = "type" },
    { label = "BACK", value = "back" },
  }
  game.stack:push(mod.ui.ListMenu.new(game, "SEARCH POKéMON", rows, {
    onChoose = function(item, menu)
      if item.value == "name" then
        mod.ui.push(game, NAME_SEARCH_SCREEN_ID)
      elseif item.value == "type" then
        openTypeSearch(mod, game)
      elseif item.value == "back" then
        menu:close()
      end
    end,
  }))
end

local function buildMainList(mod, game, opts)
  opts = opts or {}
  local seen, caughtDex = dexState(game)
  local caught = scanCaught(game)
  local reveal = mod.options:get("reveal_unseen") ~= false
  local digits = (game.data.constants and game.data.constants.dexDigits) or 3
  local items, caughtCount = {}, 0

  for _, row in ipairs(allSpecies(game)) do
    if caught[row.id] then caughtCount = caughtCount + 1 end
    local known = reveal or seen[row.id] or caughtDex[row.id] or caught[row.id]
    local label = dexNumber(row, digits) .. " " .. (known and row.name or "-----")
    items[#items + 1] = {
      label = label,
      -- Keep presentation metadata public/data-only so Modern UI can show an
      -- icon and preview without taking ownership of selection or callbacks.
      right = caught[row.id] and "C" or nil,
      value = row.id,
      species = row.id,
      dex = row.dex,
      icon = row.def and row.def.icon or nil,
      seen = known,
      caught = caught[row.id] or nil,
      ball = caught[row.id] or nil,
    }
  end

  local list = mod.ui.ListMenu.new(game, "POKéDEX+", items, {
    footer = ("CAUGHT %3d"):format(caughtCount),
    pageJump = true,
    keyRepeat = true,
    onCancel = opts.onCancel,
    onChoose = function(item)
      if item.value then openDetails(mod, game, item.value) end
    end,
  })
  list.screenId = SCREEN_ID
  list._pokemonmodGen2PokedexPlus = true

  local baseUpdate = list.update
  if type(baseUpdate) == "function" then
    function list:update(dt)
      if self.game.input:wasPressed("start") then
        pressSound(self.game)
        openSearchMenu(mod, self.game)
        return
      end
      baseUpdate(self, dt)
    end
  end
  return list
end

return function(mod)
  mod.options:define({
    {
      key = "reveal_unseen",
      type = "toggle",
      label = "REVEAL UNSEEN DATA",
      default = true,
    },
  })

  mod.content.screens:register(SCREEN_ID, {
    new = function(game, opts) return buildMainList(mod, game, opts) end,
  })
  mod.content.screens:register(STATS_SCREEN_ID, {
    new = function(game, opts) return StatsScreen.new(game, opts) end,
  })
  mod.content.screens:register(HABITAT_SCREEN_ID, {
    new = function(game, opts) return HabitatScreen.new(game, opts) end,
  })
  mod.content.screens:register(NAME_SEARCH_SCREEN_ID, {
    new = function(game) return NameSearchScreen.new(mod, game) end,
  })

  -- Gen 2 StartMenu executes custom onSelect rows only when `value` is nil.
  -- Preserve the vanilla row position, but give this replacement its own
  -- collision-safe marker. If another enabled mod already owns a POKéDEX+ row,
  -- leave it alone rather than producing duplicate entries or wrapper fights.
  mod.hooks:wrap("ui.start_menu.items", function(next, game, items)
    local out = next(game, items)
    if type(out) ~= "table" then return out end

    for _, row in ipairs(out) do
      if type(row) == "table" then
        local label = normalizedSearch(row.label)
        if label == "POKEDEX" and tostring(row.label or ""):find("+", 1, true) then
          return out
        end
      end
    end

    for i, row in ipairs(out) do
      if type(row) == "table" then
        local label = normalizedSearch(row.label)
        if row.value == "pokedex" or label == "POKEDEX" then
          local replacement = {}
          for key, value in pairs(row) do replacement[key] = value end
          replacement.label = "POKéDEX+"
          replacement.value = nil
          replacement.__pokemonmodGen2PokedexPlus = true
          replacement.onSelect = function()
            mod.ui.push(game, SCREEN_ID)
          end
          out[i] = replacement
          break
        end
      end
    end
    return out
  end, 250)

  mod.exports.getHabitats = habitatsFor
  mod.exports.getEvolutions = evolutionsFor
  mod.exports.scanCaught = scanCaught
  mod.exports.getBaseStats = baseStatsFor
  mod.exports.getDexRows = allSpecies
  mod.exports.formatDexNumber = dexNumber
  mod.exports.searchByName = function(game, query) return nameSearchRows(mod, game, query) end
  mod.exports.searchByType = function(game, typeId) return typeSearchRows(mod, game, typeId) end
  mod.exports.syncCollection = function(game) return { caught = scanCaught(game) } end
  mod.exports.pokedexPlusGen2 = {
    version = "1.0.2",
    mainScreenId = SCREEN_ID,
    resultsScreenId = "PokemonModGen2PokedexPlusResults",
    semanticRows = true,
    supportsPokemonPreview = true,
  }

  mod.log:info("Pokédex Plus - Gen 2 1.0.2 loaded")
end
