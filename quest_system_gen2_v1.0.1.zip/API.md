# Quest System Gen 2 API

Locate the framework with:

```lua
local qs = assert(mod.find("pokemonmod_gen2_quest_system")).exports
```

## Registration

`qs.register(definition)` requires `id` and `title`. Optional fields: `description`, `objective`, `location`, `reward`, `source`, `progress`, `status`, `hidden`, `sort`, `markers`. Display fields may be functions receiving `(game, savedState, definition)`.

## State methods

- `start(id, patch)`
- `update(id, patch)`
- `advance(id, amount, total)`
- `complete(id, patch)`
- `fail(id, patch)`
- `track(idOrNil)`
- `remove(id)`
- `get(id)`
- `list()`
- `open(game)`

## Markers

`addMarker(questId, marker)` supports `map/mapId`, `npc/name`, `text`, `index`, `status`, `stage`, `when`, and `kind`.

## Gen2 Modern UI

The mod publishes `exports.gen2ModernUi` using compatibility API v1 when `gen2_modern_ui` is available. Quest System remains the owner of input and quest state.
