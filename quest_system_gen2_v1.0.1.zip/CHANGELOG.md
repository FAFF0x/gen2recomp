# Changelog

## 1.0.1

- Fixed a Gen 2 stack-overflow crash caused by the NPC marker draw wrapper.
- Preserve the native `NPC:draw(ox, oy, scale, oamRow)` signature.
- Convert legacy two-argument NPC draw calls directly to the native four-argument path instead of re-entering `self:draw`.
- Recover the original NPC draw method when upgrading/hot-reloading from v1.0.0.
- Isolate quest-marker drawing with `pcall` so a marker presentation failure cannot crash gameplay.
- Keep markers aligned with scaled and tilted Gen 2 overworld rendering.


## 1.0.0 - Gen 2 Pokemon MOD port

- Added explicit `games: ["gen2"]`.
- New unique mod id `pokemonmod_gen2_quest_system`.
- New unique screen id `PokemonModGen2QuestJournal`.
- Removed bundled Gen 1 story adapters and Gen 1 map/flag assumptions.
- Replaced Gen 1 Game singleton fallback with the live mod Game2 facade.
- Corrected journal close behavior for the Gen 2 Start Menu stack.
- Added Gen2 Modern UI adapter support via `gen2_modern_ui`.
- Namespaced quest notification events to the new mod id.
- Added legacy Quest System defer guard and duplicate QUESTS-row protection.
- Kept cached NPC marker rendering through the Gen 2 NPC alias.
