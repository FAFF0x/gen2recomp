-- Quest System for Pokemon Recomp Gen 2
-- Reusable quest journal, persistence API, overworld NPC markers, and Gen2 Modern UI adapter.

local MOD_ID = "pokemonmod_gen2_quest_system"
local VERSION = "1.0.1"
local SCREEN_ID = "PokemonModGen2QuestJournal"
local SAVE_KEY = "states"
local TRACKED_KEY = "tracked"
local VALID_STATUS = {
  available = true, active = true, completed = true, failed = true,
}
local STATUS_ORDER = { available = 1, active = 2, failed = 3, completed = 4 }

local runtimeGame
local definitions = {}
local markerExtras = {}
local installedAdapters = {}
local activeMod

-- Performance: NPC markers used to resolve every quest for every visible NPC
-- on every draw. On crowded maps that multiplied dynamic quest callbacks by
-- NPC count * frame rate. Keep the presentation responsive while evaluating
-- marker state at a human-scale cadence instead.
local questRevision = 0
local MARKER_CACHE_SECONDS = 0.20
local JOURNAL_CACHE_SECONDS = 0.10
local markerIndexByMap = {}
local markerWildcard = {}
local markerIndexDirty = true
local markerCache = {
  mapId = nil,
  revision = -1,
  expires = 0,
  byNpc = {},
  snapshots = {},
}

local function nowSeconds()
  if love and love.timer and love.timer.getTime then
    return love.timer.getTime()
  end
  return os.clock()
end

local function invalidateQuestCaches(rebuildMarkerIndex)
  questRevision = questRevision + 1
  markerCache.expires = 0
  markerCache.revision = -1
  markerCache.byNpc = {}
  markerCache.snapshots = {}
  if rebuildMarkerIndex then markerIndexDirty = true end
end

local function emitQuestEvent(name, payload)
  if not activeMod then return end
  local fullName = "mod." .. MOD_ID .. "." .. tostring(name)
  local ok, err = pcall(function()
    activeMod.events:emit(fullName, payload)
  end)
  if not ok and activeMod.log then
    activeMod.log:warn("could not emit %s: %s", fullName, tostring(err))
  end
end

local function resolveGame(candidate)
  if type(candidate) == "table" and candidate.game then candidate = candidate.game end
  if candidate and candidate.save and candidate.data then
    runtimeGame = candidate
    return candidate
  end
  local live = activeMod and activeMod.game or nil
  if live and live.save and live.data then
    runtimeGame = live
    return live
  end
  if runtimeGame and runtimeGame.save and runtimeGame.data then return runtimeGame end
  return nil
end

local function shallowCopy(source)
  local out = {}
  for k, v in pairs(source or {}) do out[k] = v end
  return out
end

local function clamp(value, low, high)
  value = math.floor(tonumber(value) or low)
  if value < low then return low end
  if value > high then return high end
  return value
end

local function fit(text, maxChars)
  text = tostring(text or "")
  text = text:gsub("\f", " "):gsub("\v", " "):gsub("\n", " ")
  if #text <= maxChars then return text end
  if maxChars <= 1 then return text:sub(1, maxChars) end
  return text:sub(1, maxChars - 1) .. "."
end

local function cleanText(text)
  text = tostring(text or "")
  return text:gsub("\f", " "):gsub("\v", " ")
end

local function resolve(value, game, state, def)
  if type(value) ~= "function" then return value end
  local ok, result = pcall(value, game, state, def)
  if ok then return result end
  if activeMod then activeMod.log:warn("quest resolver failed for %s: %s",
    tostring(def and def.id), tostring(result)) end
  return nil
end

local function stateRoot(mod)
  local root = mod.save:get(SAVE_KEY)
  if type(root) ~= "table" then
    root = {}
    mod.save:set(SAVE_KEY, root)
  end
  return root
end

local function savedState(mod, id, create)
  local root = stateRoot(mod)
  local state = root[id]
  if type(state) ~= "table" and create ~= false then
    state = { stage = 1 }
    root[id] = state
    mod.save:set(SAVE_KEY, root)
  end
  return state
end

local function persistState(mod, id, state)
  local root = stateRoot(mod)
  root[id] = state
  mod.save:set(SAVE_KEY, root)
end

local function effectiveStatus(game, def, state)
  local status
  if type(def.status) == "function" then
    status = resolve(def.status, game, state, def)
  else
    status = state.status or def.status
  end
  status = status or "available"
  status = tostring(status):lower()
  if not VALID_STATUS[status] then status = "available" end
  return status
end

local function progressValues(game, def, state)
  local value = type(def.progress) == "function"
    and resolve(def.progress, game, state, def) or def.progress
  local current, total, label
  if type(value) == "table" then
    current = value.current or value[1]
    total = value.total or value[2]
    label = value.label or value.text
  elseif type(value) == "number" then
    current = value
  elseif type(value) == "string" then
    label = value
  end
  if type(def.progress) ~= "function" then
    current = state.current ~= nil and state.current or current
    total = state.total ~= nil and state.total or total
    label = state.progressLabel or label
  end
  current = tonumber(current or 0) or 0
  total = tonumber(total or 1) or 1
  if total < 1 then total = 1 end
  current = math.max(0, math.min(total, current))
  label = label or (tostring(math.floor(current)) .. "/" .. tostring(math.floor(total)))
  return current, total, tostring(label)
end

local function snapshot(game, def, trackedId, trackedKnown)
  local state = savedState(activeMod, def.id)
  local currentTracked
  if trackedKnown then
    currentTracked = trackedId
  else
    currentTracked = activeMod.save:get(TRACKED_KEY)
  end
  local hidden = resolve(def.hidden, game, state, def) == true
  local current, total, progress = progressValues(game, def, state)
  local function field(name, fallback)
    local declared = def[name]
    if type(declared) == "function" then
      return resolve(declared, game, state, def) or fallback
    end
    return state[name] ~= nil and state[name] or declared or fallback
  end
  return {
    id = def.id,
    title = tostring(field("title", def.id)),
    description = cleanText(field("description", "No description available.")),
    objective = cleanText(field("objective", "No current objective.")),
    location = cleanText(field("location", "Unknown location")),
    reward = cleanText(field("reward", "Unknown reward")),
    source = tostring(resolve(def.source, game, state, def) or def.source or "Quest System"),
    status = effectiveStatus(game, def, state),
    current = current,
    total = total,
    progress = progress,
    stage = state.stage,
    tracked = currentTracked == def.id,
    hidden = hidden,
    sort = tonumber(def.sort) or 1000,
    def = def,
    state = state,
  }
end

local function allSnapshots(game)
  local out = {}
  local trackedId = activeMod.save:get(TRACKED_KEY)
  for _, def in pairs(definitions) do
    local row = snapshot(game, def, trackedId, true)
    if not row.hidden then out[#out + 1] = row end
  end
  table.sort(out, function(a, b)
    if a.tracked ~= b.tracked then return a.tracked end
    local sa, sb = STATUS_ORDER[a.status] or 99, STATUS_ORDER[b.status] or 99
    if sa ~= sb then return sa < sb end
    if a.sort ~= b.sort then return a.sort < b.sort end
    return a.title < b.title
  end)
  return out
end

local function registerQuest(def)
  if type(def) ~= "table" then return false, "quest definition must be a table" end
  local id = def.id
  if type(id) ~= "string" or id == "" then return false, "quest id is required" end
  if type(def.title) ~= "string" and type(def.title) ~= "function" then
    return false, "quest title is required"
  end
  local copy = shallowCopy(def)
  copy.id = id
  copy.markers = copy.markers or {}
  definitions[id] = copy
  invalidateQuestCaches(true)
  emitQuestEvent("registered", { id = id, quest = copy })
  return true
end

local function removeQuest(id)
  if not definitions[id] then return false end
  definitions[id] = nil
  markerExtras[id] = nil
  invalidateQuestCaches(true)
  if activeMod and activeMod.save:get(TRACKED_KEY) == id then
    activeMod.save:set(TRACKED_KEY, nil)
  end
  return true
end

local function patchQuest(id, patch)
  if not definitions[id] then return false, "unknown quest: " .. tostring(id) end
  local state = savedState(activeMod, id)
  for k, v in pairs(patch or {}) do
    if k == "status" then
      local s = tostring(v):lower()
      if VALID_STATUS[s] then state.status = s end
    else
      state[k] = v
    end
  end
  persistState(activeMod, id, state)
  invalidateQuestCaches(false)
  emitQuestEvent("changed", { id = id, state = shallowCopy(state) })
  return true
end

local function startQuest(id, patch)
  patch = shallowCopy(patch)
  patch.status = "active"
  return patchQuest(id, patch)
end

local function advanceQuest(id, amount, total)
  if not definitions[id] then return false, "unknown quest: " .. tostring(id) end
  local state = savedState(activeMod, id)
  state.current = math.max(0, (tonumber(state.current) or 0) + (tonumber(amount) or 1))
  if total ~= nil then state.total = math.max(1, tonumber(total) or 1) end
  if state.status == "available" then state.status = "active" end
  persistState(activeMod, id, state)
  invalidateQuestCaches(false)
  emitQuestEvent("changed", { id = id, state = shallowCopy(state) })
  return true
end

local function completeQuest(id, patch)
  patch = shallowCopy(patch)
  patch.status = "completed"
  local ok, err = patchQuest(id, patch)
  if ok then emitQuestEvent("completed", { id = id }) end
  return ok, err
end

local function failQuest(id, patch)
  patch = shallowCopy(patch)
  patch.status = "failed"
  return patchQuest(id, patch)
end

local function trackQuest(id)
  if id ~= nil and not definitions[id] then return false, "unknown quest" end
  activeMod.save:set(TRACKED_KEY, id)
  invalidateQuestCaches(false)
  emitQuestEvent("tracked", { id = id })
  return true
end

local function addMarker(questId, marker)
  if not definitions[questId] then return false, "unknown quest" end
  if type(marker) ~= "table" then return false, "marker must be a table" end
  markerExtras[questId] = markerExtras[questId] or {}
  markerExtras[questId][#markerExtras[questId] + 1] = shallowCopy(marker)
  invalidateQuestCaches(true)
  return true
end

local function markerGlyph(kind)
  kind = tostring(kind or "active"):lower()
  if kind == "?" or kind == "turnin" or kind == "complete" then return "?", 3 end
  if kind == "!" or kind == "available" or kind == "start" then return "!", 2 end
  return "*", 1
end

local function markerMatches(marker, mapId, npc)
  local def = npc and npc.def or {}
  local wantedMap = marker.mapId or marker.map
  if wantedMap and wantedMap ~= mapId then return false end
  local wantedNpc = marker.npc or marker.name
  if wantedNpc and wantedNpc ~= def.name and wantedNpc ~= npc.id then return false end
  if marker.text and marker.text ~= def.text then return false end
  if marker.index and marker.index ~= def.index then return false end
  return true
end

local function markerKind(game, quest, marker)
  if marker.status then
    local allowed = false
    if type(marker.status) == "table" then
      for _, s in ipairs(marker.status) do if s == quest.status then allowed = true break end end
    else
      allowed = tostring(marker.status) == quest.status
    end
    if not allowed then return nil end
  end
  if marker.stage ~= nil and marker.stage ~= quest.stage then return nil end
  local when = marker.when
  if type(when) == "function" then
    local ok, result = pcall(when, game, quest, marker)
    if not ok then
      activeMod.log:warn("quest marker failed for %s: %s", quest.id, tostring(result))
      return nil
    end
    if result == false or result == nil then return nil end
    if type(result) == "string" then return result end
  elseif when == false then
    return nil
  end
  local kind = resolve(marker.kind, game, quest.state, quest.def)
  if kind then return kind end
  if quest.status == "available" then return "available" end
  if quest.status == "active" then return "active" end
  return nil
end

local function npcMapId(npc)
  local id = npc and npc.id
  if type(id) ~= "string" then return nil end
  return id:match("^(.-)_obj_%d+$")
end

local function rebuildMarkerIndex()
  markerIndexByMap = {}
  markerWildcard = {}

  local function addRows(questId, rows)
    for _, marker in ipairs(rows or {}) do
      local mapId = marker.mapId or marker.map
      local bucket
      if mapId then
        bucket = markerIndexByMap[mapId]
        if not bucket then
          bucket = {}
          markerIndexByMap[mapId] = bucket
        end
      else
        bucket = markerWildcard
      end
      bucket[#bucket + 1] = { questId = questId, marker = marker }
    end
  end

  for questId, def in pairs(definitions) do
    addRows(questId, def.markers)
    addRows(questId, markerExtras[questId])
  end

  markerIndexDirty = false
end

local function beginMarkerCacheWindow(game, mapId)
  if markerIndexDirty then rebuildMarkerIndex() end

  local now = nowSeconds()
  if markerCache.mapId ~= mapId
      or markerCache.revision ~= questRevision
      or now >= markerCache.expires then
    markerCache.mapId = mapId
    markerCache.revision = questRevision
    markerCache.expires = now + MARKER_CACHE_SECONDS
    markerCache.byNpc = {}
    markerCache.snapshots = {}
    markerCache.trackedId = activeMod.save:get(TRACKED_KEY)
  end
end

local function cachedMarkerQuest(game, questId)
  local cached = markerCache.snapshots[questId]
  if cached ~= nil then return cached or nil end

  local def = definitions[questId]
  if not def then
    markerCache.snapshots[questId] = false
    return nil
  end

  local quest = snapshot(game, def, markerCache.trackedId, true)
  markerCache.snapshots[questId] = quest or false
  return quest
end

local function bestMarker(game, npc)
  local mapId = npcMapId(npc)
  if not mapId then return nil end

  beginMarkerCacheWindow(game, mapId)

  local npcKey = npc.id or npc
  local cached = markerCache.byNpc[npcKey]
  if cached ~= nil then
    if cached == false then return nil end
    return cached.glyph, cached.quest
  end

  local bestGlyph, bestPriority, bestQuest

  local function consider(rows)
    for _, candidate in ipairs(rows or {}) do
      local marker = candidate.marker
      if markerMatches(marker, mapId, npc) then
        local quest = cachedMarkerQuest(game, candidate.questId)
        if quest and not quest.hidden and quest.status ~= "completed" then
          local kind = markerKind(game, quest, marker)
          if kind then
            local glyph, priority = markerGlyph(kind)
            if not bestPriority or priority > bestPriority then
              bestGlyph, bestPriority, bestQuest = glyph, priority, quest
            end
          end
        end
      end
    end
  end

  consider(markerIndexByMap[mapId])
  consider(markerWildcard)

  if bestGlyph then
    markerCache.byNpc[npcKey] = { glyph = bestGlyph, quest = bestQuest }
    return bestGlyph, bestQuest
  end

  markerCache.byNpc[npcKey] = false
  return nil
end

local function wrapLines(text, width, maxLines)
  text = cleanText(text)
  local lines = {}
  for paragraph in (text .. "\n"):gmatch("(.-)\n") do
    local current = ""
    for word in paragraph:gmatch("%S+") do
      local candidate = current == "" and word or (current .. " " .. word)
      if #candidate <= width then
        current = candidate
      else
        if current ~= "" then lines[#lines + 1] = current end
        current = word
        if #lines >= maxLines then break end
      end
    end
    if current ~= "" and #lines < maxLines then lines[#lines + 1] = current end
    if #lines >= maxLines then break end
  end
  if #lines == 0 then lines[1] = "--" end
  if #lines == maxLines and #table.concat(lines, " ") < #text then
    lines[#lines] = fit(lines[#lines], math.max(1, width - 1)) .. "."
  end
  return lines
end

local function installNpcMarkers(mod)
  local NPC = require("src.world.NPC")

  -- v1.0.0 wrapped the Gen 2 NPC:draw method with a two-argument function.
  -- Gen 2's real draw(ox, oy, scale, oamRow) has a compatibility branch that
  -- calls self:draw(...) when scale is nil, so replacing self.draw with that
  -- two-argument wrapper caused infinite recursion / stack overflow.  Recover
  -- the original method first so upgrading or hot-reloading from v1.0.0 is safe.
  if NPC.__questSystemWrapped and type(NPC.__questSystemBaseDraw) == "function" then
    NPC.draw = NPC.__questSystemBaseDraw
    NPC.__questSystemWrapped = nil
    NPC.__questSystemDrawMarker = nil
  end

  if not NPC.__pokemonModGen2QuestSystemWrappedV101 then
    NPC.__pokemonModGen2QuestSystemWrappedV101 = true
    NPC.__pokemonModGen2QuestSystemBaseDrawV101 = NPC.draw

    function NPC:draw(ox, oy, scale, oamRow)
      local base = NPC.__pokemonModGen2QuestSystemBaseDrawV101
      if type(base) ~= "function" then return end

      -- Never feed the two-argument compatibility call back through the patched
      -- self:draw. Translate it to the real Gen 2 four-argument form directly.
      local drawOx, drawOy, drawScale = ox, oy, scale
      if drawScale == nil then
        drawOx, drawOy, drawScale = -(ox or 0), -(oy or 0), 1
      end
      base(self, drawOx, drawOy, drawScale, oamRow)

      local drawMarker = NPC.__pokemonModGen2QuestSystemDrawMarkerV101
      if drawMarker then
        local ok, err = pcall(drawMarker, self, drawOx, drawOy, drawScale)
        if not ok and not NPC.__pokemonModGen2QuestSystemMarkerWarnedV101 then
          NPC.__pokemonModGen2QuestSystemMarkerWarnedV101 = true
          if mod.log then
            mod.log:warn("quest NPC marker disabled after draw error: %s", tostring(err))
          end
        end
      end
    end
  end

  NPC.__pokemonModGen2QuestSystemDrawMarkerV101 = function(npc, ox, oy, scale)
    if NPC.__pokemonModGen2QuestSystemMarkerWarnedV101 then return end
    if not runtimeGame or not love or not love.graphics then return end
    local glyph = bestMarker(runtimeGame, npc)
    if not glyph then return end

    local Font = mod.ui.Font
    local G = love.graphics
    scale = tonumber(scale) or 1
    ox, oy = tonumber(ox) or 0, tonumber(oy) or 0

    -- Draw in the same local coordinate system as Gen 2's NPC renderer. This
    -- keeps the marker attached to the NPC in normal, scaled, and tilt paths.
    G.push("all")
    G.translate(ox, oy)
    G.scale(scale, scale)
    local x = math.floor((npc.px or 0) + 3)
    local y = math.floor((npc.py or 0) - 17)
    G.setColor(1, 1, 1, 1)
    G.rectangle("fill", x, y, 10, 11)
    G.setColor(0, 0, 0, 1)
    G.rectangle("line", x + 0.5, y + 0.5, 10, 11)
    Font.draw(glyph, x + 1, y + 1)
    G.pop()
  end
end

local function installAdapters(mod)
  -- Gen 2 build intentionally ships no Gen 1 story adapters.
  -- Future Gen 2 quest mods should register through this mod's public exports.
  return true
end

return function(mod)
  activeMod = mod

  -- Allow the legacy Quest System to coexist in the manager without two
  -- QUESTS rows / two NPC draw wrappers when it is force-enabled on Gen 2.
  local deferredTo
  if type(mod.find) == "function" then
    local ok, legacy = pcall(mod.find, "quest_system")
    if ok and legacy then deferredTo = "quest_system" end
  end
  mod.exports.active = deferredTo == nil
  mod.exports.deferredTo = deferredTo
  mod.exports.modId = MOD_ID
  mod.exports.version = VERSION
  if deferredTo then
    mod.log:info("Quest System Gen 2 deferred to active %s", deferredTo)
    return
  end

  local Font = mod.ui.Font
  local Theme = mod.ui.Theme

  local Journal = {}
  Journal.__index = Journal
  Journal.isOpaque = true
  Journal.screenId = SCREEN_ID

  function Journal.new(game)
    runtimeGame = resolveGame(game) or runtimeGame
    return setmetatable({
      game = game, tab = "active", index = 1, scroll = 0,
      detail = false, detailPage = 1,
      _rowsCache = nil, _rowsCacheTab = nil, _rowsCacheRevision = -1,
      _rowsCacheExpires = 0,
    }, Journal)
  end

  function Journal:rows()
    local now = nowSeconds()
    if self._rowsCache
        and self._rowsCacheTab == self.tab
        and self._rowsCacheRevision == questRevision
        and now < (self._rowsCacheExpires or 0) then
      return self._rowsCache
    end

    local rows = {}
    for _, quest in ipairs(allSnapshots(self.game)) do
      local completed = quest.status == "completed"
      if (self.tab == "completed" and completed)
          or (self.tab == "active" and not completed) then
        rows[#rows + 1] = quest
      end
    end

    self._rowsCache = rows
    self._rowsCacheTab = self.tab
    self._rowsCacheRevision = questRevision
    self._rowsCacheExpires = now + JOURNAL_CACHE_SECONDS
    return rows
  end

  function Journal:selected()
    return self:rows()[self.index]
  end

  function Journal:clamp()
    local rows = self:rows()
    self.index = clamp(self.index, 1, math.max(1, #rows))
    if self.index < self.scroll + 1 then self.scroll = self.index - 1 end
    if self.index > self.scroll + 6 then self.scroll = self.index - 6 end
    self.scroll = math.max(0, self.scroll)
  end

  function Journal:close()
    self.game.stack:pop()
  end

  function Journal:updateList(input)
    local rows = self:rows()
    if input:wasPressed("left") or input:wasPressed("right") then
      self.tab = self.tab == "active" and "completed" or "active"
      self.index, self.scroll = 1, 0
    elseif input:wasPressed("up") and #rows > 0 then
      self.index = self.index > 1 and self.index - 1 or #rows
    elseif input:wasPressed("down") and #rows > 0 then
      self.index = self.index < #rows and self.index + 1 or 1
    elseif input:wasPressed("a") and #rows > 0 then
      self.detail = true
      self.detailPage = 1
    elseif input:wasPressed("select") and #rows > 0 then
      local selected = rows[self.index]
      trackQuest(selected.tracked and nil or selected.id)
    elseif input:wasPressed("b") then
      self:close()
      return
    end
    self:clamp()
  end

  function Journal:updateDetail(input)
    if input:wasPressed("left") then
      self.detailPage = self.detailPage > 1 and self.detailPage - 1 or 2
    elseif input:wasPressed("right") or input:wasPressed("a") then
      self.detailPage = self.detailPage < 2 and self.detailPage + 1 or 1
    elseif input:wasPressed("select") then
      local selected = self:selected()
      if selected then trackQuest(selected.tracked and nil or selected.id) end
    elseif input:wasPressed("b") then
      self.detail = false
      self.detailPage = 1
    end
  end

  function Journal:update()
    local input = self.game.input
    if self.detail then self:updateDetail(input) else self:updateList(input) end
  end

  local function drawProgress(quest, y)
    -- Compact progress display: label on the left, numeric value on the right.
    local text = tostring(quest.progress or "0/1")
    local x = math.max(8, 152 - #text * 8)
    Font.draw(text, x, y)
  end

  function Journal:drawList()
    Font.draw("QUESTS", 8, 8)
    local tabLabel = self.tab == "active" and "< ACTIVE >" or "< DONE >"
    Font.draw(tabLabel, 72, 8)
    local rows = self:rows()
    if #rows == 0 then
      Font.draw(self.tab == "active" and "No active quests." or "No completed quests", 8, 56)
      Font.draw("L/R TAB B BACK", 8, 136)
      return
    end
    for row = 1, 6 do
      local i = self.scroll + row
      local quest = rows[i]
      if not quest then break end
      local y = 20 + (row - 1) * 16
      if i == self.index then Font.drawCode(Theme.cursor, 4, y) end
      local marker = quest.tracked and "*" or " "
      local status = quest.status == "available" and "NEW "
        or quest.status == "failed" and "FAIL"
        or quest.status == "completed" and "DONE" or "ACT "
      Font.draw(marker .. fit(quest.title, 13), 12, y)
      Font.draw(status, 128, y)
    end
    local selected = rows[self.index]
    if selected then
      Font.draw("PROGRESS", 8, 118)
      drawProgress(selected, 118)
    end
    Font.draw("A DETAIL SEL TRACK", 8, 136)
  end

  local function drawLines(lines, x, y, step)
    for i, line in ipairs(lines) do Font.draw(line, x, y + (i - 1) * (step or 10)) end
  end

  function Journal:drawDetail()
    local quest = self:selected()
    if not quest then self.detail = false return self:drawList() end
    Font.draw(fit(quest.title, 16), 8, 8)
    Font.draw(tostring(self.detailPage) .. "/2", 136, 8)
    Font.draw(quest.tracked and "TRACKED" or quest.status:upper(), 88, 20)

    if self.detailPage == 1 then
      Font.draw("OBJECTIVE", 8, 24)
      drawLines(wrapLines(quest.objective, 18, 3), 16, 36, 10)
      Font.draw("LOCATION", 8, 70)
      drawLines(wrapLines(quest.location, 18, 2), 16, 82, 10)
      Font.draw("PROGRESS", 8, 108)
      drawProgress(quest, 108)
    else
      Font.draw("DESCRIPTION", 8, 24)
      drawLines(wrapLines(quest.description, 18, 5), 16, 36, 10)
      Font.draw("REWARD", 8, 88)
      drawLines(wrapLines(quest.reward, 18, 3), 16, 100, 10)
      Font.draw("MOD " .. fit(quest.source, 15), 8, 130)
    end
    Font.draw("L/R PAGE SEL TRACK B", 0, 136)
  end

  function Journal:draw()
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.rectangle("fill", 0, 0, 160, 144)
    love.graphics.setColor(0, 0, 0, 1)
    if self.detail then self:drawDetail() else self:drawList() end
    love.graphics.setColor(1, 1, 1, 1)
  end

  -- Gen2 Modern UI compatibility contract (API v1).  Quest System keeps
  -- ownership of input and state; Gen2 Modern UI only receives a read-only model
  -- of the live journal and semantic pointer actions.  If Gen2 Modern UI is not
  -- installed or disabled this export is simply ignored and the native
  -- 160x144 journal above remains the fallback.
  local function modernStatusLabel(quest)
    if quest.status == "available" then return "NEW " .. tostring(quest.progress or "") end
    if quest.status == "failed" then return "FAILED" end
    if quest.status == "completed" then return "DONE" end
    return tostring(quest.progress or "ACTIVE")
  end

  local function modernListModel(state)
    local rows = state:rows()
    local out = {}
    for _, quest in ipairs(rows) do
      out[#out + 1] = {
        label = quest.title,
        value = modernStatusLabel(quest),
        marker = quest.tracked == true,
        enabled = true,
      }
    end
    return {
      title = state.tab == "completed" and "QUESTS - COMPLETED" or "QUESTS - ACTIVE",
      rows = out,
      index = state.index,
      scroll = state.scroll,
      footer = { "L/R TAB", "A DETAILS", "SELECT TRACK", "B BACK" },
    }
  end

  local function modernDetailModel(state)
    local quest = state:selected()
    if not quest then return modernListModel(state) end
    local rows
    if state.detailPage == 1 then
      rows = {
        { label = "OBJECTIVE", header = true },
        { label = quest.objective, enabled = false },
        { label = "LOCATION", header = true },
        { label = quest.location, enabled = false },
        { label = "PROGRESS", header = true },
        { label = quest.progress, value = quest.tracked and "TRACKED" or quest.status:upper(),
          marker = quest.tracked == true, enabled = false },
      }
    else
      rows = {
        { label = "DESCRIPTION", header = true },
        { label = quest.description, enabled = false },
        { label = "REWARD", header = true },
        { label = quest.reward, enabled = false },
        { label = "SOURCE", header = true },
        { label = quest.source, enabled = false },
      }
    end
    return {
      title = quest.title .. " - " .. tostring(state.detailPage) .. "/2",
      rows = rows,
      index = 1,
      scroll = 0,
      footer = { "L/R PAGE", "A NEXT", "SELECT TRACK", "B BACK" },
    }
  end

  local modernUiContract = {
    apiVersion = 1,
    screens = {
      quest_journal = {
        match = function(state)
          return type(state) == "table" and state.screenId == SCREEN_ID
        end,
        canSuppressNative = true,
        model = function(game, state)
          runtimeGame = resolveGame(game) or runtimeGame
          if state.detail then return modernDetailModel(state) end
          return modernListModel(state)
        end,
        actions = {
          hover = function(_, state, index)
            if state.detail then return false end
            local rows = state:rows()
            if #rows == 0 then return false end
            state.index = clamp(index, 1, #rows)
            state:clamp()
            return true
          end,
          select = function(_, state, index)
            if state.detail then
              state.detailPage = state.detailPage < 2 and state.detailPage + 1 or 1
              return true
            end
            local rows = state:rows()
            if #rows == 0 then return false end
            if index ~= nil then state.index = clamp(index, 1, #rows) end
            state:clamp()
            state.detail = true
            state.detailPage = 1
            return true
          end,
          left = function(_, state)
            if state.detail then
              state.detailPage = state.detailPage > 1 and state.detailPage - 1 or 2
            else
              state.tab = state.tab == "active" and "completed" or "active"
              state.index, state.scroll = 1, 0
            end
            return true
          end,
          right = function(_, state)
            if state.detail then
              state.detailPage = state.detailPage < 2 and state.detailPage + 1 or 1
            else
              state.tab = state.tab == "active" and "completed" or "active"
              state.index, state.scroll = 1, 0
            end
            return true
          end,
          back = function(_, state)
            if state.detail then
              state.detail = false
              state.detailPage = 1
            else
              state:close()
            end
            return true
          end,
        },
      },
    },
  }

  local modernUiExports
  local modernUiRegistered = false
  local function ensureModernUiAdapter()
    if type(mod.find) ~= "function" then return false end
    local okFind, handle = pcall(mod.find, "gen2_modern_ui")
    if not okFind or type(handle) ~= "table" or type(handle.exports) ~= "table" then
      modernUiExports, modernUiRegistered = nil, false
      return false
    end
    local ex = handle.exports
    if tonumber(ex.compatibilityApiVersion or 1) ~= 1
        or type(ex.registerAdapter) ~= "function" then
      modernUiExports, modernUiRegistered = ex, false
      return false
    end
    if modernUiRegistered and modernUiExports == ex then return true end
    local ok, registered, reason = pcall(ex.registerAdapter, {
      owner = MOD_ID,
      version = VERSION,
      contract = modernUiContract,
    })
    if ok and registered ~= false then
      modernUiExports, modernUiRegistered = ex, true
      return true
    end
    modernUiExports, modernUiRegistered = ex, false
    if mod.log then
      mod.log:warn("Gen2 Modern UI adapter unavailable: %s",
        tostring(ok and reason or registered))
    end
    return false
  end

  mod.content.screens:register(SCREEN_ID, { new = Journal.new })

  local function hasLabel(items, label)
    for _, item in ipairs(items or {}) do if item.label == label then return true end end
    return false
  end

  mod.hooks:wrap("ui.start_menu.items", function(next_, game, items)
    runtimeGame = resolveGame(game) or runtimeGame
    installAdapters(mod)
    local out = next_(game, items)
    if type(out) ~= "table" then out = items or {} end
    if not hasLabel(out, "QUESTS") then
      mod.ui.insertBefore(out, "SAVE", {
        label = "QUESTS",
        onSelect = function()
          ensureModernUiAdapter()
          mod.ui.push(game, SCREEN_ID)
        end,
      })
    end
    return out
  end)

  installNpcMarkers(mod)

  mod.events:on("game.ready", function(payload)
    runtimeGame = resolveGame(payload) or runtimeGame
    installAdapters(mod)
    ensureModernUiAdapter()
  end)

  mod.events:on("map.entered", function(payload)
    runtimeGame = resolveGame(payload) or runtimeGame
  end)

  -- Cross-mod commands use exports. Pokemon Recomp only allows a mod to emit
  -- events under its own `mod.<id>.*` namespace, so unnamespaced
  -- `quest.*` command events cannot be a supported public API.


  mod.exports.register = registerQuest
  mod.exports.remove = removeQuest
  mod.exports.start = startQuest
  mod.exports.update = patchQuest
  mod.exports.advance = advanceQuest
  mod.exports.complete = completeQuest
  mod.exports.fail = failQuest
  mod.exports.track = trackQuest
  mod.exports.addMarker = addMarker
  mod.exports.get = function(id, game)
    local def = definitions[id]
    local live = resolveGame(game)
    return def and live and snapshot(live, def) or nil
  end
  mod.exports.list = function(game)
    local live = resolveGame(game)
    return live and allSnapshots(live) or {}
  end
  mod.exports.open = function(game)
    local live = resolveGame(game)
    if live then
      ensureModernUiAdapter()
      return mod.ui.push(live, SCREEN_ID)
    end
    return nil, "no game"
  end
  mod.exports.screenId = SCREEN_ID
  mod.exports.gen2ModernUi = modernUiContract

  -- Register immediately when load order permits it; game.ready and every
  -- journal open retry this after mod enable/reload changes.
  ensureModernUiAdapter()

  mod.log:info("Quest System Gen 2 loaded")
end
