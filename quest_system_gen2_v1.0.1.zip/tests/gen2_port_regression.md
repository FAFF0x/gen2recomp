# Gen 2 port regression checklist

- manifest id is `pokemonmod_gen2_quest_system`
- `games` contains only `gen2`
- no hard manifest conflicts
- unique journal screen id: `PokemonModGen2QuestJournal`
- no `src.core.Game` dependency
- no Gen 1 story adapters
- Start menu uses `ui.start_menu.items`
- duplicate `QUESTS` rows are suppressed
- journal closes by popping back to the existing Gen 2 Start menu
- NPC markers use the Gen 2-compatible `src.world.NPC` alias
- Modern UI adapter targets `gen2_modern_ui`
- public presentation export is `gen2ModernUi`
- legacy `quest_system` can be present without a second active framework
