# Changelog

## 1.0.0

- Prima release dedicata esclusivamente alla Gen 2.
- Nuovo manifest ID univoco `pokemonmod_gen2_repel_reuse_prompt`.
- Limitazione esplicita `games: ["gen2"]`.
- Rimossa la logica Gen 1 basata su `ItemEffects`, `Bag` e `OverworldController`.
- Hook Gen 2 su `World:repelWoreOff()` e `World:useRepel()`.
- Mantiene la preferenza per lo stesso tipo di Repel appena terminato.
- Fallback MAX REPEL -> SUPER REPEL -> REPEL.
- Nessun prompt se non rimangono Repel nella Bag.
- Protezione anti-doppio hook per copie/varianti della stessa conversione Gen 2.
- Nessun permesso `engine_internals` richiesto.
