-- Repel Reuse Prompt - Gen 2
-- Dedicated Gen 2 implementation for Gen1Recomp/Pokemon Recomp.
--
-- Gen 2 does not use Gen 1's ItemEffects path for Repels. The live World owns
-- both the wear-off presentation (repelWoreOff) and use/consumption
-- (useRepel), so this mod wraps only those two methods on the live Gen 2 world.

local PATCH_KEY = "__pokemonmod_gen2_repel_reuse_prompt_dispatch_v1"

local REPEL_STEPS = {
  REPEL = 100,
  SUPER_REPEL = 200,
  MAX_REPEL = 250,
}

local FALLBACK_ORDER = { "MAX_REPEL", "SUPER_REPEL", "REPEL" }

local function countOf(save, itemId)
  local value = save and save.inventory and save.inventory[itemId]
  if type(value) == "number" then
    return math.max(0, math.floor(value))
  end
  return value == true and 1 or 0
end

local function itemName(game, itemId)
  local items = game and game.data and game.data.items
  local def = items and items[itemId]
  local name = def and def.name
  if type(name) == "string" and name ~= "" then return name end
  return tostring(itemId or "REPEL"):gsub("_", " ")
end

local function isGen2(game)
  local save = game and game.save
  if not save then return true end
  if save.generation ~= nil then return tonumber(save.generation) == 2 end
  if save.version ~= nil then
    local v = tostring(save.version):lower()
    return v == "gold" or v == "silver" or v == "crystal" or v == "gen2"
  end
  -- The manifest already restricts loading to Gen 2. Keep compatibility with
  -- older Gen 2 saves that predate the generation marker.
  return true
end

return function(mod)
  local gameRef = nil
  local warnedMissingWorld = false

  local dispatch = rawget(_G, PATCH_KEY)
  if type(dispatch) ~= "table" then
    dispatch = {
      worlds = setmetatable({}, { __mode = "k" }),
    }
    rawset(_G, PATCH_KEY, dispatch)
  elseif type(dispatch.worlds) ~= "table" then
    dispatch.worlds = setmetatable({}, { __mode = "k" })
  end

  local function install(game)
    if not (game and isGen2(game)) then return false end

    local world = game.world
    if not world then return false end

    -- A second imported copy/variant of this Gen 2 implementation must not
    -- install another wrapper or show two prompts.
    if dispatch.worlds[world] then return true end

    local baseRepelWoreOff = world.repelWoreOff
    local baseUseRepel = world.useRepel
    if type(baseRepelWoreOff) ~= "function" or type(baseUseRepel) ~= "function"
       or type(world.showText) ~= "function" or type(world.askYesNo) ~= "function" then
      if not warnedMissingWorld then
        warnedMissingWorld = true
        mod.log:warn("Repel Reuse Prompt - Gen 2 could not find the expected Gen 2 World Repel/text methods")
      end
      return false
    end

    local handler = {
      game = game,
      world = world,
      mod = mod,
      baseRepelWoreOff = baseRepelWoreOff,
      baseUseRepel = baseUseRepel,
    }

    function handler:remember(itemId)
      if REPEL_STEPS[itemId] then
        self.mod.save:set("lastRepel", itemId)
      end
    end

    function handler:chooseRepel()
      local save = self.game and self.game.save
      local preferred = self.mod.save:get("lastRepel")

      -- First try the exact kind that most recently activated the Repel effect.
      if REPEL_STEPS[preferred] and countOf(save, preferred) > 0 then
        return preferred
      end

      -- If it ran out, follow the requested priority.
      for _, itemId in ipairs(FALLBACK_ORDER) do
        if countOf(save, itemId) > 0 then return itemId end
      end
      return nil
    end

    function handler:showUsed(itemId)
      self.world:showText("{PLAYER} used the\n" .. itemName(self.game, itemId) .. ".")
    end

    function handler:activateAnother()
      -- Re-check on selection in case another UI/mod changed the bag while the
      -- prompt was open.
      local itemId = self:chooseRepel()
      if not itemId then
        self.world:showText("There is no REPEL\nleft in the BAG.")
        return
      end

      -- TextBox removes the YES/NO box and its underlying question before this
      -- callback runs, so World:useRepel is no longer blocked by World:busy().
      local result = self.world:useRepel(itemId)
      if result == "repel_used" then
        self:remember(itemId)
        self:showUsed(itemId)
      elseif result == "repel_active" then
        -- Defensive only: the expired counter should be zero here.
        self.world:showText("The REPEL used\nearlier is still\nin effect.")
      else
        self.world:showText("The REPEL could not\nbe used.")
      end
    end

    function handler:wearOff()
      local candidate = self:chooseRepel()
      if not candidate then
        -- Preserve the exact vanilla Gen 2 behavior when the bag has no Repels.
        return self.baseRepelWoreOff(self.world)
      end

      -- `stay=true` mirrors Gen 2's writetext -> yesorno behavior: after the
      -- final question page finishes typing, the YES/NO box is attached without
      -- requiring an extra A press. The page break still lets the player read
      -- the normal wear-off line first.
      self.world:showText(
        "REPEL's effect\nwore off.\fUse another REPEL?",
        function()
          self.world:askYesNo(function(yes)
            if yes then self:activateAnother() end
          end)
        end,
        true
      )
    end

    -- Remember every Repel activated normally from the Gen 2 PACK/registered
    -- item path so the automatic prompt can prefer the same type next time.
    world.useRepel = function(self, itemId, ...)
      local result = baseUseRepel(self, itemId, ...)
      if result == "repel_used" and REPEL_STEPS[itemId] then
        handler:remember(itemId)
      end
      return result
    end

    -- Gen 2 StepEvents calls this method exactly when save.repelSteps reaches 0.
    world.repelWoreOff = function(self, ...)
      return handler:wearOff(...)
    end

    dispatch.worlds[world] = handler
    mod.log:info("Repel Reuse Prompt - Gen 2 installed on the live Gen 2 world")
    return true
  end

  -- game.ready is emitted before Game2 creates its World, so retain the game and
  -- install as soon as the first Gen 2 map is fully entered. Subsequent map
  -- entries are harmless because the live World is tracked in dispatch.worlds.
  mod.events:on("game.ready", function(event)
    local game = event and event.game
    if not (game and isGen2(game)) then return end
    gameRef = game
    install(game)
  end)

  mod.events:on("map.entered", function(_event)
    if gameRef then install(gameRef) end
  end)

  -- CONTINUE creates the World before save.loaded is emitted. This is a second
  -- safe installation seam for engines/drivers where map.entered is filtered.
  mod.events:on("save.loaded", function(_event)
    if gameRef then install(gameRef) end
  end)
end
