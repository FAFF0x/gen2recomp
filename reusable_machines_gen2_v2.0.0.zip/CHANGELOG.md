# Changelog

## 2.0.0 - Gen 2 port

- Nuovo ID standalone `reusable_machines_gen2`.
- Supporto esclusivo `games: ["gen2"]` per Gold / Silver / Crystal.
- TM01-TM50 non vengono più consumate dopo un insegnamento riuscito.
- Supportate tutte e sette le HM Gen 2: CUT, FLY, SURF, STRENGTH, FLASH, WATERFALL, WHIRLPOOL.
- Le HM possono essere sostituite nel normale flusso a quattro mosse senza riscrivere `Game2:learnMoveOn`.
- Preservati prompt, SFX, callback e `pokemon.move_learned` del motore.
- Vendita/TOSS non vengono intercettati.
- Nessuna patch grafica al PackMenu: il Gen 2 nativo mostra già il nome della mossa nella tasca TM/HM.
- Aggiunto helper export `machineLabel`, `isMachine`, `isTM`, `isHM` per UI/mod compatibili.
- Compatibilità best-effort con Moves Manager aggiornata alle sette HM Gen 2.
