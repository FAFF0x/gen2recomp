-- Reusable Machines - Gen 2
-- 1) TM01-TM50 are not consumed after a successful teach.
-- 2) HM moves may be replaced in the normal four-move learn flow.
-- 3) Gen 2 already prints the taught move in the TM/HM pocket; expose a
--    shared label helper for UI mods without replacing the native PackMenu.

local PATCH_KEY = "__reusable_machines_gen2_dispatch_v1"
local unpack_ = table.unpack or unpack

local GEN2_HM_MOVES = {
  CUT = true,
  FLY = true,
  SURF = true,
  STRENGTH = true,
  FLASH = true,
  WATERFALL = true,
  WHIRLPOOL = true,
}

local function pack(...)
  return { n = select("#", ...), ... }
end

local function upper(value)
  return tostring(value or ""):upper()
end

local function isMachineItem(itemId, def)
  if type(def) ~= "table" or not def.teaches then return false end
  if upper(def.pocket) == "TM_HM" then return true end
  local id = upper(itemId)
  return id:sub(1, 3) == "TM_" or id:sub(1, 3) == "HM_"
end

local function isHMItem(itemId, def)
  if not isMachineItem(itemId, def) then return false end
  local id = upper(itemId)
  if id:sub(1, 3) == "HM_" then return true end
  local label = upper(def and (def.tmLabel or def.name))
  if label:sub(1, 2) == "HM" then return true end
  local number = tonumber(def and def.tmNumber)
  return number ~= nil and number > 50
end

local function isTMItem(itemId, def)
  return isMachineItem(itemId, def) and not isHMItem(itemId, def)
end

local function isHMMove(game, moveId)
  if not moveId then return false end
  if GEN2_HM_MOVES[moveId] then return true end
  local items = game and game.data and game.data.items or {}
  for itemId, def in pairs(items) do
    if isHMItem(itemId, def) and def.teaches == moveId then return true end
  end
  return false
end

local function machineLabel(game, itemId, fallback)
  local items = game and game.data and game.data.items or {}
  local moves = game and game.data and game.data.moves or {}
  local def = items[itemId]
  if not isMachineItem(itemId, def) then return fallback end
  local moveId = def.teaches
  local move = moves[moveId]
  local moveName = (move and move.name) or moveId or "?"
  local machine = def.tmLabel or def.name or fallback or itemId
  return tostring(machine) .. " " .. tostring(moveName)
end

local function removeMemoryId(memory, moveId)
  if type(memory) ~= "table" then return end
  if type(memory.known) == "table" then memory.known[moveId] = nil end
  if type(memory.order) == "table" then
    for i = #memory.order, 1, -1 do
      if memory.order[i] == moveId then table.remove(memory.order, i) end
    end
  end
end

local function rememberMemoryId(memory, moveId)
  if type(memory) ~= "table" or not moveId then return end
  memory.known = type(memory.known) == "table" and memory.known or {}
  memory.order = type(memory.order) == "table" and memory.order or {}
  if memory.known[moveId] then return end
  memory.known[moveId] = true
  memory.order[#memory.order + 1] = moveId
end

local function installMovesManagerCompat(game, dispatch)
  local screens = game.data and game.data.screens
  local factory = screens and screens.MovesManager
  if not factory or dispatch.movesManagerPatched then return end

  local baseNew = type(factory) == "function" and factory
    or (type(factory) == "table" and factory.new)
  if type(baseNew) ~= "function" then return end

  dispatch.movesManagerPatched = true
  local function decorate(state)
    if type(state) ~= "table" or state.__reusableMachinesGen2 then return state end
    state.__reusableMachinesGen2 = true

    if type(state.openPool) == "function" and type(state.currentMove) == "function" then
      local baseOpenPool = state.openPool
      function state:openPool(...)
        local current = self:currentMove()
        local oldId = current and current.id
        if not isHMMove(self.game or game, oldId) then
          return baseOpenPool(self, ...)
        end

        local tempId = "MOD_REUSABLE_GEN2_FORGET_" .. tostring(oldId)
        local data = (self.game or game).data
        local moves = data.moves or {}
        local previous = moves[tempId]
        moves[tempId] = moves[oldId]
        current.id = tempId
        local result = pack(pcall(baseOpenPool, self, ...))
        if current.id == tempId then current.id = oldId end
        moves[tempId] = previous
        for i = #(self.pool or {}), 1, -1 do
          local id = self.pool[i] and self.pool[i].id
          if id == oldId or id == tempId then table.remove(self.pool, i) end
        end
        if not result[1] then error(result[2], 0) end
        return unpack_(result, 2, result.n)
      end
    end

    if type(state.teachCandidate) == "function" and type(state.currentMove) == "function" then
      local baseTeach = state.teachCandidate
      function state:teachCandidate(...)
        local current = self:currentMove()
        local oldId = current and current.id
        if not isHMMove(self.game or game, oldId) then
          return baseTeach(self, ...)
        end

        local currentGame = self.game or game
        local tempId = "MOD_REUSABLE_GEN2_FORGET_" .. tostring(oldId)
        local moves = currentGame.data.moves or {}
        local previous = moves[tempId]
        moves[tempId] = moves[oldId]
        current.id = tempId
        local result = pack(pcall(baseTeach, self, ...))
        if current.id == tempId then current.id = oldId end
        moves[tempId] = previous

        local memory = self.mon and self.mon.movesManagerMemory
        removeMemoryId(memory, tempId)
        rememberMemoryId(memory, oldId)

        if not result[1] then error(result[2], 0) end
        return unpack_(result, 2, result.n)
      end
    end
    return state
  end

  local wrapped = function(currentGame, ...)
    return decorate(baseNew(currentGame, ...))
  end
  if type(factory) == "function" then
    screens.MovesManager = wrapped
  else
    local copy = {}
    for key, value in pairs(factory) do copy[key] = value end
    copy.new = wrapped
    screens.MovesManager = copy
  end

  local okScreens, Screens = pcall(require, "src.ui.Screens")
  if okScreens and type(Screens.invalidate) == "function" then
    pcall(Screens.invalidate)
  end
end

local function install(game, mod)
  local dispatch = rawget(_G, PATCH_KEY)
  if not dispatch then
    dispatch = {
      games = setmetatable({}, { __mode = "k" }),
      consumePatched = setmetatable({}, { __mode = "k" }),
    }
    rawset(_G, PATCH_KEY, dispatch)
  end
  dispatch.games[game] = { mod = mod }

  -- Game2:useFieldItem calls consumeItem only AFTER a TM was successfully
  -- taught. Selling and tossing go through Bag.remove instead, so suppressing
  -- machine consumption here makes machines reusable without making them
  -- unsellable or untossable.
  if not dispatch.consumePatched[game] and type(game.consumeItem) == "function" then
    dispatch.consumePatched[game] = true
    local baseConsume = game.consumeItem
    game.consumeItem = function(self, itemId, ...)
      local def = self.data and self.data.items and self.data.items[itemId]
      if isMachineItem(itemId, def) then
        return -- reusable TM/HM; preserve inventory exactly
      end
      return baseConsume(self, itemId, ...)
    end
  end

  -- Game2:learnMoveOn keeps the seven HM ids in a private local table.  Rather
  -- than replacing the entire learning routine, wrap only the onChoose callback
  -- of Gen2MoveDeleter when it is opened with layout="forget".  Present the HM
  -- under a temporary neutral id for that one callback, then restore it.  The
  -- native prompts, move entry, SFX, callbacks and ModRuntime event all remain
  -- engine-owned.
  local okScreens, Screens = pcall(require, "src.ui.Screens")
  if okScreens and type(Screens.push) == "function" and not dispatch.baseScreensPush then
    dispatch.baseScreensPush = Screens.push
    Screens.push = function(currentGame, screenId, ...)
      local args = pack(...)
      local active = dispatch.games[currentGame]
      local opts = args[1]
      if active and screenId == "Gen2MoveDeleter"
          and type(opts) == "table" and opts.layout == "forget"
          and type(opts.onChoose) == "function"
          and not opts.__reusableMachinesGen2 then
        local wrapped = {}
        for key, value in pairs(opts) do wrapped[key] = value end
        wrapped.__reusableMachinesGen2 = true
        local baseChoose = opts.onChoose
        wrapped.onChoose = function(slot, ...)
          local mon = wrapped.mon
          local old = mon and mon.moves and mon.moves[slot]
          local oldId = old and old.id
          if not isHMMove(currentGame, oldId) then
            return baseChoose(slot, ...)
          end

          local moves = currentGame.data and currentGame.data.moves or {}
          local tempId = "MOD_REUSABLE_GEN2_FORGET_" .. tostring(oldId)
          local previous = moves[tempId]
          moves[tempId] = moves[oldId]
          old.id = tempId
          local result = pack(pcall(baseChoose, slot, ...))
          -- The native callback normally replaced this slot; restore the
          -- detached old table too so a temp id cannot leak through another mod.
          if old.id == tempId then old.id = oldId end
          moves[tempId] = previous
          if not result[1] then error(result[2], 0) end
          return unpack_(result, 2, result.n)
        end
        args[1] = wrapped
      end
      return dispatch.baseScreensPush(currentGame, screenId,
        unpack_(args, 1, args.n))
    end
  elseif not okScreens then
    mod.log:warn("Reusable Machines Gen 2 could not load Screens; HM replacement compatibility is unavailable")
  end

  installMovesManagerCompat(game, dispatch)

  mod.exports.isMachine = function(itemId)
    local def = game.data and game.data.items and game.data.items[itemId]
    return isMachineItem(itemId, def)
  end
  mod.exports.isTM = function(itemId)
    local def = game.data and game.data.items and game.data.items[itemId]
    return isTMItem(itemId, def)
  end
  mod.exports.isHM = function(itemId)
    local def = game.data and game.data.items and game.data.items[itemId]
    return isHMItem(itemId, def)
  end
  mod.exports.machineLabel = function(itemId, fallback)
    return machineLabel(game, itemId, fallback)
  end

  mod.log:info("Reusable Machines Gen 2 installed: reusable TM/HM consumption and forgettable HM replacements")
end

return function(mod)
  mod.events:on("game.ready", function(event)
    local game = event and event.game
    if not game then
      mod.log:warn("Reusable Machines Gen 2 could not install: game.ready had no game object")
      return
    end
    install(game, mod)
  end)
end
