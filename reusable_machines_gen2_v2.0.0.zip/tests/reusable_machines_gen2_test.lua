package.path = "./?.lua;./?/init.lua;" .. package.path

local callbacks = {}
local logs = {}

local Screens = {}
function Screens.invalidate() end
function Screens.push(game, id, opts)
  local state = { game = game, screenId = id, opts = opts }
  game.stack[#game.stack + 1] = state
  return state
end
package.preload["src.ui.Screens"] = function() return Screens end

local save = {
  inventory = {
    TM_DYNAMICPUNCH = 2,
    HM_CUT = 1,
    POTION = 3,
  },
}

local game = {
  save = save,
  stack = {},
  data = {
    items = {
      TM_DYNAMICPUNCH = {
        id = "TM_DYNAMICPUNCH", name = "TM01", tmLabel = "TM01",
        tmNumber = 1, pocket = "TM_HM", teaches = "DYNAMICPUNCH",
      },
      HM_CUT = {
        id = "HM_CUT", name = "HM01", tmLabel = "HM01",
        tmNumber = 51, pocket = "TM_HM", teaches = "CUT",
      },
      HM_WATERFALL = {
        id = "HM_WATERFALL", name = "HM07", tmLabel = "HM07",
        tmNumber = 57, pocket = "TM_HM", teaches = "WATERFALL",
      },
      POTION = { id = "POTION", name = "POTION", pocket = "ITEM" },
    },
    moves = {
      DYNAMICPUNCH = { id = "DYNAMICPUNCH", name = "DYNAMICPUNCH" },
      CUT = { id = "CUT", name = "CUT" },
      WATERFALL = { id = "WATERFALL", name = "WATERFALL" },
      TACKLE = { id = "TACKLE", name = "TACKLE" },
    },
    screens = {},
  },
}

function game:consumeItem(id)
  local n = (self.save.inventory[id] or 0) - 1
  self.save.inventory[id] = n > 0 and n or nil
end

-- Optional Moves Manager compatibility fixture.
game.data.screens.MovesManager = {
  new = function(currentGame, mon)
    local state = {
      game = currentGame,
      mon = mon,
      slot = 1,
      pool = {},
    }
    function state:currentMove() return self.mon.moves[self.slot] end
    function state:openPool()
      if self:currentMove().id == "WATERFALL" then
        self.blocked = true
        return
      end
      self.pool = { { id = "TACKLE", name = "TACKLE" } }
    end
    function state:teachCandidate()
      local old = self:currentMove()
      if old.id == "WATERFALL" then
        self.blocked = true
        return
      end
      local memory = self.mon.movesManagerMemory
      memory.known[old.id] = true
      memory.order[#memory.order + 1] = old.id
      self.mon.moves[self.slot] = { id = "TACKLE", pp = 35 }
    end
    return state
  end,
}

local mod = {
  events = {
    on = function(_, name, fn) callbacks[name] = fn end,
  },
  exports = {},
  log = {
    info = function(_, message) logs[#logs + 1] = message end,
    warn = function(_, message) logs[#logs + 1] = "WARN " .. message end,
  },
}

local entry = assert(loadfile("main.lua"))()
entry(mod)
assert(callbacks["game.ready"], "game.ready registered")
callbacks["game.ready"]({ game = game })

-- TM/HM machine consumption is suppressed, ordinary consumables are not.
game:consumeItem("TM_DYNAMICPUNCH")
assert(save.inventory.TM_DYNAMICPUNCH == 2, "TM remains after teaching")
game:consumeItem("HM_CUT")
assert(save.inventory.HM_CUT == 1, "HM remains reusable")
game:consumeItem("POTION")
assert(save.inventory.POTION == 2, "ordinary item still consumes")

assert(mod.exports.isTM("TM_DYNAMICPUNCH"), "TM detected")
assert(mod.exports.isHM("HM_CUT"), "HM detected")
assert(mod.exports.isHM("HM_WATERFALL"), "Gen 2 HM07 detected")
assert(mod.exports.machineLabel("TM_DYNAMICPUNCH") == "TM01 DYNAMICPUNCH",
  "machine label exposes move name")

-- Native forget-list callback with a private HM table. The wrapper must make
-- WATERFALL look neutral only for the callback and leave no temporary id.
local mon = { moves = { { id = "WATERFALL", pp = 15 } } }
local blocked, replaced = false, false
local nativeHmLock = { WATERFALL = true }
local state = Screens.push(game, "Gen2MoveDeleter", {
  mon = mon,
  layout = "forget",
  onChoose = function(slot)
    local old = mon.moves[slot]
    if nativeHmLock[old.id] then
      blocked = true
      return
    end
    local oldDef = game.data.moves[old.id]
    assert(oldDef and oldDef.name == "WATERFALL", "temporary id resolves to HM def")
    mon.moves[slot] = { id = "TACKLE", pp = 35 }
    replaced = true
  end,
})
state.opts.onChoose(1)
assert(not blocked and replaced, "HM bypassed normal replacement lock")
assert(mon.moves[1].id == "TACKLE", "HM replaced")
for id in pairs(game.data.moves) do
  assert(not tostring(id):find("MOD_REUSABLE_GEN2_FORGET_", 1, true),
    "no temporary move definition leaked")
end

-- A non-forget MoveDeleter layout is intentionally untouched.
local mon2 = { moves = { { id = "WATERFALL", pp = 15 } } }
local blocked2 = false
local state2 = Screens.push(game, "Gen2MoveDeleter", {
  mon = mon2,
  layout = "deleter",
  onChoose = function(slot)
    if nativeHmLock[mon2.moves[slot].id] then blocked2 = true end
  end,
})
state2.opts.onChoose(1)
assert(blocked2, "unrelated MoveDeleter mode is not rewritten")

-- Optional Moves Manager compatibility supports all seven Gen 2 HMs.
local managerMon = {
  moves = { { id = "WATERFALL", pp = 15 } },
  movesManagerMemory = { known = {}, order = {} },
}
local manager = game.data.screens.MovesManager.new(game, managerMon)
manager:openPool()
assert(not manager.blocked and manager.pool[1].id == "TACKLE",
  "Moves Manager pool opens over HM07")
manager:teachCandidate()
assert(managerMon.moves[1].id == "TACKLE", "Moves Manager replaces HM07")
assert(managerMon.movesManagerMemory.known.WATERFALL,
  "real HM id remains in move memory")
for _, id in ipairs(managerMon.movesManagerMemory.order) do
  assert(not tostring(id):find("MOD_REUSABLE_GEN2_FORGET_", 1, true),
    "Moves Manager memory contains no temporary id")
end

print("reusable_machines_gen2_test: ok")
