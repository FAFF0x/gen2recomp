## 1.0.2

- Defeated Rocket ambushers now disappear immediately after winning the battle.
- Won ambushers no longer respawn while their recruit reward is pending.
- Added temporary `RKT GIFT` Start-menu entry for postponed recruit rewards.
- Quest markers disappear as soon as the Rocket battle is won.
- Full-storage recovery now points the player to `RKT GIFT` instead of the removed NPC.
- Existing v1.0.0/v1.0.1 quest progress remains compatible.

## 1.0.1

- Fixed visible Rocket ambushers not responding to the A button on Gen 2.
- Hooks the actual Gen 2 `OverworldController.talkTo` facade used by `World:interactBody`.
- Keeps the `world.talk` hook as a compatibility fallback.
- Runtime Rocket NPCs now carry an explicit `claimedByMod` marker.
- Existing quest progress is preserved.

# Changelog

## 1.0.0

- Initial Gen 2 release.
- Added eight Rocket ambushes after the eight Johto Gym Badges.
- Rocket NPCs spawn dynamically near each Gym entrance.
- Added native trainer battles with escalating themed teams.
- Added post-win recruit-one-Pokemon choice.
- Added safe party/first-free-box reward delivery and pending reward recovery when storage is full.
- Added eight intel fragments and a final Badge Net conclusion.
- Added Quest System Gen 2 journal registration, dynamic objectives, progress, locations, and NPC markers.
- Supports both `pokemonmod_gen2_quest_system` and `quest_system_gen2` framework ids.
