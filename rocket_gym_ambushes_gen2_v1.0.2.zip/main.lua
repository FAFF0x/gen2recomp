-- Rocket Gym Ambushes - Gen 2
-- Eight post-Gym Team Rocket encounters with a recruit-one reward after each win.
-- Designed to integrate with Quest System Gen 2 while remaining gameplay-safe if
-- the journal framework is temporarily unavailable.

local MOD_ID = "rocket_gym_ambushes_gen2"
local VERSION = "1.0.2"
local QUEST_ID = "rocket_gym_ambushes"
local RECRUIT_SCREEN = "RocketGymAmbushRecruitGen2"
local SAVE_KEY = "rocket_gym_ambushes_state"

local Mon = require("src.battle.gen2.Mon")
local Boxes = require("src.core.gen2.Boxes")
local Chrome = require("src.ui.gen2.Chrome")
local Permissions = require("src.world.gen2.Permissions")

local activeMod
local runtimeGame
local questApi
local questRegistered = false
local recruitContext
local spawnedIds = {}

local STAGES = {
  {
    badge = "ZEPHYR", badgeName = "ZEPHYR BADGE", leader = "FALKNER",
    gymMap = "VIOLET_GYM", outsideMap = "VIOLET_CITY",
    trainer = "ROCKET SCOUT", class = "GRUNTM", baseMoney = 9,
    team = { { "RATTATA", 11 }, { "ZUBAT", 11 }, { "EKANS", 12 } },
    intro = "Hold it! That new BADGE makes you interesting. TEAM ROCKET wants to know how strong you really are!",
    intel = "The Scout drops a coded slip: 'Observe every new BADGE. Report promising trainers.' Someone is tracking your victories.",
  },
  {
    badge = "HIVE", badgeName = "HIVE BADGE", leader = "BUGSY",
    gymMap = "AZALEA_GYM", outsideMap = "AZALEA_TOWN",
    trainer = "TAIL SNATCHER", class = "GRUNTM", baseMoney = 11,
    team = { { "EKANS", 17 }, { "KOFFING", 17 }, { "DROWZEE", 18 } },
    intro = "You wrecked our Slowpoke business, and now you beat the Gym too? I'll take that confidence down a notch!",
    intel = "A second note mentions 'Project Badge Net' and orders Rocket cells to test you after major victories.",
  },
  {
    badge = "PLAIN", badgeName = "PLAIN BADGE", leader = "WHITNEY",
    gymMap = "GOLDENROD_GYM", outsideMap = "GOLDENROD_CITY",
    trainer = "SIGNAL RUNNER", class = "GRUNTM", baseMoney = 13,
    team = { { "RATICATE", 22 }, { "GRIMER", 22 }, { "KOFFING", 23 } },
    intro = "Goldenrod is OUR city to watch. Every win of yours lights up our reports. Time to shut the signal off!",
    intel = "The Runner carries a frequency list tied to Goldenrod Radio. The ambushes are being coordinated, not improvised.",
  },
  {
    badge = "FOG", badgeName = "FOG BADGE", leader = "MORTY",
    gymMap = "ECRUTEAK_GYM", outsideMap = "ECRUTEAK_CITY",
    trainer = "RELIC THIEF", class = "GRUNTM", baseMoney = 15,
    team = { { "HAUNTER", 27 }, { "MURKROW", 28 }, { "GOLBAT", 28 } },
    intro = "Legends, towers, BADGES... all that power just sitting around. Rocket should own it, not some kid!",
    intel = "A torn dossier lists Ecruteak relics beside your name. The cell is scouting both you and Johto's old power sites.",
  },
  {
    badge = "STORM", badgeName = "STORM BADGE", leader = "CHUCK",
    gymMap = "CIANWOOD_GYM", outsideMap = "CIANWOOD_CITY",
    trainer = "ROCKET COURIER", class = "GRUNTM", baseMoney = 17,
    team = { { "GOLBAT", 31 }, { "RATICATE", 31 }, { "WEEZING", 32 } },
    intro = "You crossed the sea and came back stronger. Perfect. The boss wants field data on trainers who don't quit!",
    intel = "The Courier's route links Cianwood to Olivine. Rocket remnants are moving supplies by sea to avoid official roads.",
  },
  {
    badge = "MINERAL", badgeName = "MINERAL BADGE", leader = "JASMINE",
    gymMap = "OLIVINE_GYM", outsideMap = "OLIVINE_CITY",
    trainer = "HARBOR SMUGGLER", class = "GRUNTM", baseMoney = 19,
    team = { { "ARBOK", 34 }, { "MUK", 34 }, { "GOLBAT", 35 } },
    intro = "Olivine's harbor belongs to whoever controls the cargo. A Gym winner makes valuable cargo too!",
    intel = "A shipping manifest hides Rocket supplies among medicine crates. The final destination is marked only 'M'.",
  },
  {
    badge = "GLACIER", badgeName = "GLACIER BADGE", leader = "PRYCE",
    gymMap = "MAHOGANY_GYM", outsideMap = "MAHOGANY_TOWN",
    trainer = "RADIO CELL", class = "GRUNTM", baseMoney = 21,
    team = { { "WEEZING", 37 }, { "HOUNDOOR", 38 }, { "GOLBAT", 38 } },
    intro = "You keep tearing holes in our plans! Mahogany was supposed to stay quiet. This time YOU disappear!",
    intel = "The radio cipher finally decodes 'M': a mobile Rocket command cell. Its last order is to intercept you at Blackthorn.",
  },
  {
    badge = "RISING", badgeName = "RISING BADGE", leader = "CLAIR",
    gymMap = "BLACKTHORN_GYM_1F", outsideMap = "BLACKTHORN_CITY",
    trainer = "ROCKET EXEC. NOX", class = "GRUNTM", baseMoney = 25,
    team = { { "HOUNDOOM", 42 }, { "CROBAT", 42 }, { "WEEZING", 43 } },
    intro = "Eight BADGES. You were meant to become Rocket material... or a problem to erase. This is your final evaluation!",
    intel = "Nox's transmitter is smashed. The 'Badge Net' was a rogue Rocket remnant operation. With its command cell defeated, the ambushes end.",
    final = true,
  },
}

local function state()
  local s = activeMod and activeMod.save:get(SAVE_KEY)
  if type(s) ~= "table" then
    s = { completed = {}, won = {}, recruits = {}, discovered = false }
    if activeMod then activeMod.save:set(SAVE_KEY, s) end
  end
  s.completed = type(s.completed) == "table" and s.completed or {}
  s.won = type(s.won) == "table" and s.won or {}
  s.recruits = type(s.recruits) == "table" and s.recruits or {}
  return s
end

local function persist(s)
  if activeMod then activeMod.save:set(SAVE_KEY, s) end
end

local function gameOf(candidate)
  if type(candidate) == "table" and candidate.game then candidate = candidate.game end
  if candidate and candidate.save and candidate.data then
    runtimeGame = candidate
    return candidate
  end
  if activeMod and activeMod.game and activeMod.game.save then
    runtimeGame = activeMod.game
    return activeMod.game
  end
  return runtimeGame
end

local function badgeOwned(game, badge)
  local save = game and game.save
  local player = save and save.player
  local badges = player and player.badges
  return type(badges) == "table" and badges[badge] == true
end

local function completedCount()
  local s, n = state(), 0
  for i = 1, #STAGES do if s.completed[i] then n = n + 1 end end
  return n
end

local function firstIncompleteEligible(game)
  local s = state()
  for i, st in ipairs(STAGES) do
    if badgeOwned(game, st.badge) and not s.completed[i] then return i end
  end
  return nil
end

local function currentObjectiveStage(game)
  local s = state()
  for i, st in ipairs(STAGES) do
    if badgeOwned(game, st.badge) and not s.completed[i] then return i end
  end
  for i, st in ipairs(STAGES) do
    if not badgeOwned(game, st.badge) then return i end
  end
  return nil
end

local function findQuestSystem()
  if questApi then return questApi end
  if not (activeMod and type(activeMod.find) == "function") then return nil end
  for _, id in ipairs({ "pokemonmod_gen2_quest_system", "quest_system_gen2" }) do
    local ok, handle = pcall(activeMod.find, id)
    if ok and type(handle) == "table" and type(handle.exports) == "table"
        and handle.exports.active ~= false and type(handle.exports.register) == "function" then
      questApi = handle.exports
      return questApi
    end
  end
  return nil
end

local function objectiveText(game)
  local s = state()
  if completedCount() >= #STAGES then
    return "The Badge Net is destroyed. Team Rocket's roaming command cell has been broken."
  end
  local i = currentObjectiveStage(game)
  if not i then return "Keep exploring Johto." end
  local st = STAGES[i]
  if s.won[i] and not s.completed[i] then
    return "Choose one of " .. st.trainer .. "'s Pokemon to recruit."
  end
  if badgeOwned(game, st.badge) then
    return "Confront " .. st.trainer .. " outside the " .. st.leader .. " Gym."
  end
  return "Defeat " .. st.leader .. " and obtain the " .. st.badgeName .. "."
end

local function locationText(game)
  local i = currentObjectiveStage(game)
  if not i then return "Johto" end
  local s, st = state(), STAGES[i]
  if s.won[i] and not s.completed[i] then return "START MENU - RKT GIFT" end
  if badgeOwned(game, st.badge) then return st.outsideMap:gsub("_", " ") end
  return st.gymMap:gsub("_", " ")
end

local function questHidden(game)
  local s = state()
  if s.discovered or completedCount() > 0 then return false end
  for _, st in ipairs(STAGES) do if badgeOwned(game, st.badge) then return false end end
  return true
end

local function registerQuest()
  if questRegistered then return true end
  local qs = findQuestSystem()
  if not qs then return false end
  local markers = {}
  for i, st in ipairs(STAGES) do
    local markerIndex, markerStage = i, st
    markers[#markers + 1] = {
      map = markerStage.outsideMap,
      npc = "ROCKET_GYM_AMBUSH_" .. markerIndex,
      kind = "!",
      status = { "available", "active" },
      when = function(game)
        local s = state()
        return badgeOwned(game, markerStage.badge) and not s.completed[markerIndex] and not s.won[markerIndex]
      end,
    }
  end
  local ok, err = qs.register({
    id = QUEST_ID,
    title = "Rocket Gym Ambushes",
    description = "Someone in Team Rocket is monitoring your Gym victories. After each Johto Badge, a Rocket operative appears near that Gym. Defeat the ambusher, decode their intel, and free one Pokemon from their team to join you.",
    objective = function(game) return objectiveText(game) end,
    location = function(game) return locationText(game) end,
    reward = "Recruit 1 Pokemon after each of 8 ambushes. The final recruit carries BLACKGLASSES.",
    source = "Rocket Gym Ambushes",
    progress = function()
      local n = completedCount()
      return { current = n, total = #STAGES, label = tostring(n) .. "/8 cells defeated" }
    end,
    hidden = function(game) return questHidden(game) end,
    sort = 210,
    markers = markers,
  })
  if ok == false then
    if activeMod.log then activeMod.log:warn("Quest System registration failed: %s", tostring(err)) end
    return false
  end
  questRegistered = true
  return true
end

local function syncQuest(game, stageIndex)
  if not registerQuest() then return end
  local qs = findQuestSystem()
  if not qs then return end
  local n = completedCount()
  local patch = { current = n, total = #STAGES, stage = stageIndex or currentObjectiveStage(game) or #STAGES }
  if n >= #STAGES then
    if type(qs.complete) == "function" then pcall(qs.complete, QUEST_ID, patch) end
  else
    if type(qs.start) == "function" then pcall(qs.start, QUEST_ID, patch) end
  end
end

local function existingRuntimeId(world, stageIndex)
  local map = world and world.map
  local def = map and map.def
  for _, obj in ipairs((def and def.objects) or {}) do
    if obj.runtime and obj.owner == MOD_ID and obj.rocketGymAmbushStage == stageIndex then
      return map.id .. "_obj_" .. tostring(obj.index)
    end
  end
  return nil
end

local SPAWN_OFFSETS = {
  { -1, 1 }, { 1, 1 }, { -2, 1 }, { 2, 1 },
  { -1, 2 }, { 1, 2 }, { 0, 2 }, { -2, 2 }, { 2, 2 },
  { -1, 0 }, { 1, 0 }, { 0, 1 },
}

local function gymDoor(world, stage)
  local def = world and world.map and world.map.def
  for _, warp in ipairs((def and def.warps) or {}) do
    if warp.destMap == stage.gymMap then return warp end
  end
  return nil
end

local function freeSpawn(world, door)
  if not (world and world.map and door) then return nil end
  for _, d in ipairs(SPAWN_OFFSETS) do
    local x, y = door.x + d[1], door.y + d[2]
    if world.map:isWalkable(x, y) and not world:npcAt(x, y)
        and not (world.player and world.player.cellX == x and world.player.cellY == y) then
      return x, y
    end
  end
  return nil
end

local function removeStageNpc(game, stageIndex)
  local world = game and game.world
  local id = spawnedIds[stageIndex] or existingRuntimeId(world, stageIndex)
  if id and activeMod and activeMod.world then pcall(activeMod.world.removeNpc, activeMod.world, id) end
  spawnedIds[stageIndex] = nil
end

local function spawnStageNpc(game, stageIndex)
  local s, stage = state(), STAGES[stageIndex]
  local world = game and game.world
  if not (stage and world and world.map and world.map.id == stage.outsideMap) then return nil end
  if not badgeOwned(game, stage.badge) or s.completed[stageIndex] or s.won[stageIndex] then
    removeStageNpc(game, stageIndex)
    return nil
  end
  local existing = existingRuntimeId(world, stageIndex)
  if existing then
    spawnedIds[stageIndex] = existing
    return existing
  end
  local door = gymDoor(world, stage)
  local x, y = freeSpawn(world, door)
  if not x then
    -- Extremely defensive fallback for a romhack with a rebuilt Gym frontage.
    local p = world.player
    if p then
      for _, d in ipairs({ {1,0}, {-1,0}, {0,1}, {0,-1}, {2,0}, {-2,0} }) do
        local tx, ty = p.cellX + d[1], p.cellY + d[2]
        if world.map:isWalkable(tx, ty) and not world:npcAt(tx, ty) then x, y = tx, ty break end
      end
    end
  end
  if not x then return nil end
  local id, err = activeMod.world:spawnNpc(stage.outsideMap, {
    name = "ROCKET_GYM_AMBUSH_" .. stageIndex,
    sprite = "SPRITE_ROCKET",
    x = x, y = y,
    rocketGymAmbushStage = stageIndex,
    claimedByMod = MOD_ID,
  })
  if id then
    spawnedIds[stageIndex] = id
    s.discovered = true
    persist(s)
    syncQuest(game, stageIndex)
  elseif activeMod.log then
    activeMod.log:warn("could not spawn Rocket ambush %d: %s", stageIndex, tostring(err))
  end
  return id
end

local function syncCurrentMap(game)
  game = gameOf(game)
  if not (game and game.world and game.world.map) then return end
  registerQuest()
  local mapId = game.world.map.id
  for i, stage in ipairs(STAGES) do
    if mapId == stage.outsideMap then spawnStageNpc(game, i) end
  end
end

local function buildTrainer(game, stage)
  local party = {}
  for _, row in ipairs(stage.team) do
    local mon = Mon.new(game.data, row[1], row[2])
    if mon then party[#party + 1] = mon end
  end
  return {
    class = stage.class or "GRUNTM",
    classId = stage.class or "GRUNTM",
    name = stage.trainer,
    trainerName = stage.trainer,
    className = "TEAM ROCKET",
    baseMoney = stage.baseMoney or 10,
    party = party,
    items = {},
  }
end

local function firstFreeBox(save)
  local preferred = math.max(1, math.min(Boxes.NUM_BOXES, tonumber(save.currentBox) or 1))
  if not Boxes.isFull(save, preferred) then return preferred end
  for off = 1, Boxes.NUM_BOXES - 1 do
    local idx = ((preferred - 1 + off) % Boxes.NUM_BOXES) + 1
    if not Boxes.isFull(save, idx) then return idx end
  end
  return nil
end

local function giveRecruit(game, stageIndex, choiceIndex)
  local s, stage = state(), STAGES[stageIndex]
  if not (stage and stage.team[choiceIndex] and not s.completed[stageIndex]) then return nil, "invalid reward" end
  local species, level = stage.team[choiceIndex][1], stage.team[choiceIndex][2]
  game.save.party = game.save.party or {}
  local boxIndex
  if #game.save.party >= Boxes.PARTY_SIZE then
    boxIndex = firstFreeBox(game.save)
    if not boxIndex then return nil, "storage full" end
  end
  local mon = Mon.new(game.data, species, level)
  if not mon then return nil, "unknown Pokemon" end
  local pdef = game.data and game.data.pokemon and game.data.pokemon[species]
  mon.nickname = (pdef and pdef.name) or species
  mon.happiness = math.max(100, tonumber(mon.happiness) or 0)
  if stage.final and game.data.items and game.data.items.BLACKGLASSES then
    mon.item = "BLACKGLASSES"
  end
  Mon.stampOT(game.save, mon)
  local destination
  if not boxIndex then
    game.save.party[#game.save.party + 1] = mon
    destination = "party"
  else
    local box = Boxes.box(game.save, boxIndex)
    box[#box + 1] = Boxes.enterBox(mon)
    Boxes.setCurrent(game.save, boxIndex)
    destination = "BOX " .. tostring(boxIndex)
  end
  game.save.pokedex = game.save.pokedex or { seen = {}, caught = {} }
  game.save.pokedex.seen = game.save.pokedex.seen or {}
  game.save.pokedex.caught = game.save.pokedex.caught or {}
  game.save.pokedex.seen[species] = true
  game.save.pokedex.caught[species] = true
  s.completed[stageIndex] = true
  s.won[stageIndex] = true
  s.recruits[stageIndex] = species
  s.lastIntel = stage.intel
  persist(s)
  removeStageNpc(game, stageIndex)
  syncQuest(game, stageIndex + 1)
  return mon, destination
end

local RecruitScreen = {}
RecruitScreen.__index = RecruitScreen
RecruitScreen.isOpaque = true

function RecruitScreen.new(game)
  local ctx = recruitContext
  if not (ctx and STAGES[ctx.stage]) then return setmetatable({ game = game, invalid = true }, RecruitScreen) end
  local stage = STAGES[ctx.stage]
  local self = setmetatable({ game = game, stageIndex = ctx.stage }, RecruitScreen)
  local items = {}
  for i, row in ipairs(stage.team) do
    local def = game.data.pokemon and game.data.pokemon[row[1]] or {}
    items[#items + 1] = { label = (def.name or row[1]) .. "  L" .. tostring(row[2]), value = i }
  end
  items[#items + 1] = { label = "DECIDE LATER", value = 0 }
  self.list = Chrome.List.new({
    items = items, x = 3, y = 5, spacing = 2, rows = #items, wrap = true,
    onChoose = function(value) self:choose(value) end,
    onCancel = function() self:close() end,
  })
  return self
end

function RecruitScreen:close()
  local stack = self.game and self.game.stack
  if stack and stack:top() == self then stack:pop() end
end

function RecruitScreen:choose(value)
  if value == 0 then return self:close() end
  local stage = STAGES[self.stageIndex]
  local mon, destination = giveRecruit(self.game, self.stageIndex, value)
  if not mon then
    self:close()
    local world = self.game and self.game.world
    if world then world:showText("Your party and every BOX are full. Make room, then open RKT GIFT from the START menu.") end
    return
  end
  self:close()
  local world = self.game and self.game.world
  if world then
    local name = mon.nickname or mon.species
    local text = destination == "party"
      and (name .. " chose to join your party!")
      or (name .. " chose to join you! It was sent to " .. destination .. ".")
    if stage.final and mon.item == "BLACKGLASSES" then
      text = text .. " It is holding BLACKGLASSES."
    end
    world:showText(text, function()
      if completedCount() >= #STAGES then
        world:showText("The Rocket Badge Net is finished. No more ambush signals remain in Johto.")
      end
    end)
  end
end

function RecruitScreen:update()
  if self.invalid then return self:close() end
  self.list:update(self.game and self.game.input)
end

function RecruitScreen:draw()
  Chrome.clear()
  Chrome.box(0, 0, 20, 18)
  Chrome.print("ROCKET DEFEATED", 2, 1)
  Chrome.print("Choose 1 Pokemon", 2, 3)
  self.list:draw()
  Chrome.print("A RECRUIT   B LATER", 1, 16)
end

local function openRecruit(game, stageIndex)
  recruitContext = { stage = stageIndex }
  activeMod.ui.push(game, RECRUIT_SCREEN)
end

local function afterWin(game, stageIndex)
  local s, stage = state(), STAGES[stageIndex]
  s.won[stageIndex] = true
  s.discovered = true
  s.lastIntel = stage.intel
  persist(s)
  -- A defeated ambusher leaves immediately.  The recruit reward is persisted
  -- independently under s.won, so postponing the choice never keeps a Rocket
  -- blocking the Gym entrance.
  removeStageNpc(game, stageIndex)
  syncQuest(game, stageIndex)
  local world = game and game.world
  if world then
    world:showText(stage.intel, function() openRecruit(game, stageIndex) end)
  else
    openRecruit(game, stageIndex)
  end
end

local function startAmbushBattle(game, stageIndex)
  local stage = STAGES[stageIndex]
  local world = game and game.world
  if not (stage and world) then return end
  local trainer = buildTrainer(game, stage)
  if #trainer.party == 0 then
    world:showText("The Rocket has no usable Pokemon. The ambush fizzles out.")
    return
  end
  world:startBattle({ trainer = trainer }, function(outcome)
    if outcome ~= "lose" then afterWin(game, stageIndex) end
  end)
end

local function talkAmbusher(game, stageIndex)
  local s, stage = state(), STAGES[stageIndex]
  local world = game and game.world
  if not (stage and world) then return end
  if s.completed[stageIndex] then
    removeStageNpc(game, stageIndex)
    return
  end
  s.discovered = true
  persist(s)
  syncQuest(game, stageIndex)
  if s.won[stageIndex] then
    return openRecruit(game, stageIndex)
  end
  world:showText(stage.intro, function() startAmbushBattle(game, stageIndex) end)
end

local function firstPendingRecruit()
  local s = state()
  for i = 1, #STAGES do
    if s.won[i] and not s.completed[i] then return i end
  end
  return nil
end

return function(mod)
  activeMod = mod
  runtimeGame = mod.game
  mod.exports.version = VERSION
  mod.exports.questId = QUEST_ID
  mod.exports.stages = STAGES

  mod.content.screens:register(RECRUIT_SCREEN, { new = RecruitScreen.new })

  -- Once an ambusher is defeated it never remains at the Gym entrance.
  -- A postponed/full-storage recruit is recovered from this temporary Start
  -- menu row instead, so the reward stays safe without leaving a blocking NPC.
  mod.hooks:wrap("ui.start_menu.items", function(next_, game, items)
    local out = next_(game, items)
    if type(out) ~= "table" then return out end
    local pending = firstPendingRecruit()
    if not pending then return out end
    for _, entry in ipairs(out) do
      if entry and entry.rocketGymAmbushReward == true then return out end
    end
    mod.ui.insertBefore(out, "SAVE", {
      label = "RKT GIFT",
      desc = { "Claim Rocket", "Pokemon" },
      rocketGymAmbushReward = true,
      onSelect = function(g) openRecruit(gameOf(g) or game, pending) end,
    })
    return out
  end)

  -- Runtime actors in Gen 2 are resolved by World:interactBody, which
  -- dispatches custom talk handlers through the Gen1-compatible
  -- OverworldController.talkTo facade.  `world.talk` remains installed too:
  -- older/future engine builds may expose that public seam directly.
  local function ambusherStage(target)
    local def = target and target.def
    if type(def) ~= "table" then return nil end
    local stageIndex = tonumber(def.rocketGymAmbushStage)
    if not stageIndex then return nil end
    if def.owner == MOD_ID or def.claimedByMod == MOD_ID then return stageIndex end
    return nil
  end

  local function claimAmbusherTalk(ow, target)
    local stageIndex = ambusherStage(target)
    if not stageIndex then return false end
    local game = gameOf(ow and ow.game) or gameOf()
    if not game then return false end
    talkAmbusher(game, stageIndex)
    return true
  end

  mod.hooks:wrap("world.talk", function(next_, ow, target)
    if claimAmbusherTalk(ow, target) then return true end
    return next_(ow, target)
  end)

  -- Current Gen 2 dispatch path (World:interactBody ->
  -- Gen2Compat.talkToWrapper). Chain whatever another mod installed before us
  -- instead of replacing it outright.
  local okOw, OverworldController = pcall(require, "src.world.OverworldController")
  if okOw and type(OverworldController) == "table" then
    local previousTalkTo = OverworldController.talkTo
    if not OverworldController.__rocketGymAmbushesGen2TalkV101 then
      OverworldController.talkTo = function(ow, target)
        if claimAmbusherTalk(ow, target) then return true end
        if type(previousTalkTo) == "function" then
          return previousTalkTo(ow, target)
        end
        return false
      end
      OverworldController.__rocketGymAmbushesGen2TalkV101 = true
    end
  elseif mod.log then
    mod.log:warn("Gen 2 talk facade unavailable; using world.talk fallback only")
  end

  mod.events:on("game.ready", function(payload)
    local game = gameOf(payload)
    registerQuest()
    syncCurrentMap(game)
  end)

  mod.events:on("map.entered", function(payload)
    local game = gameOf(payload)
    syncCurrentMap(game)
  end)

  mod.exports.sync = function(game) return syncCurrentMap(game or gameOf()) end
  mod.exports.state = function() return state() end
  mod.exports.openRecruit = function(game, stageIndex)
    game = gameOf(game)
    if not game then return nil, "no game" end
    openRecruit(game, tonumber(stageIndex) or firstIncompleteEligible(game) or 1)
    return true
  end

  registerQuest()
  if mod.log then mod.log:info("Rocket Gym Ambushes Gen 2 v%s loaded", VERSION) end
end
