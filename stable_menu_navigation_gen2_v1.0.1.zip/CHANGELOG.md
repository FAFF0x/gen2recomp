## 1.0.1

- Fixed invalid manifest profile `qol`.
- Uses supported profile `content` and category `UI`.

# Changelog

## 1.0.0

- Initial Gen 2-only release.
- Converted menu hold-repeat timing from logic-frame time to wall-clock time.
- Preserves immediate edge presses.
- Preserves per-menu delay/rate values by converting their frame values at 60 Hz.
- Prevents fast-forward logic bursts from producing multiple repeat moves in one rendered frame.
- Added duplicate-patch guard.
