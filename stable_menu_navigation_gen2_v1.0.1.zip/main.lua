-- Stable Menu Navigation - Gen 2
--
-- GAME SPEED accelerates the fixed-step logic clock. Gen 2's menu hold-repeat
-- is expressed in logical frames (normally 15 before repeating, then every 5),
-- so at 4X/8X/10X the cursor can race through Pack/Pokedex/list menus.
--
-- This mod changes only MenuRepeat's HOLD cadence from logical-frame time to
-- wall-clock time. Edge presses are untouched and still respond immediately.
-- The rest of the game remains at the selected GAME SPEED.

local MOD_ID = "pokemonmod_gen2_stable_menu_navigation"
local PATCH_KEY = "__pokemonmod_gen2_stable_menu_navigation_v1"
local LOGIC_HZ = 60
local ALL_DIRS = { "up", "down", "left", "right" }

local function wallTime()
  if love and love.timer and type(love.timer.getTime) == "function" then
    local ok, value = pcall(love.timer.getTime)
    if ok and type(value) == "number" then return value end
  end
  -- Headless/test fallback. os.clock is monotonic enough for the repeat gate.
  if os and type(os.clock) == "function" then return os.clock() end
  return 0
end

local function framesToSeconds(value, fallback)
  local frames = tonumber(value)
  if frames == nil then frames = fallback end
  return math.max(0, frames) / LOGIC_HZ
end

local function clearRealtimeState(state)
  if type(state) ~= "table" then return end
  state.__stableMenuDir = nil
  state.__stableMenuNext = nil
end

return function(mod)
  local ok, MenuRepeat = pcall(require, "src.ui.MenuRepeat")
  if not ok or type(MenuRepeat) ~= "table"
      or type(MenuRepeat.direction) ~= "function"
      or type(MenuRepeat.reset) ~= "function" then
    mod.log:error("Stable Menu Navigation could not access src.ui.MenuRepeat")
    mod.exports.active = false
    mod.exports.reason = "MenuRepeat unavailable"
    return
  end

  local installed = rawget(_G, PATCH_KEY)
  if type(installed) == "table" and installed.module == MenuRepeat
      and MenuRepeat.direction == installed.direction then
    -- Another imported copy of this exact implementation already owns the
    -- repeat gate. Do not wrap twice.
    mod.exports.active = true
    mod.exports.shared = true
    mod.exports.mode = "realtime_repeat"
    return
  end

  local baseDirection = MenuRepeat.direction
  local baseReset = MenuRepeat.reset

  local function realtimeDirection(state, input, dirs)
    -- Fail open for unexpected callers instead of destabilising a menu.
    if type(state) ~= "table" or type(input) ~= "table" then
      return baseDirection(state, input, dirs)
    end

    local watched = dirs or ALL_DIRS

    -- Physical/synthetic edge: exactly vanilla semantics. One press means one
    -- move immediately, regardless of current GAME SPEED.
    for _, dir in ipairs(watched) do
      if input.wasPressed and input:wasPressed(dir) then
        state.dir = dir
        state.frames = 0 -- retained for compatibility/debuggers
        state.__stableMenuDir = dir
        -- Gen 2 default: 15 / 60 = 0.25 s before the first held repeat.
        -- ListMenu/custom callers keep whatever delay they requested.
        state.__stableMenuNext = wallTime()
          + math.max(0.001, framesToSeconds(state.delay, MenuRepeat.GEN2_DELAY or 15))
        return dir, true
      end
    end

    local dir = state.dir
    if not (dir and state.enabled and input.isDown and input:isDown(dir)) then
      baseReset(state)
      clearRealtimeState(state)
      return nil, false
    end

    -- Keep the legacy counter moving for mods/debug UI that inspect it, but it
    -- is no longer the source of timing.
    state.frames = (tonumber(state.frames) or 0) + 1

    local now = wallTime()
    if state.__stableMenuDir ~= dir or type(state.__stableMenuNext) ~= "number" then
      state.__stableMenuDir = dir
      state.__stableMenuNext = now
        + math.max(0.001, framesToSeconds(state.delay, MenuRepeat.GEN2_DELAY or 15))
      return nil, false
    end

    if now >= state.__stableMenuNext then
      -- Schedule from NOW rather than adding to an old deadline. This prevents
      -- lag spikes or many fast-forward logic ticks in one rendered frame from
      -- causing a burst of several cursor moves at once.
      state.__stableMenuNext = now
        + math.max(0.001, framesToSeconds(state.rate, MenuRepeat.GEN2_RATE or 5))
      return dir, false
    end

    return nil, false
  end

  MenuRepeat.direction = realtimeDirection

  rawset(_G, PATCH_KEY, {
    module = MenuRepeat,
    baseDirection = baseDirection,
    direction = realtimeDirection,
    owner = MOD_ID,
  })

  mod.exports.active = true
  mod.exports.mode = "realtime_repeat"
  mod.exports.logicHz = LOGIC_HZ
  mod.exports.gen2DefaultDelaySeconds = (MenuRepeat.GEN2_DELAY or 15) / LOGIC_HZ
  mod.exports.gen2DefaultRateSeconds = (MenuRepeat.GEN2_RATE or 5) / LOGIC_HZ

  mod.log:info(
    "Stable Menu Navigation enabled: held menu directions now use real-time repeat timing"
  )
end
