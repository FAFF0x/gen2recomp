# Real-time repeat regression checklist

Expected Gen 2 default timings:

- initial press: immediate move
- first held repeat: ~0.250 s after the edge
- later repeats: ~0.0833 s apart

The result must be the same at 1X, 2X, 4X, 8X and higher GAME SPEED values.
Multiple calls to `MenuRepeat.direction` at the same wall-clock timestamp must
not produce multiple repeat moves.

Release must clear the held direction and the real-time deadline. A new press
must again wait the full initial delay before held repeat starts.
