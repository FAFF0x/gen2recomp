# Changelog

## 1.0.0
- Prima release separata per Gen 2.
- Manifest limitato a `games: ["gen2"]`.
- Nuovo ID univoco `pokemonmod_gen2_summon` per evitare collisioni con `summon` e altre build Gen 1.
- Nuovo screen ID univoco `PokemonModGen2SummonScreen`.
- Rimossa la dipendenza dal percorso Gen 1 `BattleState.newWild`.
- Gli incontri vengono avviati con il percorso nativo Gen 2 `World:startScriptedBattle` / `World:startBattle`.
- Il Pokémon evocato usa l'indice specie Gen 2 e il normale costruttore Gen 2, mantenendo moveset, statistiche, EXP e cattura corretti.
- Il livello corrisponde al primo Pokémon sano della squadra.
- Supportate specie aggiunte da altre mod con `dex` e `index` validi leggendo il dataset finale `game.data.pokemon`, senza dipendere dall’ordine di caricamento.
- Aggiunta protezione contro una seconda voce SUMMON nel menu Start.
- Annullando si torna alla stessa istanza del menu Start Gen 2; confermando il menu viene chiuso prima della battaglia, così al termine si torna all'overworld.
- Rimossi i flag/UI specifici della Gen1 Modern UI.
