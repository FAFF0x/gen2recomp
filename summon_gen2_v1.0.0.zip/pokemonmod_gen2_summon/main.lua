-- SUMMON - Gen 2
-- Adds a numeric Pokédex selector to the Gen 2 Start menu and starts a normal
-- wild encounter with the selected species. The Pokémon is never granted
-- directly: it must be caught through the ordinary Gen 2 battle system.

local SCREEN = "PokemonModGen2SummonScreen"
local HOOK_PRIORITY = 1000

local GRID = {
  { "1", "2", "3" },
  { "4", "5", "6" },
  { "7", "8", "9" },
  { "DEL", "0", "OK" },
  { "CANCEL" },
}

local function clamp(value, low, high)
  value = tonumber(value) or low
  if value < low then return low end
  if value > high then return high end
  return value
end

local function normalizeLabel(label)
  return tostring(label or ""):upper():gsub("[^A-Z0-9]", "")
end

local function hasSummonRow(items)
  for _, item in ipairs(items or {}) do
    if normalizeLabel(item and item.label) == "SUMMON" then return true end
    if item and item.pokemonmodGen2Summon then return true end
  end
  return false
end

local function moveGrid(state, direction)
  local current = GRID[state.row]
  if direction == "up" then
    state.row = state.row > 1 and state.row - 1 or #GRID
    state.col = math.min(state.col, #GRID[state.row])
  elseif direction == "down" then
    state.row = state.row < #GRID and state.row + 1 or 1
    state.col = math.min(state.col, #GRID[state.row])
  elseif direction == "left" then
    state.col = state.col > 1 and state.col - 1 or #current
  elseif direction == "right" then
    state.col = state.col < #current and state.col + 1 or 1
  end
end

local function hasHealthyParty(game)
  for _, mon in ipairs(game and game.save and game.save.party or {}) do
    if (tonumber(mon.hp) or 0) > 0 then return true end
  end
  return false
end

local function summonLevel(game)
  for _, mon in ipairs(game and game.save and game.save.party or {}) do
    if (tonumber(mon.hp) or 0) > 0 then
      return math.floor(clamp(mon.level, 1, 100))
    end
  end
  return nil
end

local function buildDexIndex(game)
  local rows = {}
  local pokemon = game and game.data and game.data.pokemon or {}
  for id, def in pairs(pokemon) do
    local dex = tonumber(def and def.dex)
    local index = tonumber(def and def.index)
    if dex and index and dex >= 1 and dex % 1 == 0 and index >= 1 then
      rows[#rows + 1] = {
        id = id,
        dex = math.floor(dex),
        index = math.floor(index),
        name = (def and def.name) or id,
      }
    end
  end

  table.sort(rows, function(a, b)
    if a.dex ~= b.dex then return a.dex < b.dex end
    return tostring(a.id) < tostring(b.id)
  end)

  local byDex, maxDex = {}, 0
  for _, row in ipairs(rows) do
    -- Vanilla dex numbers are unique. If two content mods reuse the same
    -- number, pick one deterministically instead of depending on registry order.
    if not byDex[row.dex] then byDex[row.dex] = row end
    if row.dex > maxDex then maxDex = row.dex end
  end
  return byDex, maxDex
end

local function makeScreenClass(mod)
  local Font = mod.ui.Font
  local Theme = mod.ui.Theme
  local Screen = {}
  Screen.__index = Screen
  Screen.isOpaque = true

  function Screen.new(game)
    local byDex, maxDex = buildDexIndex(game)
    return setmetatable({
      game = game,
      byDex = byDex,
      maxDex = maxDex,
      digits = "",
      glyphs = {},
      maxLen = math.max(3, #tostring(math.max(1, maxDex))),
      title = "SUMMON",
      row = 1,
      col = 1,
      message = "",
      screenId = SCREEN,
    }, Screen)
  end

  function Screen:grid()
    return GRID
  end

  function Screen:syncDigits()
    self.digits = table.concat(self.glyphs or {})
  end

  function Screen:clearDigits()
    self.glyphs = {}
    self:syncDigits()
    self.message = ""
  end

  function Screen:selectedNumber()
    if self.digits == "" then return nil end
    return tonumber(self.digits)
  end

  function Screen:selectedSpecies()
    local n = self:selectedNumber()
    return n and self.byDex[n] or nil
  end

  function Screen:appendDigit(digit)
    if #(self.glyphs or {}) >= self.maxLen then return end
    if digit == "0" and #self.glyphs == 0 then return end
    self.glyphs[#self.glyphs + 1] = digit
    self:syncDigits()
    self.message = ""
  end

  function Screen:deleteDigit()
    table.remove(self.glyphs)
    self:syncDigits()
    self.message = ""
  end

  function Screen:cancel()
    -- Gen 2 keeps the Start menu below submenu screens. Pop only SUMMON so the
    -- player returns to that exact menu instance and cursor position.
    if self.game and self.game.stack then self.game.stack:pop() end
  end

  function Screen:submit()
    local number = self:selectedNumber()
    if not number then
      self.message = "ENTER A NUMBER"
      return
    end

    local row = self.byDex[number]
    if not row then
      self.message = ("No.%03d NOT FOUND"):format(number)
      return
    end

    local level = summonLevel(self.game)
    if not level then
      self.message = "NO HEALTHY POKEMON"
      return
    end

    local world = self.game and self.game.world
    if not (world and type(world.startScriptedBattle) == "function") then
      self.message = "WORLD API UNAVAILABLE"
      return
    end

    -- The screen was pushed over Gen2StartMenu. A battle must return to the
    -- overworld, not to an old Start menu left underneath it, so close both.
    self.game.stack:pop() -- SUMMON
    self.game.stack:pop() -- Gen 2 Start menu

    local ok = world:startScriptedBattle(nil, {
      species = row.index,
      level = level,
    })

    if not ok then
      mod.log:warn("SUMMON failed for %s (dex %d, index %d)",
        tostring(row.id), row.dex, row.index)
      self.game.stack:push(mod.ui.TextBox.new(self.game,
        "SUMMON failed.\nTry again."))
    end
  end

  function Screen:activate(label)
    if label:match("^%d$") then
      self:appendDigit(label)
    elseif label == "DEL" then
      self:deleteDigit()
    elseif label == "OK" then
      self:submit()
    elseif label == "CANCEL" then
      self:cancel()
    end
  end

  function Screen:update()
    local input = self.game and self.game.input
    if not input then return end
    local current = GRID[self.row]

    if input:wasPressed("up") then
      moveGrid(self, "up")
    elseif input:wasPressed("down") then
      moveGrid(self, "down")
    elseif input:wasPressed("left") then
      moveGrid(self, "left")
    elseif input:wasPressed("right") then
      moveGrid(self, "right")
    elseif input:wasPressed("select") then
      self:clearDigits()
    elseif input:wasPressed("start") then
      self:submit()
    elseif input:wasPressed("b") then
      self:cancel()
    elseif input:wasPressed("a") then
      self:activate(current[self.col])
    end
  end

  -- Physical keyboard support, including the numeric keypad.
  function Screen:onKeyPressed(key)
    local digit = key and key:match("^([0-9])$")
      or (key and key:match("^kp([0-9])$"))
    if digit then
      self:appendDigit(digit)
    elseif key == "backspace" or key == "delete" then
      self:deleteDigit()
    elseif key == "return" or key == "kpenter" then
      self:submit()
    elseif key == "escape" then
      self:cancel()
    elseif self.game and self.game.input and self.game.input.keypressed then
      self.game.input:keypressed(key)
    end
  end

  local function centerX(label, center)
    return center - math.floor(Font.width(label) / 2)
  end

  function Screen:draw()
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.rectangle("fill", 0, 0, 160, 144)
    love.graphics.setColor(0, 0, 0, 1)

    Font.draw("SUMMON", 8, 8)
    Font.drawBox(1, 2, 18, 5)

    local number = self:selectedNumber()
    local display = number and ("No.%03d"):format(number) or "No.---"
    Font.draw(display, 16, 24)

    local species = self:selectedSpecies()
    if species then
      Font.draw(species.name, 16, 40)
      Font.draw(("LV%3d"):format(summonLevel(self.game) or 0), 112, 40)
    else
      Font.draw(("VALID: 1-%d"):format(self.maxDex), 16, 40)
    end

    local centers = { 32, 80, 128 }
    local startY = 72
    for r, row in ipairs(GRID) do
      local y = startY + (r - 1) * 14
      if #row == 1 then
        local label = row[1]
        Font.draw(label, centerX(label, 80), y)
      else
        for c, label in ipairs(row) do
          Font.draw(label, centerX(label, centers[c]), y)
        end
      end
    end

    local selectedRow = GRID[self.row]
    local center = #selectedRow == 1 and 80 or centers[self.col]
    Font.drawCode(Theme.cursor,
      center - math.floor(Font.width(selectedRow[self.col]) / 2) - 8,
      startY + (self.row - 1) * 14)

    if self.message ~= "" then
      Font.draw(self.message, centerX(self.message, 80), 136)
    end
    love.graphics.setColor(1, 1, 1, 1)
  end

  return Screen
end

return function(mod)
  local Screen = makeScreenClass(mod)

  mod.content.screens:register(SCREEN, {
    new = function(game)
      return Screen.new(game)
    end,
  })

  -- High priority + post-processing: run the rest of the Start-menu chain first
  -- and inspect its final list. If another compatible SUMMON mod already added
  -- the row, do nothing instead of creating a duplicate entry.
  mod.hooks:wrap("ui.start_menu.items", function(next, game, items)
    local out = next(game, items)
    if type(out) ~= "table" then out = items end
    if hasSummonRow(out) then return out end

    return mod.ui.insertBefore(out, "SAVE", {
      label = "SUMMON",
      desc = { "Choose a wild", "POKéMON" },
      pokemonmodGen2Summon = true,
      onSelect = function()
        if not hasHealthyParty(game) then
          game.stack:push(mod.ui.TextBox.new(game,
            "No healthy POKéMON\ncan battle."))
          return
        end
        mod.ui.push(game, SCREEN)
      end,
    })
  end, HOOK_PRIORITY)

  mod.exports.buildDexIndex = function(game) return buildDexIndex(game or mod.game) end
  mod.exports.summonLevel = summonLevel
  mod.exports.newScreen = function(game) return Screen.new(game) end

  mod.log:info("Summon - Gen 2 loaded")
end
