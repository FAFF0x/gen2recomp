# Changelog

## 1.2.0

- Fixed Pokédex/UI reporting `TRADE` for the converted Generation II evolutions.
- Trade rows are now actually replaced with level rows in the Pokémon data instead of being retained as hidden alternatives.
- Covers all ten canonical Gen 2 trade evolution lines.
- Held-item evolutions keep their original item requirement but trigger on level-up.
- Slowpoke + King's Rock is checked before the normal Slowbro level-37 path.
- Held evolution items are consumed only after a successful evolution.
- Preserves level paths already supplied by other mods and avoids duplicate conversions.
- Supports both `LEVEL`/`TRADE` and `EVOLVE_LEVEL`/`EVOLVE_TRADE` method names.

## 1.1.0

- Added all Generation II trade evolution targets.
- Previous implementation retained the trade row and allowed level-up through an evolution hook; this caused Pokédex screens to continue displaying TRADE.

## 1.0.0

- Initial Gen 2 conversion of the four classic trade evolutions.
