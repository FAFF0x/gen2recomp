-- Trade Evolution Fix - Gen 2
-- Gen 2-only solo evolution support for every vanilla trade evolution.
--
-- v1.2.0:
-- * Replaces the vanilla TRADE row itself with a LEVEL row. No hidden TRADE
--   duplicate is left in the species data, so Pokédex/UI mods report LEVEL.
-- * The four classic no-item trades evolve at level 40.
-- * Gen 2 held-item trades evolve by level while holding the original item.
-- * Slowpoke -> Slowking is checked before Slowbro at level 37: KING'S ROCK
--   chooses Slowking, otherwise the vanilla Slowbro evolution remains valid.
-- * Held items are consumed only after a successful solo evolution.
-- * Existing non-trade evolution paths supplied by another mod are preserved.

local TRADE_METHODS = {
  TRADE = true,
  EVOLVE_TRADE = true,
}

local LEVEL_METHODS = {
  LEVEL = true,
  EVOLVE_LEVEL = true,
}

local TARGETS = {
  KADABRA  = { into = "ALAKAZAM", level = 40 },
  MACHOKE  = { into = "MACHAMP",  level = 40 },
  GRAVELER = { into = "GOLEM",    level = 40 },
  HAUNTER  = { into = "GENGAR",   level = 40 },

  POLIWHIRL = { into = "POLITOED", level = 40, item = "KINGS_ROCK" },
  SLOWPOKE  = { into = "SLOWKING", level = 37, item = "KINGS_ROCK", first = true },
  ONIX      = { into = "STEELIX",  level = 40, item = "METAL_COAT" },
  SCYTHER   = { into = "SCIZOR",   level = 40, item = "METAL_COAT" },
  SEADRA    = { into = "KINGDRA",  level = 40, item = "DRAGON_SCALE" },
  PORYGON   = { into = "PORYGON2", level = 40, item = "UP_GRADE" },
}

local function copyEvolution(row)
  local out = {}
  for key, value in pairs(row or {}) do out[key] = value end
  return out
end

local function targetOf(row)
  return row and (row.species or row.into)
end

local function setTarget(row, target)
  if row.species ~= nil then
    row.species = target
  elseif row.into ~= nil then
    row.into = target
  else
    -- Current API uses `species`; older Gen 2 data used `into`.
    row.species = target
  end
end

local function levelMethodFor(tradeMethod)
  if tradeMethod == "EVOLVE_TRADE" then return "EVOLVE_LEVEL" end
  return "LEVEL"
end

local function pairKey(source, target)
  return tostring(source) .. ">" .. tostring(target)
end

return function(mod)
  local convertedPairs = {}
  local converted = 0
  local alreadyFixed = 0
  local missing = 0

  for speciesId, spec in pairs(TARGETS) do
    local species = mod.content.pokemon:get(speciesId)

    if not species or type(species.evolutions) ~= "table" then
      missing = missing + 1
      mod.log:warn("No evolution data found for %s", speciesId)
    else
      local tradeRow = nil
      local existingLevelRow = nil

      for _, evo in ipairs(species.evolutions) do
        if targetOf(evo) == spec.into then
          if TRADE_METHODS[evo.method] then
            tradeRow = evo
          elseif LEVEL_METHODS[evo.method] then
            existingLevelRow = evo
          end
        end
      end

      if existingLevelRow then
        -- Another mod already replaced this trade evolution. Do not overwrite it.
        alreadyFixed = alreadyFixed + 1
      elseif not tradeRow then
        missing = missing + 1
        mod.log:warn(
          "Vanilla trade evolution %s -> %s was not found; leaving species untouched",
          speciesId, spec.into
        )
      else
        local levelRow = copyEvolution(tradeRow)
        levelRow.method = levelMethodFor(tradeRow.method)
        levelRow.level = spec.level
        setTarget(levelRow, spec.into)

        if spec.item then
          -- Keep the canonical Gen 2 held-item requirement on the new level path.
          levelRow.item = levelRow.item or spec.item
        else
          -- Classic trade evolutions have no item requirement.
          levelRow.item = nil
        end

        local evolutions = {}

        -- Slowpoke must test the KING'S ROCK path before vanilla Slowbro @ 37.
        if spec.first then
          evolutions[#evolutions + 1] = levelRow
          for _, evo in ipairs(species.evolutions) do
            if evo ~= tradeRow then evolutions[#evolutions + 1] = copyEvolution(evo) end
          end
        else
          for _, evo in ipairs(species.evolutions) do
            if evo == tradeRow then
              evolutions[#evolutions + 1] = levelRow
            else
              evolutions[#evolutions + 1] = copyEvolution(evo)
            end
          end
        end

        mod.content.pokemon:patch(speciesId, { evolutions = evolutions })
        convertedPairs[pairKey(speciesId, spec.into)] = {
          level = spec.level,
          item = levelRow.item,
          method = levelRow.method,
        }
        converted = converted + 1
      end
    end
  end

  -- Vanilla LEVEL checks only test the level. For the six Gen 2 evolutions
  -- that originally required a held item during trade, also require that item
  -- on the replacement LEVEL row. Only rows converted by this mod are touched.
  mod.hooks:wrap("evolution.check", function(next, game, mon, evo, trigger)
    local source = mon and mon.species
    local target = targetOf(evo)
    local ours = source and target and convertedPairs[pairKey(source, target)] or nil

    if ours
      and LEVEL_METHODS[evo and evo.method]
      and evo.method == ours.method
      and tonumber(evo.level) == tonumber(ours.level)
    then
      if not trigger or trigger.kind ~= "levelup" then return false end
      if (mon.level or 1) < ours.level then return false end
      if ours.item and mon.item ~= ours.item then return false end
      return true
    end

    return next(game, mon, evo, trigger)
  end, 500)

  -- Consume held evolution items only after the evolution actually succeeds.
  -- If a cancelable level evolution is declined, pokemon.evolved is not emitted.
  mod.events:on("pokemon.evolved", function(ev)
    if not ev or not ev.mon then return end
    if not LEVEL_METHODS[ev.via] then return end

    local ours = convertedPairs[pairKey(ev.fromSpecies, ev.toSpecies)]
    if not ours or not ours.item then return end

    if ev.mon.item == ours.item then
      ev.mon.item = nil
    end
  end)

  mod.log:info(
    "Gen 2 Trade Evolution Fix replaced %d trade evolution(s) with level paths; %d already fixed, %d missing",
    converted, alreadyFixed, missing
  )
end
