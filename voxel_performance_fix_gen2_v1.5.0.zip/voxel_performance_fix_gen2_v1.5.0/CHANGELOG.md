# Changelog

## 1.5.0
- Added high-frequency cooperative budget checks during visible Gen 2 meshing (1-in-4 calls instead of upstream 1-in-32).
- Targets the remaining 37-55 ms `voxel.update` overshoots seen in the v1.4 performance report.
- Added staged activation for newly-ready neighbour maps, one new neighbour every 6 frames.
- Prevents several neighbour atlases/aux meshes from becoming visible on one frame, targeting the large first-draw spike when draw calls jumped from ~75 to ~208.
- Preserved v1.4's BODY-first loading and 6.5/4.75 ms visible slice caps.
- Preserved original 30 ms covered loading and 5 ms idle-neighbour loading.

## 1.4.0
- Replaced update-frequency throttling with direct cooperative mesh-budget capping.

## 1.3.0
- Added BODY-first fast-start path.

## 1.2.0
- Corrected Gen 2 visible-world detection while moving.
