# Voxel Performance Fix Gen 2 v1.6.0

External optimization/compatibility patch for **BATTLE_ART_VOXEL_GEN2 2.1.x**.
The original mod is not modified.

## Compatibility

- Requires **BATTLE_ART_VOXEL_GEN2 >=2.1.1 and <2.2.0**.
- Designed for Generation 2 (`gen2`).
- Replaces the older `voxel_performance_fix_gen2` build; do not install multiple versions at the same time.

## What v1.6 changes

- Updates the dependency range for **BATTLE ART VOXEL 2.1.x**.
- Follows the newer world lookup used by BATTLE ART (`Game.overworld` with `Game.world` fallback).
- Keeps the Gen 2 empty-StateStack visibility correction.
- Keeps BODY-first loading so the current map gets usable 3D geometry early.
- Keeps the foreground slice caps:
  - BODY bootstrap: up to **6.5 ms** per visible frame.
  - FULL completion: up to **4.75 ms** per visible frame.
- Keeps stricter visible-world `BuildBudget.tick()` sampling every **4 calls**.
- Leaves BATTLE ART 2.1.x's newer `BuildBudget.check()` path untouched, so its exact checks continue to work.
- Staggers newly-ready neighbour maps so at most one fresh neighbour becomes drawable every **6 frames**.
- Covered/menu/transition loading keeps BATTLE ART's original 30 ms behavior.
- Idle neighbour meshing keeps the original 5 ms budget.

## Install

Install together with **BATTLE_ART_VOXEL_GEN2 2.1.1** (or another compatible 2.1.x release). Replace the old `voxel_performance_fix_gen2` version; do not keep multiple versions installed.
