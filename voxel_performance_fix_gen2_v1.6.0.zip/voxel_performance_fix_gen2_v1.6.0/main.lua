-- Voxel Performance Fix Gen 2 v1.6.0
--
-- External compatibility/performance patch for BATTLE_ART_VOXEL_GEN2 2.1.x.
-- The original mod is never modified.
--
-- v1.6 ports the v1.5 optimizations to BATTLE ART VOXEL 2.1.x and keeps the
-- same two anti-spike protections while following the newer Gen 2 world API:
--   1) BuildBudget.tick samples the clock only every 32 calls upstream. On a
--      complex structure one batch of 32 iterations can overshoot a 4.75 ms
--      slice by tens of milliseconds. While the visible Gen 2 world is being
--      meshed we check the deadline every 4 calls instead.
--   2) Several newly-ready neighbour maps can become drawable on the same
--      frame. Their first atlas/aux draws then land together. We expose at most
--      one NEW neighbour every few frames; already-visible maps stay visible,
--      so seam crossings never make the map behind the player disappear.

local mod = ...

local registry = mod.content and mod.content.render_pipelines
if not registry then
  error("Voxel Performance Fix Gen 2: render_pipelines registry unavailable", 0)
end

local voxel = registry:get("voxel")
if type(voxel) ~= "table" or type(voxel.update) ~= "function" then
  error("Voxel Performance Fix Gen 2: BATTLE_ART_VOXEL_GEN2 voxel.update not found", 0)
end
local originalUpdate = voxel.update

-- Use only BATTLE ART's published module namespace. No file is copied or
-- replaced; the fix wraps the live module tables exported by the dependency.
local ChunkMesher, BuildBudget, TerrainAtlas = nil, nil, nil
do
  local ok, peer = pcall(function()
    return mod.find and mod.find("BATTLE_ART_VOXEL_GEN2") or nil
  end)
  if ok and peer and peer.exports and peer.exports.lib
      and type(peer.exports.lib.require) == "function" then
    local function take(name)
      local okM, value = pcall(peer.exports.lib.require, name)
      return okM and type(value) == "table" and value or nil
    end
    ChunkMesher = take("ChunkMesher")
    BuildBudget = take("BuildBudget")
    TerrainAtlas = take("TerrainAtlas")
  end
end

if not ChunkMesher then
  error("Voxel Performance Fix Gen 2: BATTLE ART ChunkMesher export unavailable", 0)
end
if not BuildBudget or type(BuildBudget.begin) ~= "function"
    or type(BuildBudget.tick) ~= "function"
    or type(BuildBudget.expired) ~= "function" then
  error("Voxel Performance Fix Gen 2: BATTLE ART BuildBudget export unavailable", 0)
end
if not TerrainAtlas or type(TerrainAtlas.forMap) ~= "function" then
  error("Voxel Performance Fix Gen 2: BATTLE ART TerrainAtlas export unavailable", 0)
end

local originalBudgetBegin = BuildBudget.begin
local originalBudgetTick = BuildBudget.tick

-- BATTLE ART budgets, for recognition only:
--   visible current-map = 0.012
--   idle/neighbour      = 0.005
--   covered/hidden      = 0.030
-- We cap only the visible 12 ms class. Covered and idle budgets stay upstream.
local BODY_BOOTSTRAP_SLICE = 0.0065
local FULL_VISIBLE_SLICE   = 0.00475
local FOREGROUND_MIN       = 0.009
local FOREGROUND_MAX       = 0.020

local visibleSlice = FULL_VISIBLE_SLICE
local budgetPatchActive = false
local strictTickActive = false
local strictTickCounter = 0
local STRICT_TICK_EVERY = 4

BuildBudget.begin = function(co, seconds)
  local s = tonumber(seconds)
  if budgetPatchActive and s and s >= FOREGROUND_MIN and s <= FOREGROUND_MAX then
    s = math.min(s, visibleSlice)
  end
  return originalBudgetBegin(co, s or seconds)
end

-- Upstream checks its deadline every 32 Budget.tick() calls. That is cheap,
-- but a complex tree/building iteration can make 32 calls span 30-50 ms. In
-- visible-world foreground meshing, sample every 4 calls instead. We yield only
-- from a coroutine and only after BuildBudget says the current slice expired;
-- outside the async pump, or while the world is covered, upstream behavior is
-- untouched.
-- BATTLE ART 2.1.x also has BuildBudget.check() for coarse upload loops. We do
-- not replace it: those exact per-iteration checks remain active alongside this
-- stricter tick() sampling for the older fine-grained geometry loops.
BuildBudget.tick = function(...)
  if not strictTickActive then return originalBudgetTick(...) end
  strictTickCounter = strictTickCounter + 1
  if strictTickCounter < STRICT_TICK_EVERY then return end
  strictTickCounter = 0
  local co = coroutine.running()
  if co and BuildBudget.expired() then
    return coroutine.yield("budget")
  end
end

local function liveGame()
  return mod.game
end

-- BATTLE ART VOXEL 2.1.x resolves the live Gen 2 overworld through either
-- Game.overworld or Game.world depending on the runtime. Mirror that contract
-- here so the performance shim follows the same state object as the dependency.
local function liveWorld(game)
  return game and (game.overworld or game.world) or nil
end

local function currentWorld(level)
  local game = liveGame()
  local world = liveWorld(game)
  local map = world and world.map or nil
  local active = map ~= nil and tonumber(level or 0) > 0
  return game, world, map, active
end

local function stackTop(game)
  local stack = game and game.stack
  if not (stack and type(stack.top) == "function") then return nil end
  local ok, top = pcall(stack.top, stack)
  return ok and top or nil
end

local function slotKnown(map, bodyOnly)
  if not map or type(ChunkMesher.slotKnown) ~= "function" then return false end
  local ok, known = pcall(ChunkMesher.slotKnown, map, bodyOnly)
  return ok and known == true
end

local function queueBody(map)
  if not map or slotKnown(map, true) then return end
  if type(ChunkMesher.request) == "function" then
    pcall(ChunkMesher.request, map, true, nil, true)
  end
end

-- ---------------------------------------------------------------- neighbour staging
-- VoxelScene is designed to tolerate a missing neighbour and draw the current
-- map's border ring until it appears. Exploit that existing fallback to avoid
-- activating several fresh atlases/aux meshes on one frame.
local originalPair = ChunkMesher.pair
local originalGrass = ChunkMesher.grass
local originalFlowers = ChunkMesher.flowers
local originalFigures = ChunkMesher.figures
local originalAtlasForMap = TerrainAtlas.forMap

local exposed = {}
local pending = {}
local currentMapId = nil
local previousMapId = nil
local exposeCooldown = 0
local EXPOSE_GAP_FRAMES = 6

local function isCurrent(map)
  local game = liveGame()
  local world = liveWorld(game)
  return map and world and world.map and map.id == world.map.id
end

local function visibleMap(map)
  if not map then return true end
  if isCurrent(map) then return true end
  return exposed[map.id] == true
end

local function notePending(map, hasDrawable)
  if map and hasDrawable and not isCurrent(map) and not exposed[map.id] then
    pending[map.id] = true
  end
end

if type(originalPair) == "function" then
  ChunkMesher.pair = function(map, bodyOnly)
    local mesh, water = originalPair(map, bodyOnly)
    notePending(map, mesh ~= nil)
    if not visibleMap(map) then return nil, nil end
    return mesh, water
  end
end

if type(originalGrass) == "function" then
  ChunkMesher.grass = function(map)
    if not visibleMap(map) then return nil end
    return originalGrass(map)
  end
end

if type(originalFlowers) == "function" then
  ChunkMesher.flowers = function(map)
    if not visibleMap(map) then return nil end
    return originalFlowers(map)
  end
end

if type(originalFigures) == "function" then
  ChunkMesher.figures = function(map)
    if not visibleMap(map) then return nil end
    return originalFigures(map)
  end
end

TerrainAtlas.forMap = function(map, colors)
  if not visibleMap(map) then return nil end
  return originalAtlasForMap(map, colors)
end

local function updateCurrentMap(map)
  local id = map and map.id or nil
  if id == currentMapId then return end
  previousMapId = currentMapId
  currentMapId = id
  if previousMapId then exposed[previousMapId] = true end
  if currentMapId then exposed[currentMapId] = true end
  exposeCooldown = 0
end

local function advanceNeighbourExposure()
  if exposeCooldown > 0 then
    exposeCooldown = exposeCooldown - 1
    return
  end
  local pick = nil
  for id in pairs(pending) do
    if not exposed[id] then
      if not pick or id < pick then pick = id end
    end
  end
  if not pick then return end
  pending[pick] = nil
  exposed[pick] = true
  exposeCooldown = EXPOSE_GAP_FRAMES
end

-- ---------------------------------------------------------------- Gen 2 visibility shim
local function withVisibleWorldShim(fn)
  local game = liveGame()
  local stack = game and game.stack or nil
  local world = liveWorld(game)
  local originalTop = stack and stack.top or nil
  local shimmed = false

  -- Gen 2 keeps its visible overworld outside StateStack. Empty stack means
  -- visible even while walking or a field script is busy. Present world-as-top
  -- only to BATTLE ART so ChunkMesher.pump receives covered=false.
  if stack and world and world.map and type(originalTop) == "function" then
    local okTop, actualTop = pcall(originalTop, stack)
    if okTop and actualTop == nil then
      stack.top = function(self)
        local real = originalTop(self)
        if real ~= nil then return real end
        return world
      end
      shimmed = true
    end
  end

  local ok, result = pcall(fn)
  if shimmed then stack.top = originalTop end
  if not ok then error(result, 0) end
  return result
end

local function optimizedUpdate(dt, level)
  local game, _, map, active = currentWorld(level)
  updateCurrentMap(map)

  if active then
    queueBody(map)
    local bodyReady = slotKnown(map, true)
    local fullReady = slotKnown(map, false)
    if not bodyReady then
      visibleSlice = BODY_BOOTSTRAP_SLICE
    elseif not fullReady then
      visibleSlice = FULL_VISIBLE_SLICE
    else
      visibleSlice = FULL_VISIBLE_SLICE
    end
  else
    visibleSlice = FULL_VISIBLE_SLICE
  end

  -- Strict 1-in-4 budget polling only while the real Gen 2 stack is empty:
  -- this is the case where meshing can hitch the visible overworld. Menus and
  -- transitions keep upstream's wider/cheaper covered behavior.
  strictTickActive = active and stackTop(game) == nil
  strictTickCounter = 0
  budgetPatchActive = true
  local ok, result = pcall(function()
    return withVisibleWorldShim(function()
      return originalUpdate(dt, level)
    end)
  end)
  budgetPatchActive = false
  strictTickActive = false
  strictTickCounter = 0
  if not ok then error(result, 0) end

  -- originalUpdate/prefetch has now had a chance to discover newly-ready
  -- neighbour body meshes through the wrapped pair() calls. Reveal at most one
  -- after this update, then leave several frames before the next one.
  advanceNeighbourExposure()
  return result
end

registry:patch("voxel", { update = optimizedUpdate })
